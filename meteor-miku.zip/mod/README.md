# meteor-miku

Meteor Client 的客户端附加模组（addon），是 [meteor-rejects](https://github.com/MeteorDevelopment/meteor-rejects)
在 **Minecraft 26.1 ~ 26.1.2 / Fabric** 上的移植与扩展版本。

- 加载器：Fabric `0.19.5`
- Minecraft：`26.1` ~ `26.1.2`
- Java：`25`
- 运行前置：[Meteor Client](https://github.com/MeteorDevelopment/meteor-client) `26.1.2`
  （可选：[Baritone](https://github.com/cabaletta/baritone)、Xaero 小地图/世界地图、Litematica、MiniHUD）

## 构建

```bash
./gradlew build       # 产物在 build/libs/
```

构建会生成 `meteor-miku-<version>.jar`，直接放进客户端的 `mods/` 目录即可
（仅客户端模组，不需要装在服务端）。

## 许可证

Copyright (C) 2024-2026 XC_XinCheng

本程序是自由软件：你可以依据 **GNU 通用公共许可证第 3 版**（GNU GPL v3.0）
的条款重新发布和/或修改它。

```
SPDX-License-Identifier: GPL-3.0-only
```

本程序基于“有用”的期望分发，但不提供任何担保，甚至不提供适销性或特定用途
适用性的默示担保。详见随附的 [LICENSE](LICENSE)（GNU GPL v3.0 全文）。

### 为什么是 GPL-3.0

本模组的全部运行前置与上游源码都以 GPL-3.0 发布：

- [Meteor Client](https://github.com/MeteorDevelopment/meteor-client)：GPL-3.0
- [meteor-rejects](https://github.com/MeteorDevelopment/meteor-rejects)：GPL-3.0
- [Baritone](https://github.com/cabaletta/baritone)：LGPL-3.0

由于本模组是它们的衍生作品，因此同样以 GPL-3.0 发布，并保留上游的版权声明。
各上游项目的完整归属与许可见 [THIRD-PARTY-NOTICES.md](THIRD-PARTY-NOTICES.md)。

### 源码获取

GPL-3.0 要求分发二进制时同时提供对应的完整源码。本模组的完整源码发布于：

<https://github.com/mikumiku7/meteor-miku>

发布的 jar 包内 `META-INF/` 目录下同时附带了 `LICENSE` 与
`THIRD-PARTY-NOTICES.md`。

## 修改说明

本项目相对上游 `meteor-rejects` 的主要修改：为适配 Minecraft 26.1（游戏不再混淆、
使用 Mojang 官方名）重写了 mixin 的目标方法名与访问器、更新了方块/物品注册方式与
资源目录格式，并新增了若干模块。依据 GPL-3.0 第 5 条，修改部分已在源码文件头与
提交历史中标注。

种子相关模块的版本选择：种子库 `seedfinding` 的 `MCVersion` 只收录到 1.21，没有
26.1 / 26.1.1 / 26.1.2 这些常量；本项目新增 `util/seeds/SeedVersion`，在库版本之外
补上 **26.1**、**26.1.1**、**26.1.2** 三个选项，默认 26.1.2。“种子矿透”（`SeedMine`）
在这些版本下直接调用本版游戏原生的世界生成算法（与上游 `OreSim` 的做法一致），
26.1.x 补丁号之间算法相同，因此版本选择只用于记录种子来源，不影响矿位计算；
种子库版本仅作为种子元数据兼容保留。

### 种子矿透的矿石外观

“种子矿透”的设置里，“矿石”一行点 `Select` 打开选择界面，按浅层矿石（Y≥0 石头）、
深层矿石（Y&lt;0 深板岩）、下界矿石分成三段，每段标题右边可一次全选整层。段内每一行：

- **颜色**：点色块打开取色器，改这种矿石的 3D 边框颜色（默认沿用内置色）。
- **连接**：勾选后，相邻的同类矿石边框会连成一体，不再逐块画方框。
- **显示**：勾选后才显示、也会被“同步设置 baritone / 直接开挖”当作目标。

“与世界同步”打开后，会按“同步时间”（秒）定期读取当前世界的真实种子（单人是存档
种子，服务器是按世界名保存的种子），种子或维度变化时自动重算矿位，平时只补算新
加载的区块。种子算矿算法本身没有改动。

