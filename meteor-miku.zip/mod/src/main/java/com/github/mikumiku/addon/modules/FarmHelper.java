/*
 * 本文件属于 meteor-miku 项目：https://github.com/mikumiku7/meteor-miku
 * meteor-miku 是 meteor-rejects 在 Minecraft 26.1 / Fabric 上的移植版本。
 *
 * Copyright (C) 2024-2026 XC_XinCheng
 *
 * SPDX-License-Identifier: GPL-3.0-only
 *
 * 本程序是自由软件：你可以依据 GNU 通用公共许可证（GNU GPL）第 3 版的条款
 * 重新发布和/或修改它。
 *
 * 本程序基于“有用”的期望分发，但不提供任何担保，甚至不提供适销性或特定
 * 用途适用性的默示担保。详见 GNU 通用公共许可证。
 *
 * 你应当已随本程序收到一份 GNU 通用公共许可证副本；如果没有，请见
 * <https://www.gnu.org/licenses/>。
 */
package com.github.mikumiku.addon.modules;

import com.github.mikumiku.addon.BaseModule;
import com.github.mikumiku.addon.util.BagUtil;
import com.github.mikumiku.addon.util.BaritoneUtil;
import com.github.mikumiku.addon.util.WorldUtils;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.world.level.block.BeetrootBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.GrowingPlantHeadBlock;
import net.minecraft.world.level.block.NetherWartBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.InteractionHand;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;

import java.util.*;

import static net.minecraft.world.level.block.GrowingPlantHeadBlock.AGE;
import static net.minecraft.world.level.block.state.properties.BlockStateProperties.WATERLOGGED;

public class FarmHelper extends BaseModule {

    // 设置组，用于组织模块的设置选项
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgBonemeal = settings.createGroup("骨粉");
    private final SettingGroup sgRender = settings.createGroup("渲染");

    // 工作模式设置
    private final Setting<WorkMode> workMode = sgGeneral.add(new EnumSetting.Builder<WorkMode>()
        .name("工作模式").description("选择农场助手的工作模式").defaultValue(WorkMode.All).build());

    // 锄地设置
    private final Setting<Integer> tillDelay = sgGeneral.add(new IntSetting.Builder()
        .name("锄地延迟").description("锄地操作之间的延迟").defaultValue(1).min(0).sliderMax(20).build());
    private final Setting<Integer> tillRange = sgGeneral.add(new IntSetting.Builder()
        .name("锄地范围").description("锄地的水平范围").defaultValue(4).min(1).sliderMax(6).build());
    private final Setting<Boolean> autoSwitchHoe = sgGeneral.add(new BoolSetting.Builder()
        .name("自动切换锄头").description("没有锄头时自动切换到可用的锄头").defaultValue(true).build());

    // 种植设置
    private final Setting<Integer> plantDelay = sgGeneral.add(new IntSetting.Builder()
        .name("种植延迟").description("种植操作之间的延迟").defaultValue(1).min(0).sliderMax(20).build());
    private final Setting<Integer> plantRange = sgGeneral.add(new IntSetting.Builder()
        .name("种植范围").description("种植的水平范围").defaultValue(4).min(1).sliderMax(6).build());
    private final Setting<CropType> cropType = sgGeneral.add(new EnumSetting.Builder<CropType>()
        .name("作物类型").description("选择要种植的作物类型").defaultValue(CropType.Wheat).build());
    private final Setting<Boolean> autoSwitchSeeds = sgGeneral.add(new BoolSetting.Builder()
        .name("自动切换种子").description("种植时自动切换到选定的种子").defaultValue(true).build());

    // 收割设置
    private final Setting<Integer> harvestDelay = sgGeneral.add(new IntSetting.Builder()
        .name("收割延迟").description("收割操作之间的延迟").defaultValue(1).min(0).sliderMax(20).build());
    private final Setting<Integer> harvestRange = sgGeneral.add(new IntSetting.Builder()
        .name("收割范围").description("收割的水平范围").defaultValue(4).min(1).sliderMax(6).build());
    private final Setting<Boolean> harvestOnlyMature = sgGeneral.add(new BoolSetting.Builder()
        .name("仅收割成熟").description("只收割成熟的作物").defaultValue(true).build());

    // 排序模式
    private final Setting<SortMode> sortMode = sgGeneral.add(new EnumSetting.Builder<SortMode>()
        .name("排序模式").description("如何排序要处理的方块").defaultValue(SortMode.Farthest).build());

    // 骨粉设置
    private final Setting<Boolean> useBonemeal = sgBonemeal.add(new BoolSetting.Builder()
        .name("使用骨粉")
        .description("启用骨粉催熟作物功能")
        .defaultValue(false)
        .build());

    private final Setting<Integer> bonemealDelay = sgBonemeal.add(new IntSetting.Builder()
        .name("骨粉延迟")
        .description("使用骨粉之间的延迟")
        .defaultValue(1)
        .min(0)
        .sliderMax(20)
        .build());

    private final Setting<Integer> bonemealRange = sgBonemeal.add(new IntSetting.Builder()
        .name("骨粉范围")
        .description("骨粉使用的水平范围")
        .defaultValue(4)
        .min(1)
        .sliderMax(6)
        .build());

    private final Setting<Integer> maxBonemealAttempts = sgBonemeal.add(new IntSetting.Builder()
        .name("最大骨粉次数")
        .description("对单个作物最多使用骨粉的次数")
        .defaultValue(10)
        .min(1)
        .sliderMax(20)
        .build());

    private final Setting<Boolean> autoSwitchBonemeal = sgBonemeal.add(new BoolSetting.Builder()
        .name("自动切换骨粉")
        .description("使用骨粉时自动切换到骨粉")
        .defaultValue(true)
        .build());

    // 渲染设置
    private final Setting<Boolean> render = sgRender.add(new BoolSetting.Builder()
        .name("显示渲染")
        .description("是否显示要处理的方块渲染预览")
        .defaultValue(true)
        .build());

    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
        .name("渲染模式")
        .description("选择渲染的显示模式")
        .defaultValue(ShapeMode.Both)
        .build());

    private final Setting<SettingColor> tillSideColor = sgRender.add(new ColorSetting.Builder()
        .name("锄地侧面颜色")
        .description("要锄地方块的侧面填充颜色")
        .defaultValue(new SettingColor(139, 69, 19, 30)) // 棕色
        .build());

    private final Setting<SettingColor> tillLineColor = sgRender.add(new ColorSetting.Builder()
        .name("锄地线条颜色")
        .description("要锄地方块的线条颜色")
        .defaultValue(new SettingColor(139, 69, 19, 255)) // 棕色
        .build());

    private final Setting<SettingColor> plantSideColor = sgRender.add(new ColorSetting.Builder()
        .name("种植侧面颜色")
        .description("要种植位置的侧面填充颜色")
        .defaultValue(new SettingColor(34, 139, 34, 30)) // 绿色
        .build());

    private final Setting<SettingColor> plantLineColor = sgRender.add(new ColorSetting.Builder()
        .name("种植线条颜色")
        .description("要种植位置的线条颜色")
        .defaultValue(new SettingColor(34, 139, 34, 255)) // 绿色
        .build());

    private final Setting<SettingColor> harvestSideColor = sgRender.add(new ColorSetting.Builder()
        .name("收割侧面颜色")
        .description("要收割作物的侧面填充颜色")
        .defaultValue(new SettingColor(255, 215, 0, 30)) // 金色
        .build());

    private final Setting<SettingColor> harvestLineColor = sgRender.add(new ColorSetting.Builder()
        .name("收割线条颜色")
        .description("要收割作物的线条颜色")
        .defaultValue(new SettingColor(255, 215, 0, 255)) // 金色
        .build());

    private final Setting<SettingColor> bonemealSideColor = sgRender.add(new ColorSetting.Builder()
        .name("骨粉侧面颜色")
        .description("要使用骨粉作物的侧面填充颜色")
        .defaultValue(new SettingColor(255, 255, 255, 30)) // 白色
        .build());

    private final Setting<SettingColor> bonemealLineColor = sgRender.add(new ColorSetting.Builder()
        .name("骨粉线条颜色")
        .description("要使用骨粉作物的线条颜色")
        .defaultValue(new SettingColor(255, 255, 255, 255)) // 白色
        .build());

    // 计时器
    private int tillTimer, plantTimer, harvestTimer, bonemealTimer;

    // 背包扫描
    private Map<Item, Integer> availableTools;
    private int toolSlotCurrent = -1;
    private Map<Item, Integer> availableSeeds;
    private Map<Item, Integer> availableBonemeal;
    private int bonemealSlotCurrent = -1;
    private long lastInventoryScanTime = 0;
    private static final long INVENTORY_SCAN_INTERVAL = 1000; // 1秒扫描一次背包

    // 骨粉使用记录
    private Map<BlockPos, Integer> bonemealCount;

    // 错误消息控制
    private long lastHoeErrorTime = 0;
    private long lastSeedErrorTime = 0;
    private long lastBonemealErrorTime = 0;
    private static final long ERROR_COOLDOWN = 5000; // 5秒冷却时间

    public FarmHelper() {
        super(CATEGORY_MIKU_BUILD, "农场助手", "自动锄地、种植和收割作物");
    }

    @Override
    public void onActivate() {
        super.onActivate();
        // 激活模块时重置计时器和状态
        tillTimer = 0;
        plantTimer = 0;
        harvestTimer = 0;
        bonemealTimer = 0;
        availableTools = new HashMap<>();
        availableSeeds = new HashMap<>();
        availableBonemeal = new HashMap<>();
        bonemealCount = new HashMap<>();
        lastInventoryScanTime = 0;
    }

    @EventHandler
    public void onTick(TickEvent.Post event) {
        // 每个游戏刻减少计时器
        tillTimer--;
        plantTimer--;
        harvestTimer--;
        bonemealTimer--;

        // 扫描背包中的工具和种子
        scanInventory();

        // 根据工作模式执行相应操作
        WorkMode mode = workMode.get();

        // 锄地
        if ((mode == WorkMode.All || mode == WorkMode.Till) && tillTimer <= 0) {
            BlockPos tillPos = findTillPosition();
            if (tillPos != null) {
                doTill(tillPos);
            }
            tillTimer = tillDelay.get();
        }

        // 种植
        if ((mode == WorkMode.All || mode == WorkMode.Plant) && plantTimer <= 0) {
            BlockPos plantPos = findPlantPosition();
            if (plantPos != null) {
                doPlant(plantPos);
            }
            plantTimer = plantDelay.get();
        }

        // 收割
        if ((mode == WorkMode.All || mode == WorkMode.Harvest) && harvestTimer <= 0) {
            BlockPos harvestPos = findHarvestPosition();
            if (harvestPos != null) {
                doHarvest(harvestPos);
            }
            harvestTimer = harvestDelay.get();
        }

        // 骨粉（独立于工作模式）
        if (useBonemeal.get() && bonemealTimer <= 0) {
            BlockPos bonemealPos = findBonemealPosition();
            if (bonemealPos != null) {
                doBonemeal(bonemealPos);
            }
            bonemealTimer = bonemealDelay.get();
        }
    }

    // 扫描背包中的工具和种子
    private void scanInventory() {
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastInventoryScanTime < INVENTORY_SCAN_INTERVAL) {
            return;
        }

        availableTools.clear();
        availableSeeds.clear();
        availableBonemeal.clear();
        toolSlotCurrent = -1;
        bonemealSlotCurrent = -1;
        // 扫描锄头
        List<Item> tools = Arrays.asList(Items.WOODEN_HOE, Items.STONE_HOE, Items.IRON_HOE, Items.GOLDEN_HOE, Items.DIAMOND_HOE, Items.NETHERITE_HOE);
        for (Item tool : tools) {
            int toolSlot = BagUtil.findItemInventorySlot(tool);
            if (toolSlot != -1) {
                availableTools.put(tool, toolSlot);
                toolSlotCurrent = toolSlot;
            }
        }

        // 扫描种子
        CropType type = cropType.get();
        switch (type) {
            case Wheat:
                int wheatSlot = BagUtil.findItemInventorySlot(Items.WHEAT_SEEDS);
                if (wheatSlot != -1) {
                    availableSeeds.put(Items.WHEAT_SEEDS, wheatSlot);
                }
                break;
            case Carrot:
                int carrotSlot = BagUtil.findItemInventorySlot(Items.CARROT);
                if (carrotSlot != -1) {
                    availableSeeds.put(Items.CARROT, carrotSlot);
                }
                break;
            case Potato:
                int potatoSlot = BagUtil.findItemInventorySlot(Items.POTATO);
                if (potatoSlot != -1) {
                    availableSeeds.put(Items.POTATO, potatoSlot);
                }
                break;
            case Beetroot:
                int beetrootSlot = BagUtil.findItemInventorySlot(Items.BEETROOT_SEEDS);
                if (beetrootSlot != -1) {
                    availableSeeds.put(Items.BEETROOT_SEEDS, beetrootSlot);
                }
                break;
            case Pumpkin:
                int pumpkinSlot = BagUtil.findItemInventorySlot(Items.PUMPKIN_SEEDS);
                if (pumpkinSlot != -1) {
                    availableSeeds.put(Items.PUMPKIN_SEEDS, pumpkinSlot);
                }
                break;
            case Melon:
                int melonSlot = BagUtil.findItemInventorySlot(Items.MELON_SEEDS);
                if (melonSlot != -1) {
                    availableSeeds.put(Items.MELON_SEEDS, melonSlot);
                }
                break;
            case NetherWart:
                int netherWartSlot = BagUtil.findItemInventorySlot(Items.NETHER_WART);
                if (netherWartSlot != -1) {
                    availableSeeds.put(Items.NETHER_WART, netherWartSlot);
                }
                break;
        }

        // 扫描骨粉
        int bonemealSlot = BagUtil.findItemInventorySlot(Items.BONE_MEAL);
        if (bonemealSlot != -1) {
            availableBonemeal.put(Items.BONE_MEAL, bonemealSlot);
            bonemealSlotCurrent = bonemealSlot;
        }

        lastInventoryScanTime = currentTime;
    }

    // 检查位置附近是否有水
    private boolean hasWaterNearby(BlockPos pos) {
        int radius = 4; // 9x9范围的半径是4
        int px = pos.getX(), py = pos.getY(), pz = pos.getZ();
        // 性能：复用同一个 MutableBlockPos，原实现每次调用最多分配 162 个 BlockPos，
        // 而本方法在 canTillBlock 里被球体候选逐个调用（每 tick 与每帧各一遍）。
        BlockPos.MutableBlockPos checkPos = new BlockPos.MutableBlockPos();

        for (int x = -radius; x <= radius; x++) {
            for (int y = 0; y <= 1; y++) { // 检查自身高度和上一格
                for (int z = -radius; z <= radius; z++) {
                    BlockState state = mc.level.getBlockState(checkPos.set(px + x, py + y, pz + z));

                    // 检查是否是水方块、水源、水流或含水方块
                    if (isWaterBlock(state)) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    public static boolean isWaterBlock(BlockState state) {
        Block block = state.getBlock();
        // 检查是否是水方块、水源、水流或含水方块
        if (block == Blocks.WATER ||
            block == Blocks.SEAGRASS ||
            block == Blocks.TALL_SEAGRASS ||
            block == Blocks.KELP ||
            block == Blocks.KELP_PLANT ||
            block == Blocks.BUBBLE_COLUMN ||
            state.getFluidState().is(Fluids.WATER)) {
            return true;
        }

        // 可 waterlogged 且已含水
        if (state.hasProperty(WATERLOGGED) && state.getValue(WATERLOGGED)) {
            return true;
        }
        return false;
    }

    // 检查方块是否可以锄地
    private boolean canTillBlock(BlockPos pos) {
        BlockState state = mc.level.getBlockState(pos);
        Block block = state.getBlock();

        // 检查是否是泥土或草方块
        if (block == Blocks.DIRT ||
            block == Blocks.GRASS_BLOCK ||
            block == Blocks.COARSE_DIRT ||
            block == Blocks.PODZOL ||
            block == Blocks.MYCELIUM ||
            block == Blocks.ROOTED_DIRT) {

            // 检查上方是否是空气
            BlockPos abovePos = pos.above();
            BlockState aboveState = mc.level.getBlockState(abovePos);

            if (aboveState.getBlock() == Blocks.AIR) {
                // 检查附近是否有水源
                return hasWaterNearby(pos);
            }
        }

        return false;
    }

    // 检查方块是否是耕地
    private boolean isFarmland(BlockPos pos) {
        return mc.level.getBlockState(pos).getBlock() == Blocks.FARMLAND;
    }

    // 检查方块是否是灵魂沙
    private boolean isSoulSand(BlockPos pos) {
        return mc.level.getBlockState(pos).getBlock() == Blocks.SOUL_SAND;
    }

    // 检查耕地是否可以种植
    private boolean canPlantOnFarmland(BlockPos pos) {
        // 检查下方是否是耕地或灵魂沙（地狱疣）
        CropType type = cropType.get();
        if (type == CropType.NetherWart) {
            // 地狱疣需要种植在灵魂沙上
            if (!isSoulSand(pos)) {
                return false;
            }
        } else {
            // 其他作物需要耕地
            if (!isFarmland(pos)) {
                return false;
            }
        }

        // 检查上方是否是空气
        BlockPos abovePos = pos.above();
        BlockState aboveState = mc.level.getBlockState(abovePos);

        if (aboveState.getBlock() != Blocks.AIR) {
            return false;
        }
        if (!BaritoneUtil.canSeeBlockFace(pos, Direction.UP)) {
            return false;
        }
        // 检查是否有对应的种子
        switch (type) {
            case Wheat:
                return availableSeeds.containsKey(Items.WHEAT_SEEDS);
            case Carrot:
                return availableSeeds.containsKey(Items.CARROT);
            case Potato:
                return availableSeeds.containsKey(Items.POTATO);
            case Beetroot:
                return availableSeeds.containsKey(Items.BEETROOT_SEEDS);
            case Pumpkin:
                return availableSeeds.containsKey(Items.PUMPKIN_SEEDS);
            case Melon:
                return availableSeeds.containsKey(Items.MELON_SEEDS);
            case NetherWart:
                return availableSeeds.containsKey(Items.NETHER_WART);
            default:
                return false;
        }
    }

    // 检查作物是否成熟
    private boolean isCropMature(BlockPos pos) {
        BlockState state = mc.level.getBlockState(pos);
        Block block = state.getBlock();
        if (block instanceof CropBlock) {
            CropBlock crop = (CropBlock) block;
            return crop.isMaxAge(state);
        } else if (block == Blocks.MELON || block == Blocks.PUMPKIN) {
            // 南瓜和西瓜没有成熟度，直接可以收割
            return true;
        } else if (block == Blocks.CARROTS || block == Blocks.POTATOES) {
            // 胡萝卜和土豆
            return state.getValue(AGE) >= 7;
        } else if (block == Blocks.BEETROOTS) {
            // 甜菜根
            return state.getValue(BeetrootBlock.AGE) >= 3;
        } else if (block == Blocks.NETHER_WART) {
            // 甜菜根
            return state.getValue(NetherWartBlock.AGE) >= 3;
        }

        return false;
    }

    // 检查方块是否可以收割
    private boolean canHarvestBlock(BlockPos pos) {
        BlockState state = mc.level.getBlockState(pos);
        Block block = state.getBlock();

        // 检查是否是作物
        if (block instanceof CropBlock ||
            block == Blocks.MELON ||
            block == Blocks.PUMPKIN ||
            block == Blocks.CARROTS ||
            block == Blocks.POTATOES ||
            block == Blocks.NETHER_WART ||
            block == Blocks.BEETROOTS) {

            // 如果设置了仅收割成熟，则检查是否成熟
            if (harvestOnlyMature.get()) {
                return isCropMature(pos);
            }

            return true;
        }

        return false;
    }

    // 查找要锄地的位置
    private BlockPos findTillPosition() {
        if (availableTools.isEmpty()) {
            return null;
        }

        List<BlockPos> validPositions = new ArrayList<>();
        BlockPos playerPos = mc.player.blockPosition();
        List<BlockPos> nearbyPositions = WorldUtils.getSphere(playerPos, tillRange.get(), 1);

        // 遍历附近的位置，找到可以锄地的位置
        for (BlockPos pos : nearbyPositions) {
            if (canTillBlock(pos)) {
                validPositions.add(pos);
            }
        }

        if (validPositions.isEmpty()) {
            return null;
        }

        // 根据距离排序
        // 性能：用平方距离排序，顺序与并列时的先后完全一致，但省掉 O(n log n) 次开方（每 tick 要跑四处）。
        validPositions.sort(Comparator.comparingDouble(PlayerUtils::squaredDistanceTo));

        // 根据排序模式决定使用最近还是最远的位置
        if (sortMode.get() == SortMode.Farthest) {
            Collections.reverse(validPositions);
        }

        return validPositions.get(0);
    }

    // 查找要种植的位置
    private BlockPos findPlantPosition() {
        if (availableSeeds.isEmpty()) {
            return null;
        }

        List<BlockPos> validPositions = new ArrayList<>();
        BlockPos playerPos = mc.player.blockPosition();
        List<BlockPos> nearbyPositions = WorldUtils.getSphere(playerPos, plantRange.get(), 2);

        // 遍历附近的位置，找到可以种植的位置
        for (BlockPos pos : nearbyPositions) {
            if (canPlantOnFarmland(pos)) {
                validPositions.add(pos);
            }
        }

        if (validPositions.isEmpty()) {
            return null;
        }

        // 根据距离排序
        // 性能：用平方距离排序，顺序与并列时的先后完全一致，但省掉 O(n log n) 次开方（每 tick 要跑四处）。
        validPositions.sort(Comparator.comparingDouble(PlayerUtils::squaredDistanceTo));

        // 根据排序模式决定使用最近还是最远的位置
        if (sortMode.get() == SortMode.Farthest) {
            Collections.reverse(validPositions);
        }

        return validPositions.get(0);
    }

    // 查找要收割的位置
    private BlockPos findHarvestPosition() {
        List<BlockPos> validPositions = new ArrayList<>();
        BlockPos playerPos = mc.player.blockPosition();
        List<BlockPos> nearbyPositions = WorldUtils.getSphere(playerPos, harvestRange.get(), 2);

        // 遍历附近的位置，找到可以收割的位置
        for (BlockPos pos : nearbyPositions) {
            if (canHarvestBlock(pos)) {
                validPositions.add(pos);
            }
        }

        if (validPositions.isEmpty()) {
            return null;
        }

        // 根据距离排序
        // 性能：用平方距离排序，顺序与并列时的先后完全一致，但省掉 O(n log n) 次开方（每 tick 要跑四处）。
        validPositions.sort(Comparator.comparingDouble(PlayerUtils::squaredDistanceTo));

        // 根据排序模式决定使用最近还是最远的位置
        if (sortMode.get() == SortMode.Farthest) {
            Collections.reverse(validPositions);
        }

        return validPositions.get(0);
    }

    // 执行锄地操作
    private void doTill(BlockPos pos) {
        // 获取锄头

        if (toolSlotCurrent == -1) {
            long currentTime = System.currentTimeMillis();
            if (currentTime - lastHoeErrorTime >= ERROR_COOLDOWN) {
                error("背包中没有找到钻石锄或下界合金锄");
                lastHoeErrorTime = currentTime;
            }
            return;
        }

        // 切换到锄头
        if (autoSwitchHoe.get()) {
            BagUtil.doSwap(toolSlotCurrent);
        }

        // 使用锄头
        BaritoneUtil.clickBlock(pos, Direction.UP, true, InteractionHand.MAIN_HAND, BaritoneUtil.SwingSide.All);

        // 切换回原来的物品
        if (autoSwitchHoe.get()) {
            BagUtil.doSwap(toolSlotCurrent);
        }
    }

    // 执行种植操作
    private void doPlant(BlockPos pos) {
        // 获取种子
        Item seed = null;
        Integer seedSlot = null;

        CropType type = cropType.get();
        switch (type) {
            case Wheat:
                seed = Items.WHEAT_SEEDS;
                break;
            case Carrot:
                seed = Items.CARROT;
                break;
            case Potato:
                seed = Items.POTATO;
                break;
            case Beetroot:
                seed = Items.BEETROOT_SEEDS;
                break;
            case Pumpkin:
                seed = Items.PUMPKIN_SEEDS;
                break;
            case Melon:
                seed = Items.MELON_SEEDS;
                break;
            case NetherWart:
                seed = Items.NETHER_WART;
                break;
        }

        if (seed != null) {
            seedSlot = availableSeeds.get(seed);
        }

        if (seedSlot == null) {
            long currentTime = System.currentTimeMillis();
            if (currentTime - lastSeedErrorTime >= ERROR_COOLDOWN) {
                error("背包中没有找到选定的种子");
                lastSeedErrorTime = currentTime;
            }
            return;
        }

        // 切换到种子
        if (autoSwitchSeeds.get()) {
            BagUtil.doSwap(seedSlot);
        }

        // 种植种子（在耕地上方）
        BlockPos plantPos = pos;
        BaritoneUtil.clickBlock(plantPos, Direction.UP, true, InteractionHand.MAIN_HAND, BaritoneUtil.SwingSide.All);

        // 切换回原来的物品
        if (autoSwitchSeeds.get()) {
            BagUtil.doSwap(seedSlot);
        }
    }

    // 执行收割操作
    private void doHarvest(BlockPos pos) {
        // 如果有锄头，切换到锄头再收割
        boolean shouldSwitchToHoe = autoSwitchHoe.get() && toolSlotCurrent != -1;

        if (shouldSwitchToHoe) {
            BagUtil.doSwap(toolSlotCurrent);
        }

        // 使用左键破坏作物方块
        BlockUtils.breakBlock(pos, true);

        // 切换回原来的物品
        if (shouldSwitchToHoe) {
            BagUtil.doSwap(toolSlotCurrent);
        }
    }

    // 查找要使用骨粉的位置
    private BlockPos findBonemealPosition() {
        if (availableBonemeal.isEmpty()) {
            return null;
        }

        List<BlockPos> validPositions = new ArrayList<>();
        BlockPos playerPos = mc.player.blockPosition();
        List<BlockPos> nearbyPositions = WorldUtils.getSphere(playerPos, bonemealRange.get(), 2);

        // 遍历附近的位置，找到可以使用骨粉的位置
        for (BlockPos pos : nearbyPositions) {
            if (canBonemealBlock(pos)) {
                validPositions.add(pos);
            }
        }

        if (validPositions.isEmpty()) {
            return null;
        }

        // 根据距离排序
        // 性能：用平方距离排序，顺序与并列时的先后完全一致，但省掉 O(n log n) 次开方（每 tick 要跑四处）。
        validPositions.sort(Comparator.comparingDouble(PlayerUtils::squaredDistanceTo));

        // 根据排序模式决定使用最近还是最远的位置
        if (sortMode.get() == SortMode.Farthest) {
            Collections.reverse(validPositions);
        }

        return validPositions.get(0);
    }

    // 检查方块是否可以使用骨粉
    private boolean canBonemealBlock(BlockPos pos) {
        BlockState state = mc.level.getBlockState(pos);
        Block block = state.getBlock();

        // 检查是否是作物
        if (block instanceof CropBlock ||
            block == Blocks.MELON_STEM ||
            block == Blocks.PUMPKIN_STEM ||
            block == Blocks.CARROTS ||
            block == Blocks.POTATOES ||
            block == Blocks.NETHER_WART ||
            block == Blocks.BEETROOTS) {

            // 检查是否未成熟
            if (!isCropMature(pos)) {
                // 检查骨粉使用次数
                int currentCount = bonemealCount.getOrDefault(pos, 0);
                return currentCount < maxBonemealAttempts.get();
            }
        }

        return false;
    }

    // 执行骨粉使用操作
    private void doBonemeal(BlockPos pos) {
        if (bonemealSlotCurrent == -1) {
            long currentTime = System.currentTimeMillis();
            if (currentTime - lastBonemealErrorTime >= ERROR_COOLDOWN) {
                error("背包中没有找到骨粉");
                lastBonemealErrorTime = currentTime;
            }
            return;
        }

        // 切换到骨粉
        if (autoSwitchBonemeal.get()) {
            BagUtil.doSwap(bonemealSlotCurrent);
        }

        // 使用骨粉
        BaritoneUtil.clickBlock(pos, Direction.UP, true, InteractionHand.MAIN_HAND, BaritoneUtil.SwingSide.All);

        // 更新使用次数
        int currentCount = bonemealCount.getOrDefault(pos, 0);
        bonemealCount.put(pos, currentCount + 1);
        // 切换回原来的物品
        if (autoSwitchBonemeal.get()) {
            BagUtil.doSwap(bonemealSlotCurrent);
        }
    }

    // 工作模式枚举
    public enum WorkMode {
        All("全部功能"),
        Till("仅锄地"),
        Plant("仅种植"),
        Harvest("仅收割");

        private final String displayName;

        WorkMode(String displayName) {
            this.displayName = displayName;
        }

        @Override
        public String toString() {
            return displayName;
        }
    }

    // 作物类型枚举
    public enum CropType {
        Wheat("小麦"),
        Carrot("胡萝卜"),
        Potato("土豆"),
        Beetroot("甜菜根"),
        Pumpkin("南瓜"),
        Melon("西瓜"),
        NetherWart("地狱疣");

        private final String displayName;

        CropType(String displayName) {
            this.displayName = displayName;
        }

        @Override
        public String toString() {
            return displayName;
        }
    }

    // 排序模式枚举
    public enum SortMode {
        Closest("最近优先"),
        Farthest("最远优先");

        private final String displayName;

        SortMode(String displayName) {
            this.displayName = displayName;
        }

        @Override
        public String toString() {
            return displayName;
        }
    }

    @EventHandler
    private void onRender3D(Render3DEvent event) {
        if (!render.get() || mc.player == null || mc.level == null) return;

        WorkMode mode = workMode.get();

        // 渲染要锄地的位置
        if (mode == WorkMode.All || mode == WorkMode.Till) {
            renderTillPositions(event);
        }

        // 渲染要种植的位置
        if (mode == WorkMode.All || mode == WorkMode.Plant) {
            renderPlantPositions(event);
        }

        // 渲染要收割的位置
        if (mode == WorkMode.All || mode == WorkMode.Harvest) {
            renderHarvestPositions(event);
        }

        // 渲染要使用骨粉的位置（独立于工作模式）
        if (useBonemeal.get()) {
            renderBonemealPositions(event);
        }
    }

    private void renderTillPositions(Render3DEvent event) {
        if (availableTools.isEmpty()) return;

        BlockPos playerPos = mc.player.blockPosition();
        List<BlockPos> nearbyPositions = WorldUtils.getSphere(playerPos, tillRange.get(), 1);

        for (BlockPos pos : nearbyPositions) {
            if (canTillBlock(pos)) {
                renderBlock(event, pos, tillSideColor.get(), tillLineColor.get());
            }
        }
    }

    private void renderPlantPositions(Render3DEvent event) {
        if (availableSeeds.isEmpty()) return;

        BlockPos playerPos = mc.player.blockPosition();
        List<BlockPos> nearbyPositions = WorldUtils.getSphere(playerPos, plantRange.get(), 2);

        for (BlockPos pos : nearbyPositions) {
            if (canPlantOnFarmland(pos)) {
                // 渲染耕地或灵魂沙上的空气位置（种子将要种植的位置）
                renderBlock(event, pos.above(), plantSideColor.get(), plantLineColor.get());
            }
        }
    }

    private void renderHarvestPositions(Render3DEvent event) {
        BlockPos playerPos = mc.player.blockPosition();
        List<BlockPos> nearbyPositions = WorldUtils.getSphere(playerPos, harvestRange.get(), 2);

        for (BlockPos pos : nearbyPositions) {
            if (canHarvestBlock(pos)) {
                renderBlock(event, pos, harvestSideColor.get(), harvestLineColor.get());
            }
        }
    }

    private void renderBonemealPositions(Render3DEvent event) {
        if (availableBonemeal.isEmpty()) return;

        BlockPos playerPos = mc.player.blockPosition();
        List<BlockPos> nearbyPositions = WorldUtils.getSphere(playerPos, bonemealRange.get(), 2);

        for (BlockPos pos : nearbyPositions) {
            if (canBonemealBlock(pos)) {
                renderBlock(event, pos, bonemealSideColor.get(), bonemealLineColor.get());
            }
        }
    }

    private void renderBlock(Render3DEvent event, BlockPos pos, SettingColor sideColor, SettingColor lineColor) {
        double x1 = pos.getX();
        double y1 = pos.getY();
        double z1 = pos.getZ();
        double x2 = pos.getX() + 1;
        double y2 = pos.getY() + 1;
        double z2 = pos.getZ() + 1;

        event.renderer.box(x1, y1, z1, x2, y2, z2, sideColor, lineColor, shapeMode.get(), 0);
    }
}
