/*
 * 本文件属于 meteor-miku 项目：https://github.com/mikumiku7/meteor-miku
 * meteor-miku 是 meteor-rejects 在 Minecraft 26.1 / Fabric 上的移植版本。
 *
 * Copyright (C) 2024-2026 XC_XinCheng
 *
 * SPDX-License-Identifier: GPL-3.0-only
 *
 * 本程序是自由软件：你可以依据 GNU 通用公共许可证（GNU GPL）第 3 版的条款
 * 重新发布和/或修改它。
 *
 * 本程序基于“有用”的期望分发，但不提供任何担保，甚至不提供适销性或特定
 * 用途适用性的默示担保。详见 GNU 通用公共许可证。
 *
 * 你应当已随本程序收到一份 GNU 通用公共许可证副本；如果没有，请见
 * <https://www.gnu.org/licenses/>。
 */
package com.github.mikumiku.addon.modules;

import com.github.mikumiku.addon.BaseModule;
import com.github.mikumiku.addon.util.BagUtil;
import com.github.mikumiku.addon.util.BaritoneUtil;
import com.github.mikumiku.addon.util.Via;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.utils.misc.Pool;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.BlockIterator;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.item.Items;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class AutoWither extends BaseModule {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRender = settings.createGroup("渲染");

    // 通用设置

    private final Setting<Integer> horizontalRadius = sgGeneral.add(new IntSetting.Builder()
        .name("水平半径")
        .description("放置的水平半径")
        .defaultValue(4)
        .min(0)
        .sliderMax(6)
        .build()
    );

    private final Setting<Integer> verticalRadius = sgGeneral.add(new IntSetting.Builder()
        .name("垂直半径")
        .description("放置的垂直半径")
        .defaultValue(3)
        .min(0)
        .sliderMax(6)
        .build()
    );

    private final Setting<Priority> priority = sgGeneral.add(new EnumSetting.Builder<Priority>()
        .name("优先级")
        .description("优先级")
        .defaultValue(Priority.随机)
        .build()
    );

    private final Setting<Integer> witherDelay = sgGeneral.add(new IntSetting.Builder()
        .name("凋零延迟")
        .description("凋零放置之间的延迟（刻）")
        .defaultValue(1)
        .min(1)
        .sliderMax(10)
        .build()
    );

    private final Setting<Integer> blockDelay = sgGeneral.add(new IntSetting.Builder()
        .name("方块延迟")
        .description("方块放置之间的延迟（刻）")
        .defaultValue(1)
        .min(0)
        .sliderMax(10)
        .build()
    );

    private final Setting<Boolean> rotate = sgGeneral.add(new BoolSetting.Builder()
        .name("旋转")
        .description("建造时是否旋转")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> turnOff = sgGeneral.add(new BoolSetting.Builder()
        .name("自动关闭")
        .description("建造单个凋零怪后自动关闭")
        .defaultValue(true)
        .build()
    );

    // 渲染设置

    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
        .name("形状模式")
        .description("形状的渲染方式")
        .defaultValue(ShapeMode.Both)
        .build()
    );

    private final Setting<SettingColor> sideColor = sgRender.add(new ColorSetting.Builder()
        .name("侧面颜色")
        .description("目标方块渲染的侧面颜色")
        .defaultValue(new SettingColor(197, 137, 232, 10))
        .build()
    );
    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder()
        .name("线条颜色")
        .description("目标方块渲染的线条颜色")
        .defaultValue(new SettingColor(197, 137, 232))
        .build()
    );

    private final Pool<Wither> witherPool = new Pool<>(Wither::new);
    private final ArrayList<Wither> withers = new ArrayList<>();
    private Wither wither;

    private int witherTicksWaited, blockTicksWaited;

    public AutoWither() {
        super(CATEGORY_MIKU_BUILD,"自动放凋零", "自动建造凋零");
    }

    @Override
    public void onActivate() {
        super.onActivate();
    }

    @Override
    public void onDeactivate() {
        wither = null;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (wither == null) {
            // 延迟
            if (witherTicksWaited < witherDelay.get() - 1) {
                return;
            }

            // 清空池和列表
            for (Wither wither : withers) witherPool.free(wither);
            withers.clear();

            // 注册
            BlockIterator.register(horizontalRadius.get(), verticalRadius.get(), (blockPos, blockState) -> {
                Direction dir = Via.getOppositeDirectionTo(blockPos);
                if (isValidSpawn(blockPos, dir)) withers.add(witherPool.get().set(blockPos, dir));
            });
        }
    }

    @EventHandler
    private void onPostTick(TickEvent.Post event) {
        if (wither == null) {
            // 延迟
            if (witherTicksWaited < witherDelay.get() - 1) {
                witherTicksWaited++;
                return;
            }


            if (withers.isEmpty()) return;

            // 排序
            switch (priority.get()) {
                case 最近:
                    withers.sort(Comparator.comparingDouble(w -> PlayerUtils.distanceTo(w.foot)));
                case 最远:
                    withers.sort((w1, w2) -> {
                        int sort = Double.compare(PlayerUtils.distanceTo(w1.foot), PlayerUtils.distanceTo(w2.foot));
                        if (sort == 0) return 0;
                        return sort > 0 ? -1 : 1;
                    });
                case 随机:
                    Collections.shuffle(withers);
            }

            wither = withers.get(0);
        }

        // 灵魂沙/土和头颅槽位
        int slotSand = BagUtil.findItemInventorySlot(Items.SOUL_SAND);
        int slotSoil = BagUtil.findItemInventorySlot(Items.SOUL_SOIL);
        int slotHead = BagUtil.findItemInventorySlot(Items.WITHER_SKELETON_SKULL);

        slotSand = slotSand == -1 ? slotSoil : slotSand;

        if (slotSand == -1 && slotSoil == -1 || slotHead == -1) {
            error("背包中没有足够的资源");
            toggle();
            return;
        }

        // 建造
        if (blockDelay.get() == 0) {
            // 一 tick 内完成所有
            // 身体
            placeBlock(wither.foot, slotSand);
            placeBlock(wither.foot.above(), slotSand);
            placeBlock(wither.foot.above().relative(wither.axis, -1), slotSand);
            placeBlock(wither.foot.above().relative(wither.axis, 1), slotSand);

            placeBlock(wither.foot.above().above(), slotHead);
            placeBlock(wither.foot.above().above().relative(wither.axis, -1), slotHead);
            placeBlock(wither.foot.above().above().relative(wither.axis, 1), slotHead);


            // 自动关闭
            if (turnOff.get()) {
                wither = null;
                toggle();
            }

        } else {
            // 延迟
            if (blockTicksWaited < blockDelay.get() - 1) {
                blockTicksWaited++;
                return;
            }

            switch (wither.stage) {
                case 0:
                    placeBlock(wither.foot, slotSand);
                    wither.stage++;
                    break;
                case 1:
                    placeBlock(wither.foot.above(), slotSand);
                    wither.stage++;
                    break;
                case 2:
                    placeBlock(wither.foot.above().relative(wither.axis, -1), slotSand);

                    wither.stage++;
                    break;
                case 3:
                    placeBlock(wither.foot.above().relative(wither.axis, 1), slotSand);

                    wither.stage++;
                    break;
                case 4:
                    placeBlock(wither.foot.above().above(), slotHead);
                    wither.stage++;
                    break;
                case 5:
                    placeBlock(wither.foot.above().above().relative(wither.axis, -1), slotHead);
                    wither.stage++;
                    break;
                case 6:
                    placeBlock(wither.foot.above().above().relative(wither.axis, 1), slotHead);
                    wither.stage++;
                    break;
                case 7:
                    // 自动关闭
                    if (turnOff.get()) {
                        wither = null;
                        toggle();
                    }
                    break;
            }
        }


        witherTicksWaited = 0;
    }

    public void placeBlock(BlockPos blockPos, int slot) {
        BagUtil.doSwap(slot);
        BaritoneUtil.placeBlock(blockPos);
        BagUtil.doSwap(slot);
        BagUtil.sync();
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (wither == null) return;

        // 身体
        event.renderer.box(wither.foot, sideColor.get(), lineColor.get(), shapeMode.get(), 0);
        event.renderer.box(wither.foot.above(), sideColor.get(), lineColor.get(), shapeMode.get(), 0);
        event.renderer.box(wither.foot.above().relative(wither.axis, -1), sideColor.get(), lineColor.get(), shapeMode.get(), 0);
        event.renderer.box(wither.foot.above().relative(wither.axis, 1), sideColor.get(), lineColor.get(), shapeMode.get(), 0);

        // 头部
        BlockPos midHead = wither.foot.above().above();
        BlockPos leftHead = wither.foot.above().above().relative(wither.axis, -1);
        BlockPos rightHead = wither.foot.above().above().relative(wither.axis, 1);

        event.renderer.box((double) midHead.getX() + 0.2, midHead.getX(), (double) midHead.getX() + 0.2,
            (double) midHead.getX() + 0.8, (double) midHead.getX() + 0.7, (double) midHead.getX() + 0.8,
            sideColor.get(), lineColor.get(), shapeMode.get(), 0);

        event.renderer.box((double) leftHead.getX() + 0.2, leftHead.getX(), (double) leftHead.getX() + 0.2,
            (double) leftHead.getX() + 0.8, (double) leftHead.getX() + 0.7, (double) leftHead.getX() + 0.8,
            sideColor.get(), lineColor.get(), shapeMode.get(), 0);

        event.renderer.box((double) rightHead.getX() + 0.2, rightHead.getX(), (double) rightHead.getX() + 0.2,
            (double) rightHead.getX() + 0.8, (double) rightHead.getX() + 0.7, (double) rightHead.getX() + 0.8,
            sideColor.get(), lineColor.get(), shapeMode.get(), 0);
    }

    private boolean isValidSpawn(BlockPos blockPos, Direction direction) {
        // 凋零怪是 3x3x1

        // 检查 y > (255 - 3)
        // 因为凋零怪有 3 个方块高
        if (blockPos.getY() > 252) return false;

        // 根据方向确定宽度
        int widthX = 0;
        int widthZ = 0;

        if (direction == Direction.EAST || direction == Direction.WEST) widthZ = 1;
        if (direction == Direction.NORTH || direction == Direction.SOUTH) widthX = 1;


        // 检查非空气方块和实体
        BlockPos.MutableBlockPos bp = new BlockPos.MutableBlockPos();
        for (int x = blockPos.getX() - widthX; x <= blockPos.getX() + widthX; x++) {
            for (int z = blockPos.getZ() - widthZ; z <= blockPos.getZ(); z++) {
                for (int y = blockPos.getY(); y <= blockPos.getY() + 2; y++) {
                    bp.set(x, y, z);
                    if (!mc.level.getBlockState(bp).canBeReplaced()) return false;
                    if (!mc.level.isUnobstructed(Blocks.STONE.defaultBlockState(), bp, CollisionContext.empty())) return false;
                }
            }
        }

        return true;
    }

    public enum Priority {
        最近,
        最远,
        随机
    }

    private static class Wither {
        public int stage;
        // 0 = 脚部
        // 1 = 身体中部
        // 2 = 左臂
        // 3 = 右臂
        // 4 = 中间头部
        // 5 = 左头部
        // 6 = 右头部
        // 7 = 结束
        public BlockPos.MutableBlockPos foot = new BlockPos.MutableBlockPos();
        public Direction facing;
        public Direction.Axis axis;

        public Wither set(BlockPos pos, Direction dir) {
            this.stage = 0;
            this.foot.set(pos);
            this.facing = dir;
            this.axis = dir.getAxis();

            return this;
        }
    }
}
