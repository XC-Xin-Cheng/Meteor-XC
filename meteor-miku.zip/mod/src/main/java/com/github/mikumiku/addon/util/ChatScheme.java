/*
 * 本文件属于 meteor-miku 项目：https://github.com/mikumiku7/meteor-miku
 * meteor-miku 是 meteor-rejects 在 Minecraft 26.1 / Fabric 上的移植版本。
 *
 * Copyright (C) 2024-2026 XC_XinCheng
 *
 * SPDX-License-Identifier: GPL-3.0-only
 *
 * 本程序是自由软件：你可以依据 GNU 通用公共许可证（GNU GPL）第 3 版的条款
 * 重新发布和/或修改它。
 *
 * 本程序基于“有用”的期望分发，但不提供任何担保，甚至不提供适销性或特定
 * 用途适用性的默示担保。详见 GNU 通用公共许可证。
 *
 * 你应当已随本程序收到一份 GNU 通用公共许可证副本；如果没有，请见
 * <https://www.gnu.org/licenses/>。
 */
package com.github.mikumiku.addon.util;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * 「Miku 聊天」里的一套聊天方案。
 *
 * <p>一套方案 = 一个方案名 + 一段发送间隔 + 若干条消息。多套方案可以同时启用，
 * 各自的间隔与消息互相独立，例如“打招呼”和“夸夸”两套同时跑。</p>
 *
 * <p>消息里有 {@code %s} 时，附近必须能找到一个玩家，才会把 {@code %s} 替换成
 * 那名玩家的名字（和「自动社交」的写法一致）；找不到玩家时，这套方案这一次就先不发，
 * 不会把 {@code %s} 原样发到聊天栏。</p>
 *
 * <p>{@code nextSendAt} / {@code index} / {@code wasEnabled} 是运行期状态，
 * 只在内存里用，不进配置（{@link #toTag()} 不写它们）。</p>
 */
public class ChatScheme {

    /** 消息列表在配置里的分隔符（界面上一个输入框里填多条消息时用）。 */
    public static final String MESSAGE_SEPARATOR = "|";

    // ---- 配置项（会保存） ----
    /** 方案名，只用于在界面上区分。 */
    public String name = "新方案";
    /** 是否启用这套方案；多套可以同时启用。 */
    public boolean enabled = true;
    /** 这套方案两条消息之间至少间隔多少毫秒。 */
    public int intervalMs = 1500;
    /** 是否随机挑消息（不勾选则按顺序轮播）。 */
    public boolean random = false;
    /** 随机挑消息时，是否避免和上一条重复（即「自动社交」的挑选方式）。 */
    public boolean avoidRepeat = false;
    /** 这套方案要发的消息，至少一条。 */
    public List<String> messages = new ArrayList<>();

    // ---- 运行期状态（不保存） ----
    /** 下一条消息该在什么时间发出（毫秒时间戳）。 */
    public transient long nextSendAt = 0L;
    /** 顺序发送时轮到第几条。 */
    public transient int index = 0;
    /** 随机发送时上一条用的是第几条，用来避免连续重复；-1 表示还没发过。 */
    public transient int lastPicked = -1;
    /** 上一 tick 的启用状态，用来识别“刚被勾上”并重新计时。 */
    public transient boolean wasEnabled = false;

    private static final Random RANDOM = new Random();

    public ChatScheme() {
    }

    public ChatScheme(String name) {
        this.name = name;
    }

    public ChatScheme(String name, boolean enabled, int intervalMs, boolean random, String... messages) {
        this.name = name;
        this.enabled = enabled;
        this.intervalMs = intervalMs;
        this.random = random;
        for (String message : messages) {
            if (message != null && !message.isBlank()) this.messages.add(message);
        }
    }

    /** 发送间隔，限制在 200 ms ~ 10 min，避免手滑填 0 刷屏或填太大永远不发。 */
    public int clampedIntervalMs() {
        return Math.max(200, Math.min(600_000, intervalMs));
    }

    /** 这套方案现在有没有可发的消息。 */
    public boolean hasMessages() {
        return !messages.isEmpty();
    }

    /** 把运行期状态清干净：{@code now} 之前不发，并回到第一条。 */
    public void resetRuntime(long now) {
        nextSendAt = now + clampedIntervalMs();
        index = 0;
        lastPicked = -1;
        wasEnabled = enabled;
    }

    /**
     * 取这一次要发的消息原文（还没做 {@code %s} 替换）。
     *
     * @return 消息原文；没有消息时返回 {@code null}
     */
    public String pickMessage() {
        if (messages.isEmpty()) return null;

        int size = messages.size();
        if (random) {
            int picked = RANDOM.nextInt(size);
            // 和「自动社交」一样：随机时尽量不和上一条撞车，避免连着喊同一句
            if (avoidRepeat && size > 1 && picked == lastPicked) {
                picked = (picked + 1 + RANDOM.nextInt(size - 1)) % size;
            }
            lastPicked = picked;
            return messages.get(picked);
        }

        if (index < 0 || index >= size) index = 0;
        String message = messages.get(index);
        index = (index + 1) % size;
        return message;
    }

    /** 复制一份配置项（运行期状态不带过去）。 */
    public ChatScheme copy() {
        ChatScheme copy = new ChatScheme(name);
        copy.enabled = enabled;
        copy.intervalMs = intervalMs;
        copy.random = random;
        copy.avoidRepeat = avoidRepeat;
        copy.messages = new ArrayList<>(messages);
        return copy;
    }

    /** 把消息列表拼成界面上那个输入框里的文本。 */
    public String messagesAsText() {
        return String.join(" " + MESSAGE_SEPARATOR + " ", messages);
    }

    /** 把界面上输入的文本拆回消息列表并把 {@code %s} 之类的空白收拾干净。 */
    public void setMessagesFromText(String text) {
        List<String> parsed = new ArrayList<>();
        if (text != null) {
            for (String part : text.split("[|\\n\\r]")) {
                String message = part.trim();
                if (!message.isEmpty()) parsed.add(message);
            }
        }
        this.messages = parsed;
    }

    public CompoundTag toTag() {
        CompoundTag tag = new CompoundTag();
        tag.putString("name", name == null ? "方案" : name);
        tag.putBoolean("enabled", enabled);
        tag.putInt("intervalMs", intervalMs);
        tag.putBoolean("random", random);
        tag.putBoolean("avoidRepeat", avoidRepeat);

        ListTag listTag = new ListTag();
        for (String message : messages) {
            CompoundTag entry = new CompoundTag();
            entry.putString("m", message);
            listTag.add(entry);
        }
        tag.put("messages", listTag);
        return tag;
    }

    public static ChatScheme fromTag(CompoundTag tag) {
        ChatScheme scheme = new ChatScheme();
        scheme.name = tag.getStringOr("name", "方案");
        scheme.enabled = tag.getBooleanOr("enabled", true);
        scheme.intervalMs = tag.getIntOr("intervalMs", 1500);
        scheme.random = tag.getBooleanOr("random", false);
        scheme.avoidRepeat = tag.getBooleanOr("avoidRepeat", false);

        ListTag listTag = tag.getList("messages").orElse(new ListTag());
        for (Tag entry : listTag) {
            entry.asCompound().ifPresent(compound -> {
                String message = compound.getStringOr("m", "");
                if (!message.isEmpty()) scheme.messages.add(message);
            });
        }
        return scheme;
    }

    /**
     * 序列化成 Miku-Chat.txt 里的一行，格式：
     * {@code on1 方案名 间隔ms 消息 on2 on3}（消息内部可带空格，多条用 {@code |} 分隔）。
     */
    public String toLine() {
        String safeName = (name == null || name.isBlank()) ? "方案" : name.trim().replaceAll("\\s+", "_");
        return (enabled ? "on1" : "off1") + " "
            + safeName + " "
            + clampedIntervalMs() + " "
            + String.join(MESSAGE_SEPARATOR, messages) + " "
            + (random ? "on2" : "off2") + " "
            + (avoidRepeat ? "on3" : "off3");
    }

    /**
     * 解析 Miku-Chat.txt 里的一行；空行、注释行、字段不足的行返回 {@code null}。
     *
     * <p>消息允许带空格，所以从第 4 个字段到「倒数第 2 个字段」之间的内容都算消息，
     * 最后两个字段固定是 {@code on2/off2}（随机）和 {@code on3/off3}（不重复）。</p>
     */
    public static ChatScheme fromLine(String line) {
        if (line == null) return null;
        String trimmed = line.trim();
        if (trimmed.isEmpty() || trimmed.startsWith("#")) return null;

        String[] fields = trimmed.split("\\s+");
        if (fields.length < 3) return null;

        ChatScheme scheme = new ChatScheme();
        scheme.enabled = isOn(fields[0]);
        scheme.name = fields[1];

        try {
            scheme.intervalMs = Math.max(200, Math.min(600_000, Integer.parseInt(fields[2])));
        } catch (NumberFormatException ignored) {
            scheme.intervalMs = 1500;
        }

        StringBuilder message = new StringBuilder();
        int messageEnd = fields.length; // 不含
        if (fields.length >= 5) {
            scheme.random = isOn(fields[fields.length - 2]);
            scheme.avoidRepeat = isOn(fields[fields.length - 1]);
            messageEnd = fields.length - 2;
        }
        for (int i = 3; i < messageEnd; i++) {
            if (message.length() > 0) message.append(' ');
            message.append(fields[i]);
        }
        scheme.setMessagesFromText(message.toString());

        return scheme;
    }

    /** {@code on1/on2/on3/on/true/1} 视为开，其余视为关。 */
    private static boolean isOn(String token) {
        if (token == null) return false;
        String value = token.trim().toLowerCase(Locale.ROOT);
        return value.startsWith("on") || value.equals("true") || value.equals("1") || value.equals("yes");
    }

    /** 生成一个可读的方案描述，用于配置里的字符串形式与日志。 */
    @Override
    public String toString() {
        return String.format(Locale.ROOT, "%s[%dms %d条%s]",
            name, clampedIntervalMs(), messages.size(),
            random ? " 随机" : " 顺序");
    }
}
