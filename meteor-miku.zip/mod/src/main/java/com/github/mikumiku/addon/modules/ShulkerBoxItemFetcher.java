/*
 * 本文件属于 meteor-miku 项目：https://github.com/mikumiku7/meteor-miku
 * meteor-miku 是 meteor-rejects 在 Minecraft 26.1 / Fabric 上的移植版本。
 *
 * Copyright (C) 2024-2026 XC_XinCheng
 *
 * SPDX-License-Identifier: GPL-3.0-only
 *
 * 本程序是自由软件：你可以依据 GNU 通用公共许可证（GNU GPL）第 3 版的条款
 * 重新发布和/或修改它。
 *
 * 本程序基于“有用”的期望分发，但不提供任何担保，甚至不提供适销性或特定
 * 用途适用性的默示担保。详见 GNU 通用公共许可证。
 *
 * 你应当已随本程序收到一份 GNU 通用公共许可证副本；如果没有，请见
 * <https://www.gnu.org/licenses/>。
 */
package com.github.mikumiku.addon.modules;

import baritone.api.BaritoneAPI;
import baritone.api.IBaritone;
import baritone.api.pathing.goals.GoalBlock;
import com.github.mikumiku.addon.BaseModule;
import com.github.mikumiku.addon.util.BagUtil;
import com.github.mikumiku.addon.util.BaritoneUtil;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.pathing.NopPathManager;
import meteordevelopment.meteorclient.pathing.PathManagers;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class ShulkerBoxItemFetcher extends BaseModule {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgSettings = settings.createGroup("设置");
    IBaritone baritone;

    // Settings
    public final Setting<Item> targetItem = sgGeneral.add(new ItemSetting.Builder()
        .name("目标物品")
        .description("要从潜影盒中获取的物品。")
        .defaultValue(Items.COBBLESTONE)
        .build()
    );

    public final Setting<Integer> delay = sgSettings.add(new IntSetting.Builder()
        .name("延迟")
        .description("操作之间的延迟（tick）。")
        .defaultValue(2)
        .min(1)
        .max(20)
        .build()
    );

    public final Setting<Boolean> autoClose = sgSettings.add(new BoolSetting.Builder()
        .name("自动关闭")
        .description("完成后自动关闭模块。")
        .defaultValue(true)
        .build()
    );

    public final Setting<Boolean> logActions = sgSettings.add(new BoolSetting.Builder()
        .name("记录操作")
        .description("在聊天栏记录操作日志。")
        .defaultValue(true)
        .build()
    );

    public final Setting<Boolean> autoRotate = sgSettings.add(new BoolSetting.Builder()
        .name("自动转头")
        .description("交互时自动转头看向方块。")
        .defaultValue(true)
        .build()
    );

    public final Setting<Boolean> debugMode = sgSettings.add(new BoolSetting.Builder()
        .name("调试模式")
        .description("启用详细的调试日志。")
        .defaultValue(false)
        .build()
    );

    public final Setting<Boolean> elytraExchange = sgSettings.add(new BoolSetting.Builder()
        .name("鞘翅交换")
        .description("鞘翅交换逻辑，旧的存起来。")
        .defaultValue(true)
        .build()
    );

    public final Setting<Boolean> specifyAmount = sgSettings.add(new BoolSetting.Builder()
        .name("指定数量")
        .description("是否只提取指定数量的物品。")
        .defaultValue(false)
        .build()
    );

    public final Setting<Integer> extractAmount = sgSettings.add(new IntSetting.Builder()
        .name("提取数量（组）")
        .description("要提取的物品组数（一组64个）。")
        .defaultValue(1)
        .min(1)
        .max(64)
        .visible(() -> specifyAmount.get())
        .build()
    );

    // Internal state
    public enum State {
        SEARCHING_SHULKER,
        PLACING_SHULKER,
        OPENING_SHULKER,
        EXTRACTING_ITEMS,
        CLOSING_CONTAINER,
        BREAKING_SHULKER,
        PICKING_UP_SHULKER,
        FINISHED
    }

    public State currentState = State.SEARCHING_SHULKER;
    public int tickCounter = 0;
    public int shulkerSlot = -1;
    public BlockPos shulkerPos = null;
    public ItemStack shulkerBoxItem = null;
    public boolean isProcessing = false;
    public int stateTimeout = 0;
    public static final int MAX_STATE_TIMEOUT = 100; // 5 seconds at 20 TPS
    public boolean hasRotated = false; // Track if we've rotated to look at the shulker box
    public int itemsExtracted = 0; // Track how many items have been extracted

    // Pickup tracking (参照 MassExtractor#tickPickupDrop 的追逐机制)
    private ItemEntity pickupDrop = null;       // 当前正在追逐的掉落物实体
    private boolean pickupPathed = false;       // 是否已发出寻路指令
    private int pickupSettleTicks = 0;          // 等待掉落物落地的 tick 计数
    private BlockPos pickupGoal = null;         // 上次寻路到的目标方块（用于检测漂移）
    private int pickupAttempts = 0;             // 总等待 tick 计数（超时上限）
    private int pickupBefore = 0;               // 打破前背包中潜影盒的数量
    private static final int PICKUP_SETTLE_TICKS = 20;  // 等掉落物落地最多 1 秒
    private static final int PICKUP_TIMEOUT_TICKS = 20 * 10; // 10 秒超时放弃

    public ShulkerBoxItemFetcher() {
        super("一键补给", "自动从潜影盒中获取指定物品。自动放盒，取物，打盒，捡盒");
        baritone = BaritoneAPI.getProvider().getPrimaryBaritone();
    }

    @Override
    public void onActivate() {
        if (mc.player == null || mc.level == null) {
            if (logActions.get()) error("玩家或世界为空！");
            toggle();
            return;
        }

        if (PathManagers.get() instanceof NopPathManager) {
            info("需要 Baritone 自动寻路");
            toggle();
            return;
        }


        currentState = State.SEARCHING_SHULKER;
        tickCounter = 0;
        shulkerSlot = -1;
        shulkerPos = null;
        shulkerBoxItem = null;
        isProcessing = false;
        stateTimeout = 0;
        hasRotated = false;
        itemsExtracted = 0;

        if (logActions.get()) {
            info("开始寻找潜影盒中的 " + targetItem.get().getName(targetItem.get().getDefaultInstance()).getString());
        }
    }

    @Override
    public void onDeactivate() {
        if (logActions.get()) {
            info("潜影盒物品获取器已关闭");
        }
        resetState();
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.level == null) return;

        tickCounter++;
        if (tickCounter < delay.get()) return;
        tickCounter = 0;

        if (isProcessing) return;

        // Check for state timeout
        stateTimeout++;
        if (stateTimeout > MAX_STATE_TIMEOUT) {
            if (logActions.get()) {
                error("状态超时: " + currentState.name() + " (已等待 " + stateTimeout + " 刻)");
            }
            changeState(State.FINISHED);
            return;
        }

        if (debugMode.get()) {
            info("当前状态: " + currentState.name() + " (Tick: " + tickCounter + ", 超时: " + stateTimeout + ")");
        }

        switch (currentState) {
            case SEARCHING_SHULKER -> searchForShulkerBox();
            case PLACING_SHULKER -> placeShulkerBox();
            case OPENING_SHULKER -> openShulkerBox();
            case EXTRACTING_ITEMS -> extractItems();
            case CLOSING_CONTAINER -> closeContainer();
            case BREAKING_SHULKER -> breakShulkerBox();
            case PICKING_UP_SHULKER -> pickUpShulkerBox();
            case FINISHED -> finishProcess();
        }
    }

    private void searchForShulkerBox() {
        if (logActions.get()) info("正在搜索库存中的潜影盒...");

        shulkerSlot = BagUtil.findItemInventorySlot(stack -> {
            if (stack.isEmpty()) return false;
            if (stack.getItem() instanceof BlockItem blockItem) {
                Block block = blockItem.getBlock();
                if (block instanceof ShulkerBoxBlock) {
                    // Check if this shulker box contains the target item
                    if (containsTargetItem(stack)) {
                        // Special handling for elytra exchange mode
                        if (targetItem.get() == Items.ELYTRA && elytraExchange.get()) {
                            // Check if shulker box contains high durability elytra
                            ItemContainerContents container = stack.get(DataComponents.CONTAINER);
                            if (container != null) {
                                boolean hasHighDurabilityElytra = false;
                                int elytraCount = 0;

                                for (ItemStack itemStack : container.allItemsCopyStream().toList()) {
                                    if (!itemStack.isEmpty() && itemStack.getItem() == Items.ELYTRA) {
                                        elytraCount++;
                                        if (isElytraHighDurability(itemStack)) {
                                            hasHighDurabilityElytra = true;
                                        }
                                    }
                                }

                                if (hasHighDurabilityElytra) {
                                    if (logActions.get()) {
                                        info("找到潜影盒包含高耐久鞘翅 (共 " + elytraCount + " 个鞘翅)");
                                        if (specifyAmount.get()) {
                                            int availableGroups = countTargetItemGroups(stack, targetItem.get());
                                            info("可用组数: " + availableGroups + ", 需要提取: " + extractAmount.get() + " 组");
                                        }
                                    }
                                    shulkerBoxItem = stack.copy();
                                    changeState(State.PLACING_SHULKER);
                                    return true;
                                } else if (elytraCount > 0) {
                                    if (logActions.get()) {
                                        info("跳过低耐久鞘翅潜影盒");
                                    }
                                }
                            }
                        } else {
                            // Normal handling for non-elytra items or when elytra exchange is disabled
                            if (specifyAmount.get()) {
                                int availableGroups = countTargetItemGroups(stack, targetItem.get());
                                if (availableGroups > 0) {
                                    if (logActions.get()) {
                                        info("找到潜影盒包含 " + availableGroups + " 组 " + targetItem.get().getName(targetItem.get().getDefaultInstance()).getString());
                                    }
                                    shulkerBoxItem = stack.copy();
                                    changeState(State.PLACING_SHULKER);
                                    return true;
                                }
                            } else {
                                // Not specifying amount, any shulker box with the target item is fine
                                shulkerBoxItem = stack.copy();
                                changeState(State.PLACING_SHULKER);
                                return true;
                            }
                        }
                    }
                }
            }
            return false;
        });

        // No suitable shulker box found

        if (shulkerSlot == -1) {
            if (targetItem.get() == Items.ELYTRA && elytraExchange.get()) {
                error("未找到包含高耐久鞘翅的潜影盒");
            } else {
                error("未找到包含 " + targetItem.get().getName(targetItem.get().getDefaultInstance()).getString() + " 的潜影盒");
            }
            changeState(State.FINISHED);
        }

    }

    public boolean containsTargetItem(ItemStack shulkerBox) {

        return containsTargetItem(shulkerBox, targetItem.get());
    }

    public static boolean containsTargetItem(ItemStack shulkerBox, Item targetItem) {
        // Check container component for contained items (1.21+ data components)
        ItemContainerContents container = shulkerBox.get(DataComponents.CONTAINER);
        if (container == null) return false;

        // Check each item in the container
        for (ItemStack stack : container.allItemsCopyStream().toList()) {
            if (!stack.isEmpty() && stack.getItem() == targetItem) {
                return true;
            }
        }
        return false;
    }

    public static int countTargetItemGroups(ItemStack shulkerBox, Item targetItem) {
        // Count how many groups (stacks) of target item are in the shulker box
        ItemContainerContents container = shulkerBox.get(DataComponents.CONTAINER);
        if (container == null) return 0;

        int groupCount = 0;
        for (ItemStack stack : container.allItemsCopyStream().toList()) {
            if (!stack.isEmpty() && stack.getItem() == targetItem) {
                groupCount++;
            }
        }
        return groupCount;
    }

    public static int countTargetItems(ItemStack shulkerBox, Item targetItem) {
        // Count total number of target items in the shulker box
        ItemContainerContents container = shulkerBox.get(DataComponents.CONTAINER);
        if (container == null) return 0;

        int totalCount = 0;
        for (ItemStack stack : container.allItemsCopyStream().toList()) {
            if (!stack.isEmpty() && stack.getItem() == targetItem) {
                totalCount += stack.getCount();
            }
        }
        return totalCount;
    }

    public static int getElytraDurability(ItemStack elytraStack) {
        if (elytraStack.isEmpty()) {
            return 0;
        }

        int maxDamage = elytraStack.getMaxDamage();
        int damage = elytraStack.getDamageValue();
        return maxDamage - damage; // Return remaining durability
    }

    public static boolean isElytraLowDurability(ItemStack elytraStack) {
        return getElytraDurability(elytraStack) <= 20;
    }

    public static boolean isElytraHighDurability(ItemStack elytraStack) {
        return getElytraDurability(elytraStack) > 20;
    }

    public int findLowDurabilityElytraInInventory() {
        // Find low durability elytra in player's inventory (main inventory only, not hotbar)
        for (int i = 9; i < 36; i++) {
            ItemStack stack = mc.player.getInventory().getItem(i);
            if (!stack.isEmpty() && stack.getItem() == Items.ELYTRA && isElytraLowDurability(stack)) {
                return i; // Return the slot index
            }
        }
        return -1; // No low durability elytra found
    }

    private void placeShulkerBox() {
        if (logActions.get()) info("正在放置潜影盒...");

        // Find a suitable position to place the shulker box
        BlockPos playerPos = mc.player.blockPosition();
        BlockPos placePos = findSuitablePlacePosition(playerPos);

        if (placePos == null) {
            error("找不到合适的位置放置潜影盒");
            changeState(State.FINISHED);
            return;
        }

        if (shulkerSlot != -1) {
            BaritoneUtil.placeItem(placePos, shulkerSlot);
        }

        shulkerPos = placePos;
        changeState(State.OPENING_SHULKER);

        if (logActions.get()) {
            info("潜影盒已放置在: " + placePos.toShortString());
        }
    }

    public BlockPos findSuitablePlacePosition(BlockPos playerPos) {
        // Get player's facing direction
        Direction playerFacing = mc.player.getDirection();

        // Priority order: facing direction first, then adjacent sides, then diagonals
        // 1. First try the direction player is facing
        BlockPos facingPos = playerPos.relative(playerFacing);
        if (isValidPlacePosition(facingPos)) {
            if (debugMode.get()) {
                info("找到合适位置(面朝方向): " + facingPos.toShortString());
            }
            return facingPos;
        }

        // 2. Try adjacent horizontal directions (not diagonal)
        Direction[] adjacentDirections = {
            playerFacing.getClockWise(),
            playerFacing.getCounterClockWise(),
            playerFacing.getOpposite()
        };

        for (Direction dir : adjacentDirections) {
            BlockPos testPos = playerPos.relative(dir);
            if (isValidPlacePosition(testPos)) {
                if (debugMode.get()) {
                    info("找到合适位置(相邻方向): " + testPos.toShortString());
                }
                return testPos;
            }
        }

        // 3. Try above and below current position
        for (int y = 1; y >= -1; y -= 2) { // +1 then -1
            BlockPos testPos = playerPos.offset(0, y, 0);
            if (isValidPlacePosition(testPos)) {
                if (debugMode.get()) {
                    info("找到合适位置(上下方向): " + testPos.toShortString());
                }
                return testPos;
            }
        }

        // 4. Finally try diagonal positions if no direct adjacent positions work
        for (int distance = 1; distance <= 3; distance++) {
            for (int x = -distance; x <= distance; x++) {
                for (int z = -distance; z <= distance; z++) {
                    // Skip positions we already checked (direct adjacent)
                    if ((Math.abs(x) == 1 && z == 0) || (x == 0 && Math.abs(z) == 1) || (x == 0 && z == 0)) {
                        continue;
                    }

                    // Only check positions at the current distance boundary
                    if (Math.abs(x) == distance || Math.abs(z) == distance) {
                        for (int y = -1; y <= 1; y++) {
                            BlockPos testPos = playerPos.offset(x, y, z);
                            if (isValidPlacePosition(testPos)) {
                                if (debugMode.get()) {
                                    double dist = Math.sqrt(x * x + y * y + z * z);
                                    info("找到合适位置(对角线): " + testPos.toShortString() + " (距离: " + String.format("%.1f", dist) + ")");
                                }
                                return testPos;
                            }
                        }
                    }
                }
            }
        }

        if (logActions.get()) {
            error("在3格范围内未找到合适的放置位置");
        }
        return null;
    }

    private boolean isValidPlacePosition(BlockPos pos) {
        return mc.level.getBlockState(pos).isAir() &&
            BlockUtils.canPlace(pos) &&
            !mc.level.getBlockState(pos.below()).isAir();
    }

    private void moveItemToHotbar(int sourceSlot) {
        // Find empty hotbar slot
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getItem(i).isEmpty()) {
                // Move item to hotbar
                mc.gameMode.handleContainerInput(
                    mc.player.containerMenu.containerId,
                    sourceSlot,
                    i,
                    ContainerInput.SWAP,
                    mc.player
                );
                shulkerSlot = i;
                return;
            }
        }

        // If no empty slot, swap with first hotbar slot
        mc.gameMode.handleContainerInput(
            mc.player.containerMenu.containerId,
            sourceSlot,
            0,
            ContainerInput.SWAP,
            mc.player
        );
        shulkerSlot = 0;
    }

    private void openShulkerBox() {
        if (logActions.get()) info("正在打开潜影盒...");

        if (shulkerPos == null) {
            changeState(State.FINISHED);
            return;
        }

        // First, look at the shulker box
        if (!hasRotated) {
            lookAtBlock(shulkerPos);
            hasRotated = true;
            return; // Wait one tick for rotation to complete
        }

        // Wait a few ticks after rotation to ensure it's complete
        if (stateTimeout < 3) {
            return; // Wait 3 ticks after rotation
        }

        // 确保目标位置确实是潜影盒
        Block block = mc.level.getBlockState(shulkerPos).getBlock();
        if (!(block instanceof ShulkerBoxBlock)) {
            warning("目标位置不是潜影盒: " + shulkerPos.toShortString());
            return;
        }

        // 计算点击位置
        Vec3 hitVec = Vec3.upFromBottomCenterOf(shulkerPos, 0);
        Direction side = Direction.UP; // 默认从上方点击

        // 创建方块命中结果
        BlockHitResult hitResult = new BlockHitResult(hitVec, side, shulkerPos, false);

        // 右键点击潜影盒
        mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND, hitResult);

        changeState(State.EXTRACTING_ITEMS);
        if (logActions.get()) info("潜影盒已打开");
    }

    private void extractItems() {
        if (logActions.get()) info("正在提取物品...");

        // Check if container screen is open
        if (mc.screen == null) {
            if (logActions.get()) info("等待容器界面打开... (界面为空)");
            return;
        }

        if (!(mc.screen instanceof AbstractContainerScreen)) {
            if (logActions.get())
                info("等待容器界面打开... (当前界面: " + mc.screen.getClass().getSimpleName() + ")");
            return;
        }

        AbstractContainerScreen<?> containerScreen = (AbstractContainerScreen<?>) mc.screen;
        var screenHandler = containerScreen.getMenu();

        if (logActions.get()) info("容器界面已打开: " + containerScreen.getClass().getSimpleName());

        // Special handling for elytra exchange
        boolean isElytraTarget = targetItem.get() == Items.ELYTRA && elytraExchange.get();
        boolean hasStoredLowDurabilityElytra = false;

        if (isElytraTarget) {
            // Check for low durability elytra in inventory and store it first
            int lowDurabilitySlot = findLowDurabilityElytraInInventory();
            if (lowDurabilitySlot != -1) {
                if (logActions.get()) {
                    ItemStack lowElytra = mc.player.getInventory().getItem(lowDurabilitySlot);
                    info("发现低耐久鞘翅 (耐久: " + getElytraDurability(lowElytra) + ")，先存入潜影盒");
                }
                // Move low durability elytra to container
                mc.gameMode.handleContainerInput(
                    screenHandler.containerId,
                    36 + lowDurabilitySlot, // Player inventory slot
                    0,
                    ContainerInput.QUICK_MOVE,
                    mc.player
                );
                hasStoredLowDurabilityElytra = true;
                return; // Wait one tick for the move to complete
            }
        }

        // Count empty slots in player inventory (excluding hotbar slot 0 which we want to keep)
        int emptySlots = countEmptyInventorySlots();
        if (emptySlots <= 1) {
            if (logActions.get()) info("库存空间不足，仅保留一格空位");
            changeState(State.CLOSING_CONTAINER);
            return;
        }

        // Extract target items from container
        boolean foundItems = false;
        int containerSlots = screenHandler.slots.size() - 36; // Container slots only (excluding player inventory)
        int targetGroupsExtracted = 0; // Count how many groups of items we've extracted in this session
        int maxGroupsToExtract = specifyAmount.get() ? extractAmount.get() : Integer.MAX_VALUE;

        if (logActions.get()) {
            info("容器槽位数: " + containerSlots + ", 总槽位数: " + screenHandler.slots.size());
            if (specifyAmount.get()) {
                info("指定提取模式: 最多提取 " + maxGroupsToExtract + " 组物品");
            } else {
                info("全部提取模式: 提取所有目标物品");
            }
        }

        for (int i = 0; i < containerSlots; i++) {
            ItemStack stack = screenHandler.getSlot(i).getItem();
            if (logActions.get() && !stack.isEmpty()) {
                String durabilityInfo = "";
                if (stack.getItem() == Items.ELYTRA) {
                    durabilityInfo = " (耐久: " + getElytraDurability(stack) + ")";
                }
                info("槽位 " + i + ": " + stack.getDisplayName().getString() + " x" + stack.getCount() + durabilityInfo);
            }

            if (!stack.isEmpty() && stack.getItem() == targetItem.get()) {
                // Special elytra durability check
                if (isElytraTarget && !isElytraHighDurability(stack)) {
                    if (logActions.get()) {
                        info("跳过低耐久鞘翅 (耐久: " + getElytraDurability(stack) + ")");
                    }
                    continue;
                }

                // Check if we've reached the extraction limit
                if (specifyAmount.get() && targetGroupsExtracted >= maxGroupsToExtract) {
                    if (logActions.get()) {
                        info("已达到指定提取数量限制 (" + maxGroupsToExtract + " 组)，停止提取");
                    }
                    break;
                }

                // Click to take the item
                mc.gameMode.handleContainerInput(
                    screenHandler.containerId,
                    i,
                    0,
                    ContainerInput.QUICK_MOVE,
                    mc.player
                );
                foundItems = true;
                targetGroupsExtracted++;
                itemsExtracted += stack.getCount();

                if (logActions.get()) {
                    String durabilityInfo = "";
                    if (stack.getItem() == Items.ELYTRA) {
                        durabilityInfo = " (耐久: " + getElytraDurability(stack) + ")";
                    }
                    info("提取了 " + stack.getCount() + " 个 " + stack.getHoverName().getString() + durabilityInfo +
                        " (已提取 " + targetGroupsExtracted + "/" + maxGroupsToExtract + " 组)");
                }

                // Check if we have enough space for more items
                emptySlots = countEmptyInventorySlots();
                if (emptySlots <= 1) {
                    if (logActions.get()) info("库存空间不足，停止提取");
                    break;
                }
            }
        }

        if (!foundItems) {
            if (logActions.get()) {
                if (specifyAmount.get()) {
                    info("已完成指定数量提取或潜影盒中没有更多目标物品");
                } else {
                    info("潜影盒中没有更多目标物品");
                }
            }
            changeState(State.CLOSING_CONTAINER);
        }
    }

    public static int countEmptyInventorySlots() {
        int count = 0;
        Minecraft mc = Minecraft.getInstance();
        for (int i = 9; i < 36; i++) { // Main inventory slots only
            if (mc.player.getInventory().getItem(i).isEmpty()) {
                count++;
            }
        }
        return count;
    }

    private void closeContainer() {
        if (logActions.get()) info("正在关闭容器...");

        if (mc.screen != null) {
            mc.screen.onClose();
        }

        changeState(State.BREAKING_SHULKER);
    }

    private void breakShulkerBox() {
        if (logActions.get()) info("正在挖掘潜影盒...");

        if (shulkerPos == null) {
            changeState(State.FINISHED);
            return;
        }

        // Check if the shulker box still exists
        Block block = mc.level.getBlockState(shulkerPos).getBlock();
        if (!(block instanceof ShulkerBoxBlock)) {
            if (logActions.get()) info("潜影盒已不存在（已被破坏）");
            changeState(State.PICKING_UP_SHULKER);
            baritone.getPathingBehavior().cancelEverything();
            return;
        }

        // 打破前快照背包中潜影盒数量（用于检测拾取成功）
        if (pickupBefore == 0) {
            pickupBefore = countShulkersInInventory();
            if (logActions.get()) dbg("打破前背包潜影盒数量: %d", pickupBefore);
        }

        // Look at the shulker box before breaking
        lookAtBlock(shulkerPos);

        // 持续破坏直到方块消失
        BlockUtils.breakBlock(shulkerPos, true);

        // 不立即切换状态 —— 每 tick 持续调用直到 ShulkerBoxBlock 变为空气
    }

    private void pickUpShulkerBox() {
        int result = tickPickupDrop(shulkerPos);

        switch (result) {
            case 0 -> {
            } // BUSY — 继续追逐
            case 1 -> {  // DONE — 已拾取成功
                if (logActions.get()) info("潜影盒拾取成功");
                resetPickupState();
                changeState(State.FINISHED);
            }
            case 2 -> {  // GAVE_UP — 超时放弃
                warning("拾取潜影盒超时 — 放弃追逐");
                resetPickupState();
                changeState(State.FINISHED);
            }
        }
    }

    /**
     * 单 tick 驱动拾取逻辑，参照 MassExtractor#tickPickupDrop。
     * 返回值：0=BUSY（仍在追逐），1=DONE（已拾取），2=GAVE_UP（超时放弃）。
     * 核心机制：定位掉落实体 → 等落地 → 追逐寻路 → 检测漂移重新寻路 → 数量增加即完成。
     */
    private int tickPickupDrop(BlockPos breakPos) {
        // 检测拾取成功：背包中潜影盒数量增加了
        if (countShulkersInInventory() > pickupBefore) {
            baritone.getPathingBehavior().cancelEverything();
            resetPickupState();
            return 1; // DONE
        }

        // 超时放弃（~10 秒）
        if (++pickupAttempts > PICKUP_TIMEOUT_TICKS) {
            baritone.getPathingBehavior().cancelEverything();
            resetPickupState();
            return 2; // GAVE_UP
        }

        // （重新）获取掉落的潜影盒实体 —— 打碎后可能弹开一格
        if (pickupDrop == null || !pickupDrop.isAlive() || pickupDrop.isRemoved()) {
            pickupDrop = nearestShulkerDrop(breakPos);
            pickupPathed = false;
            pickupSettleTicks = 0;
            pickupGoal = null;
        }

        if (pickupDrop != null) {
            // 落地等待：新打碎的潜影盒会弹跳，等它落地再追（避免追到过时位置）
            if (!pickupDrop.onGround() && ++pickupSettleTicks < PICKUP_SETTLE_TICKS) {
                return 0; // BUSY — 还在等落地
            }
            // 漂移追踪：掉落物弹到新方块时重新寻路
            BlockPos cur = pickupDrop.blockPosition();
            if (!pickupPathed || !cur.equals(pickupGoal)) {
                pathToBlock(cur);
                pickupGoal = cur;
                pickupPathed = true;
                if (logActions.get()) dbg("追逐潜影盒掉落物 → %s", cur.toShortString());
            }
        } else if (!pickupPathed && breakPos != null) {
            // 还没找到实体 —— 先走到破坏点
            pathToBlock(breakPos);
            pickupPathed = true;
        }

        return 0; // BUSY
    }

    /**
     * 重置拾取追踪状态。
     */
    private void resetPickupState() {
        pickupDrop = null;
        pickupPathed = false;
        pickupSettleTicks = 0;
        pickupGoal = null;
        pickupAttempts = 0;
        pickupBefore = 0;
    }

    /**
     * 在破坏点附近搜索掉落的潜影盒实体。
     */
    private ItemEntity nearestShulkerDrop(BlockPos near) {
        if (near == null || mc.level == null) return null;
        ItemEntity best = null;
        double bestSq = Double.MAX_VALUE;
        for (ItemEntity e : mc.level.getEntitiesOfClass(ItemEntity.class, new AABB(near).inflate(4),
            e -> e.isAlive() && isShulkerBoxItem(e.getItem()))) {
            double d = e.distanceToSqr(mc.player);
            if (d < bestSq) {
                bestSq = d;
                best = e;
            }
        }
        return best;
    }

    /**
     * 判断物品是否是任意潜影盒。
     */
    private boolean isShulkerBoxItem(ItemStack stack) {
        if (stack.isEmpty()) return false;
        return stack.getItem() instanceof BlockItem bi && bi.getBlock() instanceof ShulkerBoxBlock;
    }

    /**
     * 统计背包中潜影盒的总数量（物品数量，非槽位数）。
     */
    private int countShulkersInInventory() {
        int n = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack s = mc.player.getInventory().getItem(i);
            if (isShulkerBoxItem(s)) n += s.getCount();
        }
        return n;
    }

    /**
     * 使用 Baritone 寻路到指定方块（精确站在上面），用于拾取掉落物。
     */
    private void pathToBlock(BlockPos pos) {
        baritone.getCustomGoalProcess().setGoalAndPath(new GoalBlock(pos));
    }

    private void finishProcess() {
        if (logActions.get()) {
            if (specifyAmount.get()) {
                info("物品提取完成！共提取了 " + itemsExtracted + " 个物品");
            } else {
                info("物品提取完成！共提取了 " + itemsExtracted + " 个物品");
            }
        }

        if (autoClose.get()) {
            toggle();
        } else {
            resetState();
        }
    }

    private void resetState() {
        currentState = State.SEARCHING_SHULKER;
        tickCounter = 0;
        shulkerSlot = -1;
        shulkerPos = null;
        shulkerBoxItem = null;
        isProcessing = false;
        stateTimeout = 0;
        hasRotated = false;
        itemsExtracted = 0;
        resetPickupState();

        baritone.getSelectionManager().removeAllSelections();
        baritone.getPathingBehavior().cancelEverything();
    }

    private void changeState(State newState) {
        if (currentState != newState) {
            if (debugMode.get()) {
                info("状态切换: " + currentState.name() + " -> " + newState.name());
            }
            currentState = newState;
            stateTimeout = 0; // Reset timeout when changing state
            hasRotated = false; // Reset rotation flag when changing state
        }
    }

    private void lookAtBlock(BlockPos pos) {
        if (mc.player == null || !autoRotate.get()) return;

        Vec3 playerPos = mc.player.getEyePosition();
        Vec3 blockCenter = Vec3.upFromBottomCenterOf(pos, 0);
        Vec3 direction = blockCenter.subtract(playerPos).normalize();

        float yaw = (float) (Mth.atan2(direction.z, direction.x) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float) -(Mth.atan2(direction.y, Math.sqrt(direction.x * direction.x + direction.z * direction.z)) * 180.0 / Math.PI);

//        mc.player.setYaw(yaw);
//        mc.player.setPitch(pitch);
        Rotations.rotate(yaw, pitch);
    }

    private void dbg(String fmt, Object... args) {
        if (debugMode.get()) info(args.length == 0 ? fmt : String.format(fmt, args));
    }
}
