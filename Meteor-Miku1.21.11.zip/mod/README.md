# meteor-miku

Meteor Client 的客户端附加模组（addon），是 [meteor-rejects](https://github.com/MeteorDevelopment/meteor-rejects)
在 **Minecraft 1.21.11 / Fabric** 上的移植与扩展版本。

- 加载器：Fabric `0.19.5`
- Minecraft：`1.21.11`
- Java：`21`

## 需要的前置

### 必需

| 前置 | 版本 |
| --- | --- |
| [Meteor Client](https://github.com/MeteorDevelopment/meteor-client) | 适配 1.21.11 的版本 |
| [Fabric API](https://modrinth.com/mod/fabric-api) | `0.141.6+1.21.11` |
| Fabric Loader | `0.19.5` |

### 可选联动（装了才生效，不装也能正常启动）

| 前置 | 版本（均为 1.21.11 的 Fabric 版） | 用到的功能 |
| --- | --- | --- |
| [Baritone](https://github.com/cabaletta/baritone)（Meteor 打包版，mod id 是 `baritone-meteor`） | `1.21.11` | 寻路、种子矿透同步目标 |
| [Xaero's Minimap](https://modrinth.com/mod/xaeros-minimap) | `26.5.0` | 小地图路径点 |
| [Xaero's World Map](https://modrinth.com/mod/xaeros-world-map) | `1.46.0` | 世界地图路径点刷新 |
| [Litematica](https://modrinth.com/mod/litematica) | `0.26.16` | 投影原理图 |
| [MiniHUD](https://modrinth.com/mod/minihud) | `0.38.16` | HUD 坐标行覆盖 |
| [MaLiLib](https://modrinth.com/mod/malilib) | `0.27.20` | Litematica / MiniHUD 的前置 |

事件总线 Orbit 由 Meteor Client 在运行期自带，不需要单独安装。

### 1.21.11 适配说明

本版由上游 26.1 版源码移植而来：类名、方法名与字段名全部换成 1.21.11 的 Yarn 映射，
mixin 目标与方法签名按 1.21.11 重写。种子模拟所需的 seedfinding 系列库随 jar 一起
打包进产物；可选联动模组直接用面向 1.21.11 的真实发行 jar 编译（不会打进产物），
因此运行期签名与这些模组的官方版本完全一致。

## 构建

```bash
gradle build       # 产物在 build/libs/
```

构建会生成 `meteor-miku-<version>.jar`，直接放进客户端的 `mods/` 目录即可
（仅客户端模组，不需要装在服务端）。

## 许可证

Copyright (C) 2024-2026 XC_XinCheng

本程序是自由软件：你可以依据 **GNU 通用公共许可证第 3 版**（GNU GPL v3.0）
的条款重新发布和/或修改它。

```
SPDX-License-Identifier: GPL-3.0-only
```

本程序基于“有用”的期望分发，但不提供任何担保，甚至不提供适销性或特定用途
适用性的默示担保。详见随附的 [LICENSE](LICENSE)（GNU GPL v3.0 全文）。

### 为什么是 GPL-3.0

本模组的全部运行前置与上游源码都以 GPL-3.0 发布：

- [Meteor Client](https://github.com/MeteorDevelopment/meteor-client)：GPL-3.0
- [meteor-rejects](https://github.com/MeteorDevelopment/meteor-rejects)：GPL-3.0
- [Baritone](https://github.com/cabaletta/baritone)：LGPL-3.0

由于本模组是它们的衍生作品，因此同样以 GPL-3.0 发布，并保留上游的版权声明。
各上游项目的完整归属与许可见 [THIRD-PARTY-NOTICES.md](THIRD-PARTY-NOTICES.md)。

### 源码获取

GPL-3.0 要求分发二进制时同时提供对应的完整源码。本模组的完整源码发布于：

<https://github.com/mikumiku7/meteor-miku>

发布的 jar 包内 `META-INF/` 目录下同时附带了 `LICENSE` 与
`THIRD-PARTY-NOTICES.md`。

## 修改说明

本项目相对上游 `meteor-rejects` 的主要修改：为适配 Minecraft 1.21.11（Yarn 映射）
重写了类名、方法名与字段名、mixin 的目标方法名与访问器，把种子模拟所需的 seedfinding
系列库打包进产物，并改用面向 1.21.11 的真实前置模组 jar 编译，此外新增了若干模块。
依据 GPL-3.0 第 5 条，修改部分已在源码文件头与提交历史中标注。

### 本版新增分类

- **「Miku 合法」**：以真人操作节奏为优先的模块。
  - `Miku合法杀戮光环`：每 tick 只把视角朝目标转一个可调角度（默认 18°/tick），
    转到瞄准容差以内、且原版攻击冷却好了才补一次点击；目标按
    距离最近 / 血量最低 / 综合 筛选（综合模式优先处理凋零、末影龙、苦力怕，
    其次是女巫、骷髅，最后是其余普通怪物），点击间隔可自定义；实体类型下面还能选
    「武器类型」（剑 / 斧 / 锤 / 三叉戟 / 全部武器 / 任意物品），手里拿的不是选定武器
    就不甩视角也不出手。
  - `Miku合法挖掘光环`：视角逐步对准目标方块，再走原版
    `startDestroyBlock` / `continueDestroyBlock`；可设置挖掘范围、方块列表、
    视角速度、瞄准容差与换目标间隔，并可高亮当前目标。
- **`Miku 聊天`（主分类「Miku」下）**：可自定义多套聊天方案，在设置界面里直接加行即可；
  每套独立设置启用、方案名、发送间隔、多条消息（用 `|` 分隔）、顺序/随机；每套方案的间隔
  后面都能单独选单位（毫秒/秒/分），换档只改显示口径、方案里始终按毫秒保存。
  消息里的 `%s` 要不要换成附近玩家名，由「范围内搜索玩家」开关统一决定：**关闭（默认）**
  时不去搜人，把 `%s` 去掉后直接发送；**开启**时才在「寻找范围」格内找最近的玩家替换
  （可勾「忽略好友」），附近找不到就跳过这一条。该模块名在 GUI 里渲染为黄色，只有这几个字
  变黄，不影响同一分类里的其它模块。


种子相关模块的版本选择：种子库 `seedfinding` 的 `MCVersion` 只收录到 1.21，没有
1.21.11；本项目新增 `util/seeds/SeedVersion`，在库版本之外补上 **1.21.11**（默认），
并保留上游的 26.x 选项以兼容旧配置。“种子矿透”（`SeedMine`）直接调用本版游戏原生的
世界生成算法（与上游 `OreSim` 的做法一致），因此版本选择只用于记录种子来源，
不影响矿位计算；种子库版本仅作为种子元数据兼容保留。

### 种子矿透的矿石外观

“种子矿透”的设置里，“矿石”一行点 `Select` 打开选择界面，按浅层矿石（Y≥0 石头）、
深层矿石（Y&lt;0 深板岩）、下界矿石分成三段，每段标题右边可一次全选整层。段内每一行：

- **颜色**：点色块打开取色器，改这种矿石的 3D 边框颜色（默认沿用内置色）。
- **连接**：勾选后，相邻的同类矿石边框会连成一体，不再逐块画方框。
- **显示**：勾选后才显示、也会被“同步设置 baritone / 直接开挖”当作目标。

“与世界同步”打开后，会按“同步时间”（秒）定期读取当前世界的真实种子（单人是存档
种子，服务器是按世界名保存的种子），种子或维度变化时自动重算矿位，平时只补算新
加载的区块。种子算矿算法本身没有改动。

