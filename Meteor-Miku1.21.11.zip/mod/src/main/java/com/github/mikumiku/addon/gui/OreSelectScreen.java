/*
 * 本文件属于 meteor-miku 项目：https://github.com/mikumiku7/meteor-miku
 * meteor-miku 是 meteor-rejects 在 Minecraft 26.1 / Fabric 上的移植版本。
 *
 * Copyright (C) 2024-2026 XC_XinCheng
 *
 * SPDX-License-Identifier: GPL-3.0-only
 *
 * 本程序是自由软件：你可以依据 GNU 通用公共许可证（GNU GPL）第 3 版的条款
 * 重新发布和/或修改它。
 *
 * 本程序基于“有用”的期望分发，但不提供任何担保，甚至不提供适销性或特定
 * 用途适用性的默示担保。详见 GNU 通用公共许可证。
 *
 * 你应当已随本程序收到一份 GNU 通用公共许可证副本；如果没有，请见
 * <https://www.gnu.org/licenses/>。
 */
package com.github.mikumiku.addon.gui;

import com.github.mikumiku.addon.util.Ore;
import com.github.mikumiku.addon.util.OreListSetting;
import com.github.mikumiku.addon.util.MikuCompat;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.WindowScreen;
import meteordevelopment.meteorclient.gui.screens.settings.ColorSettingScreen;
import meteordevelopment.meteorclient.gui.widgets.containers.WSection;
import meteordevelopment.meteorclient.gui.widgets.containers.WTable;
import meteordevelopment.meteorclient.gui.widgets.containers.WVerticalList;
import meteordevelopment.meteorclient.gui.widgets.input.WTextBox;
import meteordevelopment.meteorclient.gui.widgets.pressable.WCheckbox;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * 矿石选择界面：按浅层（Y≥0 石头）、深层（Y&lt;0 深板岩）、下界分成三段，
 * 每段标题右边有一个全选勾选框（一次勾上这一层全部矿石）。
 * 段内每行是“矿石名 + 颜色块 + 边框连接 + 显示勾选框”：
 * 点颜色块打开取色器，连接勾选框决定边框是否与相邻同类矿石连成一体，
 * 显示勾选框决定这种矿石画不画、挖不挖。
 */
public class OreSelectScreen extends WindowScreen {
    private final OreListSetting setting;
    private final WTextBox filter;
    private final WVerticalList list;
    private String filterText = "";

    public OreSelectScreen(GuiTheme theme, OreListSetting setting) {
        super(theme, "选择矿石");
        this.setting = setting;

        this.filter = add(theme.textBox("", "搜索")).minWidth(400).expandX().widget();
        this.filter.action = () -> {
            this.filterText = filter.get().trim().toLowerCase(Locale.ROOT);
            rebuild();
        };

        add(theme.label("颜色：点色块选择；连接：相邻同类矿石边框连成一体；显示：勾选才显示/挖掘。"));

        this.list = add(theme.verticalList()).expandX().widget();
    }

    @Override
    public void initWidgets() {
        filter.setFocused(true);
        rebuild();
    }

    private void rebuild() {
        list.clear();

        for (Ore.OreLayer layer : Ore.OreLayer.values()) {
            List<Ore.OreType> types = new ArrayList<>();
            for (Ore.OreType type : Ore.OreType.inLayer(layer)) {
                if (matches(type)) types.add(type);
            }
            if (types.isEmpty()) continue;

            Set<Ore.OreKey> selected = setting.get();
            List<Ore.OreKey> keys = new ArrayList<>(types.size());
            for (Ore.OreType type : types) keys.add(Ore.OreKey.of(type, layer));

            // 段标题右边的全选勾选框
            WCheckbox master = theme.checkbox(selected.containsAll(keys));
            master.tooltip = "一次勾上/取消这一层的全部矿石";
            master.action = () -> {
                Set<Ore.OreKey> current = setting.get();
                if (master.checked) current.addAll(keys);
                else current.removeAll(keys);
                setting.onChanged();
                rebuild();
            };

            WSection section = list.add(theme.section(layer.displayName, true, master)).expandX().widget();
            WTable table = section.add(theme.table()).expandX().widget();

            // 表头，对应下面每一行的三个控件
            table.add(theme.label("")).expandCellX().widget();
            table.add(theme.label("颜色")).widget();
            table.add(theme.label("连接")).widget();
            table.add(theme.label("显示")).widget();
            table.row();

            for (int i = 0; i < types.size(); i++) {
                Ore.OreType type = types.get(i);
                Ore.OreKey key = keys.get(i);
                Ore.OreStyle style = setting.style(key);

                table.add(theme.label(type.displayName)).expandCellX().widget();

                WOreColorSwatch swatch = table.add(new WOreColorSwatch(style.color)).widget();
                swatch.action = () -> openColorPicker(key);

                WCheckbox connected = table.add(theme.checkbox(style.connected)).widget();
                connected.tooltip = "边框是否与相邻的同类矿石连成一体";
                connected.action = () -> {
                    style.connected = connected.checked;
                    setting.onChanged();
                };

                WCheckbox box = table.add(theme.checkbox(selected.contains(key))).widget();
                box.tooltip = "勾选后才显示/挖掘这种矿石";
                box.action = () -> {
                    Set<Ore.OreKey> current = setting.get();
                    if (box.checked) current.add(key);
                    else current.remove(key);
                    setting.onChanged();
                    rebuild();
                };

                table.row();
            }
        }
    }

    /** 打开 Meteor 自带的取色器，改完直接写回这个矿石的样式。 */
    private void openColorPicker(Ore.OreKey key) {
        Ore.OreStyle style = setting.style(key);
        ColorSetting picker = new ColorSetting(
            key.type.displayName + "·" + key.layer.displayName + " 颜色",
            "选择这种矿石边框的颜色",
            new SettingColor(style.color.r, style.color.g, style.color.b, style.color.a),
            color -> {
                style.color.set(color);
                setting.onChanged();
            },
            null,
            null
        );
        MikuCompat.setScreen(new ColorSettingScreen(theme, picker));
    }

    private boolean matches(Ore.OreType type) {
        if (filterText.isEmpty()) return true;
        return type.displayName.toLowerCase(Locale.ROOT).contains(filterText)
            || type.mineName.toLowerCase(Locale.ROOT).contains(filterText)
            || type.name().toLowerCase(Locale.ROOT).contains(filterText);
    }
}
