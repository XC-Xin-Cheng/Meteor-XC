/*
 * 本文件属于 meteor-miku 项目：https://github.com/mikumiku7/meteor-miku
 * meteor-miku 是 meteor-rejects 在 Minecraft 26.1 / Fabric 上的移植版本。
 *
 * Copyright (C) 2024-2026 XC_XinCheng
 *
 * SPDX-License-Identifier: GPL-3.0-only
 *
 * 本程序是自由软件：你可以依据 GNU 通用公共许可证（GNU GPL）第 3 版的条款
 * 重新发布和/或修改它。
 *
 * 本程序基于“有用”的期望分发，但不提供任何担保，甚至不提供适销性或特定
 * 用途适用性的默示担保。详见 GNU 通用公共许可证。
 *
 * 你应当已随本程序收到一份 GNU 通用公共许可证副本；如果没有，请见
 * <https://www.gnu.org/licenses/>。
 */
package com.github.mikumiku.addon.modules;

import com.github.mikumiku.addon.BaseModule;
import com.github.mikumiku.addon.util.ChatScheme;
import com.github.mikumiku.addon.util.ChatSchemeListSetting;
import com.github.mikumiku.addon.util.MikuChatStore;
import com.github.mikumiku.addon.util.MikuCompat;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.player.PlayerEntity;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * 「Miku 聊天」——可自定义多套聊天方案。
 *
 * <p>每套方案独立设置发送间隔、消息列表、顺序/随机。多套方案可以同时启用，
 * 互不干扰，例如“打招呼”和“夸夸机”两套一起跑。</p>
 *
 * <p>消息里写 {@code %s} 时怎么发，由「范围内搜索玩家」开关决定：<b>关（默认）</b>
 * 时不去搜附近的人，直接把 {@code %s} 去掉后照常发送；<b>开</b>时才在「寻找范围」
 * 格内找最近的玩家，把 {@code %s} 换成他的名字，附近找不到就先跳过这一条。
 * 两种情况下都不会把 {@code %s} 原样发到聊天栏。</p>
 *
 * <p>每套方案的间隔后面都有一个单位下拉框，各选各的：毫秒（最长 10 分钟）、
 * 秒（最长 5 小时）、分（最长 10 小时）；不管选哪一档，方案文件里存的都是毫秒。</p>
 *
 * <p>方案在配置界面里展开成一张可编辑的表，直接加一行、填消息即可，
 * 不需要改代码。默认方案见 {@link #defaultSchemes()}：游戏根目录里还没有
 * {@code Miku-Chat.txt} / {@code Miku-Chat-old.txt} 时，就按这套默认值创建。</p>
 */
public class MikuChat extends BaseModule {

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<List<ChatScheme>> schemes = sgGeneral.add(new ChatSchemeListSetting.Builder()
        .name("聊天方案")
        .description("可添加多套方案：勾选启用、改名字、填间隔（每套方案的间隔后面都能切毫秒/秒/分）、写多条消息（用 | 分隔）、切顺序/随机；多套可同时生效")
        .defaultValue(defaultSchemes())
        // 走方法引用而不是直接读 maxHistory 字段：该字段在下面才声明，
        // 字段初始化器里直接引用会触发 illegal forward reference
        .historyLimit(this::maxHistoryValue)
        .build()
    );

    /**
     * 内置默认方案：35 套，间隔 50000 ms，随机且不重复，默认全部关闭。
     *
     * <p>这套默认值同时用于三处：首次安装时的设置初值、点「重置」后恢复的
     * 内容、以及游戏根目录里那两个方案文件不存在时自动创建的内容。</p>
     */
    public static List<ChatScheme> defaultSchemes() {
        String[][] def = {
            {"方案1", "心有丘壑,眼存山河"},
            {"方案2", "纵有狂风起,亦要向前行"},
            {"方案3", "大鹏一日同风起,扶摇直上九万里"},
            {"方案4", "%s，愿你乘风破浪，直挂云帆济沧海"},
            {"方案5", "胸藏文墨怀若谷，腹有诗书气自华"},
            {"方案6", "剑指苍穹，豪情万丈，此生无悔"},
            {"方案7", "%s，愿你历尽千帆，归来仍是少年"},
            {"方案8", "天行健，君子以自强不息"},
            {"方案9", "地势坤，君子以厚德载物"},
            {"方案10", "%s，且将新火试新茶，诗酒趁年华"},
            {"方案11", "大鹏一日同风起，扶摇直上九万里，%s"},
            {"方案12", "莫愁前路无知己，天下谁人不识君"},
            {"方案13", "黄沙百战穿金甲，不破楼兰终不还"},
            {"方案14", "%s，愿你满腔孤勇，一身热血，仗剑走天涯"},
            {"方案15", "仰天大笑出门去，我辈岂是蓬蒿人"},
            {"方案16", "%s，愿我们都能长风破浪，会当凌绝顶"},
            {"方案17", "海内存知己，天涯若比邻，%s"},
            {"方案18", "%s，祝你前程似锦，归来仍是少年"},
            {"方案19", "路漫漫其修远兮，吾将上下而求索"},
            {"方案20", "遵守规矩不算是本事，真正的本事是破坏规矩而享受利益，却不受惩罚。"},
            {"方案21", "这个世界其实是灰色的。有时候黑的能转成白的，白的能转成黑的，%s。"},
            {"方案22", "替我活下去，见证这个世间万般之精彩吧！"},
            {"方案23", "看万物都是一视同仁，众生皆是平等。所以人的死，一棵树的死，没有区别，%s。"},
            {"方案24", "人言可畏，但可信的人只有我自己。"},
            {"方案25", "岂不闻天无绝人之路？只要我想走，路就在脚下，%s！"},
            {"方案26", "态度是心的面具，%s。"},
            {"方案27", "%s，因为困难多壮志，不教红尘惑坚心，今身暂且栖草头，它日狂歌踏山河。"},
            {"方案28", "%s，逆天，尚有例外。逆吾，绝无生机。"},
            {"方案29", "%s，当我读到你的时候，便对你顿生无尽崇敬之意。"},
            {"方案30", "世事如棋，上佳的棋手，向来谋定后动。"},
            {"方案31", "%s，他心中一片平静。辱骂于我何加焉？"},
            {"方案32", "%s，万物平等，天地不仁以万物为刍狗。"},
            {"方案33", "%s，野心一大，世界便小。"},
            {"方案34", "每次看到 %s，男儿不展凌云志，空负天生八尺躯。"},
            {"方案35", "魔不魔，正不正，天地自有凤九歌。走不走，留不留，死生皆在我心头"}
        };

        List<ChatScheme> list = new ArrayList<>(def.length);
        for (String[] entry : def) {
            ChatScheme scheme = new ChatScheme(entry[0], false, 50000, true, entry[1]);
            scheme.avoidRepeat = true;
            list.add(scheme);
        }
        return list;
    }

    /**
     * 「范围内搜索玩家」开关。
     *
     * <p>关（默认）时消息里的 {@code %s} 不去搜人，去掉后直接发送；开时才在
     * {@link #range} 格内找最近的玩家来替换 {@code %s}，找不到这条先跳过。</p>
     */
    private final Setting<Boolean> searchRange = sgGeneral.add(new BoolSetting.Builder()
        .name("范围内搜索玩家")
        .description("关（默认）：消息里的 %s 不搜索玩家，把 %s 去掉后直接发送；开：在「寻找范围」格内找最近的玩家，找到才把 %s 换成他的名字，找不到这条先跳过")
        .defaultValue(false)
        .build()
    );

    private final Setting<Double> range = sgGeneral.add(new DoubleSetting.Builder()
        .name("寻找范围")
        .description("把 %s 替换成玩家名时，最多在多少格内找最近的玩家")
        .defaultValue(16.0)
        .min(1.0)
        .sliderRange(1.0, 64.0)
        .visible(searchRange::get)
        .build()
    );

    private final Setting<Boolean> ignoreFriends = sgGeneral.add(new BoolSetting.Builder()
        .name("忽略好友")
        .description("找 %s 的替换对象时不把好友算进去")
        .defaultValue(false)
        .visible(searchRange::get)
        .build()
    );

    private final Setting<Boolean> pauseInGui = sgGeneral.add(new BoolSetting.Builder()
        .name("界面中暂停")
        .description("打开背包/聊天/设置界面时先不发消息，避免关界面的瞬间补发一串")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> notify = sgGeneral.add(new BoolSetting.Builder()
        .name("启用提示")
        .description("启用时在聊天栏提示当前有几套方案在发消息")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> autoSave = sgGeneral.add(new BoolSetting.Builder()
        .name("自动保存")
        .description("按下面的间隔，自动把所有聊天方案写入游戏根目录的 " + MikuChatStore.FILE_NAME)
        .defaultValue(true)
        .build()
    );

    private final Setting<Integer> autoSaveInterval = sgGeneral.add(new IntSetting.Builder()
        .name("自动保存间隔（秒）")
        .description("自动保存的间隔，单位秒；默认 1200 秒 = 20 分钟")
        .defaultValue(1200)
        .min(10)
        .sliderRange(10, 3600)
        .visible(autoSave::get)
        .build()
    );

    /**
     * {@code Miku-Chat-old.txt} 里最多保留多少份旧方案集。
     *
     * <p>每点一次「重置」就会追加一份，超过这个数就从最旧的一份开始删。填再大也会被
     * {@link MikuChatStore#HARD_MAX_SNAPSHOTS} 夹住，避免文件无限膨胀。</p>
     */
    private final Setting<Integer> maxHistory = sgGeneral.add(new IntSetting.Builder()
        .name("旧方案集上限")
        .description("Miku-Chat-old.txt 里最多保留多少份「重置」前的方案集；超出时从最旧的一份开始丢")
        .defaultValue(MikuChatStore.DEFAULT_MAX_SNAPSHOTS)
        .min(1)
        .sliderRange(1, 100)
        .build()
    );

    /** 给 {@link ChatSchemeListSetting} 用的旧方案集上限；设置项还没就绪时回落到默认值。 */
    private int maxHistoryValue() {
        Integer value = maxHistory.get();
        return value == null ? MikuChatStore.DEFAULT_MAX_SNAPSHOTS : value;
    }

    /** 下一次自动保存的时间戳（毫秒）。 */
    private long nextAutoSaveAt = 0L;

    public MikuChat() {
        super(BaseModule.CATEGORY, "Miku 聊天",
            "可自定义多套聊天方案：每套独立设置间隔、消息、顺序/随机；%s 是否搜索附近玩家由「范围内搜索玩家」决定");
    }

    @Override
    public void onActivate() {
        super.onActivate();

        // 方案文本以游戏根目录的 Miku-Chat.txt 为准：有文件就读进来，没文件就先按当前方案建一份
        loadSchemesFromFile();

        long now = System.currentTimeMillis();
        int enabled = 0;
        for (ChatScheme scheme : schemes.get()) {
            scheme.resetRuntime(now);
            if (scheme.enabled) enabled++;
        }
        nextAutoSaveAt = now + autoSaveIntervalMs();

        if (notify.get()) {
            info("Miku 聊天已启用，当前 %d 套方案在发消息（方案文件：%s）", enabled, MikuChatStore.FILE_NAME);
        }
    }

    /**
     * 从 {@code Miku-Chat.txt} 载入方案，并把该有的文件补齐。
     *
     * <p>文件存在且至少有 1 行能解析时，用它替换当前方案；文件存在但解析不出方案时保持现状，
     * 不覆盖用户文件；文件不存在时按当前方案（首次即 {@link #defaultSchemes()}）写一份出去，
     * 方便用户直接编辑。备份文件 {@code Miku-Chat-old.txt} 不存在时同样建一份。旧版
     * {@code Miku-Chet.txt} 会在这一步自动迁到新名字，用户已有的方案不会丢。</p>
     */
    private void loadSchemesFromFile() {
        File main = MikuChatStore.ensureMainFile(schemes.get());
        List<ChatScheme> loaded = MikuChatStore.load(main);
        if (!loaded.isEmpty()) {
            List<ChatScheme> list = schemes.get();
            list.clear();
            list.addAll(loaded);
        }

        // 备份文件也补一份，用户在游戏根目录能直接看到这两个文件
        MikuChatStore.ensureOldFile(schemes.get());
    }

    /** 自动保存间隔换算成毫秒，至少 1 秒。 */
    private long autoSaveIntervalMs() {
        return Math.max(1, autoSaveInterval.get()) * 1000L;
    }

    /** 到点就把当前所有方案写回 Miku-Chat.txt；关掉「自动保存」时什么都不做。 */
    private void autoSaveTick() {
        if (!autoSave.get()) return;

        long now = System.currentTimeMillis();
        if (now < nextAutoSaveAt) return;

        MikuChatStore.save(MikuChatStore.mainFile(), schemes.get());
        nextAutoSaveAt = now + autoSaveIntervalMs();
    }

    @Override
    public void onDeactivate() {
        for (ChatScheme scheme : schemes.get()) {
            scheme.nextSendAt = 0L;
        }
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        autoSaveTick();

        if (mc.player == null || mc.world == null) return;
        if (pauseInGui.get() && MikuCompat.screen() != null) return;

        long now = System.currentTimeMillis();
        List<ChatScheme> list = schemes.get();

        for (ChatScheme scheme : list) {
            // 在界面上刚勾上/取消：重新计时，避免一点开就立刻发
            if (scheme.enabled != scheme.wasEnabled) {
                scheme.wasEnabled = scheme.enabled;
                scheme.nextSendAt = now + scheme.clampedIntervalMs();
            }

            if (!scheme.enabled || !scheme.hasMessages()) continue;
            if (now < scheme.nextSendAt) continue;

            String message = scheme.pickMessage();
            if (message == null) continue;

            if (message.contains("%s")) {
                if (searchRange.get()) {
                    PlayerEntity target = nearestPlayer();
                    if (target == null) {
                        // 消息里必须要名字但附近没有玩家，这一轮先跳过，不把 %s 原样发出去
                        scheme.nextSendAt = now + scheme.clampedIntervalMs();
                        continue;
                    }
                    message = message.replace("%s", target.getName().getString());
                } else {
                    // 没开范围搜索：不去找玩家，把 %s 去掉后直接发
                    message = withoutPlaceholder(message);
                    if (message.isEmpty()) {
                        // 整条消息就只有 %s，去掉后没内容了，这一轮跳过
                        scheme.nextSendAt = now + scheme.clampedIntervalMs();
                        continue;
                    }
                }
            }

            ChatUtils.sendPlayerMsg(message);
            scheme.nextSendAt = now + scheme.clampedIntervalMs();
        }
    }

    /** 在设定范围内找最近的、不是自己的玩家；没有则返回 null。 */
    private PlayerEntity nearestPlayer() {
        PlayerEntity closest = null;
        double closestSq = range.get() * range.get();

        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player == mc.player) continue;
            if (ignoreFriends.get() && Friends.get().isFriend(player)) continue;

            double distSq = mc.player.squaredDistanceTo(player);
            if (distSq <= closestSq) {
                closestSq = distSq;
                closest = player;
            }
        }

        return closest;
    }

    /**
     * 关掉「范围内搜索玩家」时，把消息里的 {@code %s} 去掉再发。
     *
     * <p>去掉占位符后顺手收拾留下的空格和标点，例如「每次看到 %s，男儿…」
     * 变成「每次看到，男儿…」、「%s，愿你…」变成「愿你…」，
     * 而不是「每次看到 ，男儿…」这种带空格的怪句子。</p>
     */
    private static String withoutPlaceholder(String message) {
        return message.replace("%s", "")
            .replaceAll("\\s+", " ")
            .replaceAll("\\s+([,，。.、；;：:!！?？])", "$1")
            .replaceAll("^[,，。.、；;：:!！?？]+", "")
            .trim();
    }
}
