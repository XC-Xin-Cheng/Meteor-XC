/*
 * 本文件属于 meteor-miku 项目：https://github.com/mikumiku7/meteor-miku
 * meteor-miku 是 meteor-rejects 在 MinecraftClient 26.1 / Fabric 上的移植版本。
 *
 * Copyright (C) 2024-2026 XC_XinCheng
 *
 * SPDX-License-Identifier: GPL-3.0-only
 *
 * 本程序是自由软件：你可以依据 GNU 通用公共许可证（GNU GPL）第 3 版的条款
 * 重新发布和/或修改它。
 *
 * 本程序基于“有用”的期望分发，但不提供任何担保，甚至不提供适销性或特定
 * 用途适用性的默示担保。详见 GNU 通用公共许可证。
 *
 * 你应当已随本程序收到一份 GNU 通用公共许可证副本；如果没有，请见
 * <https://www.gnu.org/licenses/>。
 */
package com.github.mikumiku.addon.util;

import com.github.mikumiku.addon.BaseModule;
import com.github.mikumiku.addon.MikuMagic2;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.player.InstantRebreak;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import net.minecraft.block.AirBlock;
import net.minecraft.block.AbstractFireBlock;
import net.minecraft.block.BedBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.ButtonBlock;
import net.minecraft.block.HangingSignBlock;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.FluidBlock;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.block.SlabBlock;
import net.minecraft.block.SignBlock;
import net.minecraft.block.TrapdoorBlock;
import net.minecraft.block.WallSignBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.enums.SlabType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.entity.projectile.thrown.ExperienceBottleEntity;
import net.minecraft.item.Item;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.state.property.Properties;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.*;

/**
 * Baritone 工具类，提供方块放置、交互和实体检测等功能
 * <p>
 * 通常
 * 放置范围最大为5
 * 挖掘范围最大为6
 *
 * @author MikuMiku
 */
public class BaritoneUtil {
    /**
     * MinecraftClient 客户端实例
     */
    public static final MinecraftClient mc = MinecraftClient.getInstance();

    // 性能：Direction.values() 每次调用都会克隆一个 6 元素数组，这里缓存一份只读副本供遍历使用。
    public static final Direction[] DIRECTIONS = Direction.values();


    /**
     * 需要潜行才能交互的方块列表
     */
    public static final List<Block> SNEAK_BLOCKS = Arrays.asList(
        Blocks.ENDER_CHEST,
        Blocks.CHEST,
        Blocks.TRAPPED_CHEST,
        Blocks.CRAFTING_TABLE,
        Blocks.CRAFTER,
        Blocks.JUKEBOX,
        Blocks.DECORATED_POT,
        Blocks.BIRCH_TRAPDOOR,
        Blocks.BAMBOO_TRAPDOOR,
        Blocks.DARK_OAK_TRAPDOOR,
        Blocks.CHERRY_TRAPDOOR,
        Blocks.OAK_TRAPDOOR,
        Blocks.SPRUCE_TRAPDOOR,
        Blocks.JUNGLE_TRAPDOOR,
        Blocks.WARPED_TRAPDOOR,
        Blocks.CRIMSON_TRAPDOOR,
        Blocks.MANGROVE_TRAPDOOR,
        Blocks.ANVIL,
        Blocks.REPEATER,
        Blocks.COMPARATOR,
        Blocks.CHIPPED_ANVIL,
        Blocks.DAMAGED_ANVIL,
        Blocks.BREWING_STAND,
        Blocks.HOPPER,
        Blocks.DROPPER,
        Blocks.DISPENSER,
        Blocks.ACACIA_TRAPDOOR,
        Blocks.ENCHANTING_TABLE,
        MikuBlocks.get("white_shulker_box"),
        MikuBlocks.get("orange_shulker_box"),
        MikuBlocks.get("magenta_shulker_box"),
        MikuBlocks.get("light_blue_shulker_box"),
        MikuBlocks.get("yellow_shulker_box"),
        MikuBlocks.get("lime_shulker_box"),
        MikuBlocks.get("pink_shulker_box"),
        MikuBlocks.get("gray_shulker_box"),
        MikuBlocks.get("cyan_shulker_box"),
        MikuBlocks.get("purple_shulker_box"),
        MikuBlocks.get("blue_shulker_box"),
        MikuBlocks.get("brown_shulker_box"),
        MikuBlocks.get("green_shulker_box"),
        MikuBlocks.get("red_shulker_box"),
        MikuBlocks.get("black_shulker_box"),
        Blocks.SCAFFOLDING,
        Blocks.LECTERN,
        Blocks.NOTE_BLOCK,
        Blocks.SMITHING_TABLE,
        Blocks.CARTOGRAPHY_TABLE,
        Blocks.BARREL,
        Blocks.BELL,
        Blocks.SWEET_BERRY_BUSH,
        Blocks.POWDER_SNOW_CAULDRON,
        Blocks.CAULDRON,
        Blocks.FURNACE,
        Blocks.BLAST_FURNACE,
        Blocks.SMOKER,
        Blocks.LEVER,
        Blocks.LOOM,
        Blocks.STONECUTTER,
        Blocks.BEACON,
        Blocks.REDSTONE_WIRE,
        Blocks.GRINDSTONE
    );


    /**
     * 需要潜行才能交互的方块类列表
     */
    public static final List<Class> SNEAK_BLOCK_CLASSES = Arrays.asList(SignBlock.class,
        DoorBlock.class,
        ButtonBlock.class,
        TrapdoorBlock.class,
        HangingSignBlock.class,
        ShulkerBoxBlock.class,
        WallSignBlock.class);


    /**
     * 检查指定位置是否可以放置方块
     *
     * @param pos 要检查的方块位置
     * @return 如果可以放置方块则返回 true，否则返回 false
     */
    public static boolean canPlace(BlockPos pos) {
        return getInteractDirection(pos, true) != null;
    }

    /**
     * 检查指定位置是否可以放置方块，支持严格方向检查
     *
     * @param pos             要检查的方块位置
     * @param strictDirection 是否启用严格方向检查
     * @return 如果可以放置方块则返回 true，否则返回 false
     */
    public static boolean canPlace(BlockPos pos, boolean strictDirection) {
        return getInteractDirection(pos, strictDirection) != null;
    }


    public static boolean canClick(BlockPos pos) {
        return mc.world.getBlockState(pos).isSolid()
            && (!SNEAK_BLOCKS.contains(getBlock(pos)) && !(getBlock(pos) instanceof BedBlock) || mc.player.isSneaking());
    }

    public static Block getBlock(BlockPos pos) {
        return mc.world.getBlockState(pos).getBlock();
    }

    public static boolean canReplace(BlockPos pos) {
        return mc.world.getBlockState(pos).isReplaceable();
    }

    public static ArrayList<Direction> checkAxis(double diff, Direction negativeSide, Direction positiveSide, boolean bothIfInRange) {
        ArrayList<Direction> valid = new ArrayList<>();
        if (diff < -0.5) {
            valid.add(negativeSide);
        }

        if (diff > 0.5) {
            valid.add(positiveSide);
        }

        if (bothIfInRange) {
            if (!valid.contains(negativeSide)) {
                valid.add(negativeSide);
            }

            if (!valid.contains(positiveSide)) {
                valid.add(positiveSide);
            }
        }

        return valid;
    }

    public static boolean isStrictDirection(BlockPos pos, Direction side) {
        if (mc.player.getBlockY() - pos.getY() >= 0 && side == Direction.DOWN) {
            return false;
        } else if (side == Direction.UP && pos.getY() + 1 > mc.player.getEyeY()) {
            return false;
        } else if (getBlock(pos.offset(side)) != Blocks.OBSIDIAN
            && getBlock(pos.offset(side)) != Blocks.BEDROCK
            && getBlock(pos.offset(side)) != Blocks.RESPAWN_ANCHOR) {
            Vec3d eyePos = getEyesPos();
            Vec3d blockCenter = Vec3d.ofCenter(pos);
            ArrayList<Direction> validAxis = new ArrayList<>();
            validAxis.addAll(checkAxis(eyePos.x - blockCenter.x, Direction.WEST, Direction.EAST, false));
            validAxis.addAll(checkAxis(eyePos.y - blockCenter.y, Direction.DOWN, Direction.UP, true));
            validAxis.addAll(checkAxis(eyePos.z - blockCenter.z, Direction.NORTH, Direction.SOUTH, false));
            return validAxis.contains(side);
        } else {
            return false;
        }
    }

    public static boolean canPlaceWithDis(BlockPos pos, double dis, boolean ignoreCrystal) {
        if (getPlaceSide(pos, dis) == null) {
            return false;
        }
        return canReplace(pos) && !hasEntityHere(pos, ignoreCrystal);
    }

    public static boolean hasEntityHere(BlockPos pos, boolean ignoreCrystal) {
        for (Entity entity : getEntities(new Box(pos))) {
            if (entity.isAlive()
                && !(entity instanceof ItemEntity)
                && !(entity instanceof ExperienceOrbEntity)
                && !(entity instanceof ExperienceBottleEntity)
                && !(entity instanceof ArrowEntity)
                && (!ignoreCrystal || !(entity instanceof EndCrystalEntity))) {
                if (entity instanceof ArmorStandEntity) {
                }

                return true;
            }
        }

        return false;
    }

    public static List<Entity> getEntities(Box box) {
        List<Entity> list = new ArrayList<>();

        for (Entity entity : mc.world.getEntities()) {
            if (entity != null && entity.getBoundingBox().intersects(box)) {
                list.add(entity);
            }
        }

        return list;
    }


    public static Direction getPlaceSide(BlockPos pos, double distance) {
        double dis = Integer.MAX_VALUE;
        Direction side = null;

        for (Direction i : DIRECTIONS) {
            if (canClick(pos.offset(i)) && !canReplace(pos.offset(i)) && canSeeBlockFace(pos.offset(i), i.getOpposite())) {
                double vecDis = mc
                    .player
                    .getEyePos()
                    .squaredDistanceTo(
                        Vec3d.ofCenter(pos)
                            .add(
                                i.getVector().getX() * 0.5,
                                i.getVector().getY() * 0.5,
                                i.getVector().getZ() * 0.5
                            )
                    );
                if (!(MathHelper.sqrt((float) vecDis) > distance) && (side == null || vecDis < dis)) {
                    side = i;
                    dis = vecDis;
                }
            }
        }

        return side;
    }

    public static Direction getPlaceSide(BlockPos pos) {
        if (pos == null) {
            return null;
        } else {
            double bestRelevancy = 999999.0;
            Direction side = null;

            for (Direction i : DIRECTIONS) {
                if (canClick(pos.offset(i)) && !canReplace(pos.offset(i)) && isStrictDirection(pos.offset(i), i.getOpposite())) {
                    double vecDis = mc
                        .player
                        .getEyePos()
                        .squaredDistanceTo(
                            Vec3d.ofCenter(pos)
                                .add(
                                    i.getVector().getX() * 0.5,
                                    i.getVector().getY() * 0.5,
                                    i.getVector().getZ() * 0.5
                                )
                        );
                    if (side == null || vecDis < bestRelevancy) {
                        side = i;
                        bestRelevancy = vecDis;
                    }
                }
            }

            return side;
        }
    }

    /**
     * 检查指定方块是否属于需要潜行才能交互的方块类型
     *
     * @param block 要检查的方块
     * @return 如果是需要潜行的方块类型则返回 true，否则返回 false
     */
    public static boolean isSneakBlockClass(Block block) {
        if (block == null) {
            return false;
        } else {
            for (Class clazz : SNEAK_BLOCK_CLASSES) {
                if (clazz.isInstance(block)) {
                    return true;
                }
            }

            return false;
        }
    }

    /**
     * 检查在指定条件下是否可以放置方块
     *
     * @param pos             要检查的方块位置
     * @param strictDirection 是否启用严格方向检查
     * @param direction       指定的方向
     * @return 如果满足条件可以放置方块则返回 true，否则返回 false
     */
    public static boolean canPlaceIf(BlockPos pos, boolean strictDirection, Direction direction) {
        return getInteractDirectionIf(pos, strictDirection, direction) != null;
    }

    /**
     * 在指定位置放置方块（使用默认参数）
     *
     * @param pos 要放置方块的位置
     * @return 如果成功放置方块则返回 true，否则返回 false
     */
    public static boolean placeItem(BlockPos pos, Item item) {
        int slot = BagUtil.findItemInventorySlotGrim(item);

        if (slot == -1) {
            return false;
        }
        BagUtil.doSwap(slot);

        boolean placed = placeBlock(pos, true, true, true);
        BagUtil.doSwap(slot);

        return placed;
    }

    /**
     * 在指定位置放置方块（使用默认参数）
     *
     * @param pos 要放置方块的位置
     * @return 如果成功放置方块则返回 true，否则返回 false
     */
    public static boolean placeItem(BlockPos pos, int slot) {

        BagUtil.doSwap(slot);

        boolean placed = placeBlock(pos, true, true, true);
        BagUtil.doSwap(slot);

        return placed;
    }

    /**
     * 在指定位置放置方块（使用默认参数）
     *
     * @param pos 要放置方块的位置
     * @return 如果成功放置方块则返回 true，否则返回 false
     */
    public static boolean placeBlock(BlockPos pos) {
        return placeBlock(pos, true, true, true);
    }

    /**
     * 在指定位置空中放置方块
     *
     * @param blockPos 要放置方块的位置
     * @return 如果成功放置方块则返回 true，否则返回 false
     */
    public static boolean airPlaceBlockOld(BlockPos blockPos) {
        Vec3d hitPos = Vec3d.ofCenter(blockPos, 0);

        BlockPos neighbour;
        Direction side = getPlaceSide(blockPos);

        if (side == null) {
            side = Direction.UP;
            neighbour = blockPos;
        } else {
            neighbour = blockPos.offset(side);
            hitPos = hitPos.add(side.getOffsetX() * 0.5, side.getOffsetY() * 0.5, side.getOffsetZ() * 0.5);
        }

        BlockHitResult bhr = new BlockHitResult(hitPos, side.getOpposite(), neighbour, false);


        boolean rot = RotationManager.getInstance().register(new Rotation(hitPos).setPriority(10));
        if (!rot) {
            return false;
        }

        BlockUtils.interact(bhr, Hand.MAIN_HAND, true);

        return true;
    }

    /**
     * 在指定位置空中放置方块
     *
     * @param pos 要放置方块的位置
     * @return 如果成功放置方块则返回 true，否则返回 false
     */
    public static boolean airPlaceBlock(BlockPos pos) {

        BlockPos neighbor;
        Direction side = getPlaceSide(pos);
        if (side == null) {
            side = Direction.UP;
            neighbor = pos;
        } else {
            neighbor = pos.offset(side.getOpposite());
        }

        return placeBlock(neighbor, side, true, true);

    }

    public static boolean breakBlock(BlockPos blockPos) {

        return breakBlock(blockPos, BlockUtils.getDirection(blockPos));

    }

    public static boolean breakBlock(BlockPos blockPos, Direction direction) {

        if (!BlockUtils.canBreak(blockPos, mc.world.getBlockState(blockPos))) {
            return false;
        } else {
            BlockPos pos = blockPos instanceof BlockPos.Mutable ? new BlockPos(blockPos) : blockPos;
            InstantRebreak ir = Modules.get().get(InstantRebreak.class);
            if (ir != null && ir.isActive() && ir.blockPos.equals(pos) && ir.shouldMine()) {
                ir.sendPacket();
                return true;
            } else {
                Vec3d hitVec = Vec3d.ofCenter(pos).add(new Vec3d(direction.getUnitVector()).multiply(0.5));

                boolean rot = RotationManager.getInstance().register(new Rotation(hitVec));
                if (!rot) {
                    return false;
                }
                if (mc.interactionManager.isBreakingBlock()) {
                    mc.interactionManager.updateBlockBreakingProgress(pos, BlockUtils.getDirection(blockPos));
                } else {
                    mc.interactionManager.attackBlock(pos, BlockUtils.getDirection(blockPos));
                }
                mc.player.swingHand(Hand.MAIN_HAND);

                return true;
            }
        }

    }

    /**
     * 在指定位置放置方块（使用默认参数）
     *
     * @param pos 要放置方块的位置
     * @return 如果成功放置方块则返回 true，否则返回 false
     */
    public static boolean placeBlock(BlockPos pos, Item item) {

        int slot = BagUtil.findItemInventorySlot(item);
        if (slot == -1) {
            return false;
        }
        if (mc.player.squaredDistanceTo(pos.getX(), pos.getY(), pos.getZ()) > 36) {
            return false;
        }

        BagUtil.doSwap(slot);

        boolean placed = placeBlock(pos, true, true, true);

        BagUtil.doSwap(slot);
        return placed;
    }

    /**
     * 在指定位置放置方块，支持自定义参数
     *
     * @param pos             要放置方块的位置
     * @param strictDirection 是否启用严格方向检查
     * @param clientSwing     是否在客户端显示挥手动画
     * @param rotate          是否自动旋转视角
     * @return 如果成功放置方块则返回 true，否则返回 false
     */
    public static boolean placeBlock(BlockPos pos, boolean strictDirection, boolean clientSwing, boolean rotate) {
        Direction direction = getInteractDirection(pos, strictDirection);
        if (direction == null) {
            return false;
        } else {
            BlockPos neighbor = pos.offset(direction.getOpposite());
            return placeBlock(neighbor, direction, clientSwing, rotate);
        }
    }

    /**
     * 在指定位置放置方块，支持自定义参数
     *
     * @param pos             要放置方块的位置
     * @param strictDirection 是否启用严格方向检查
     * @param clientSwing     是否在客户端显示挥手动画
     * @param rotate          是否自动旋转视角
     * @return 如果成功放置方块则返回 true，否则返回 false
     */
    public static boolean placeBlockDirectionOnly(BlockPos pos, boolean strictDirection, boolean clientSwing, boolean rotate, Direction only) {
        Direction direction = getInteractDirectionOnly(pos, strictDirection, only);
        if (direction == null) {
            return false;
        } else {
            BlockPos neighbor = pos.offset(direction.getOpposite());
            return placeBlock(neighbor, direction, clientSwing, rotate);
        }
    }

    /**
     * 在指定位置向上放置方块（适用于台阶等方块）
     *
     * @param pos             要放置方块的位置
     * @param strictDirection 是否启用严格方向检查
     * @param clientSwing     是否在客户端显示挥手动画
     * @param rotate          是否自动旋转视角
     * @return 如果成功放置方块则返回 true，否则返回 false
     */
    public static boolean placeUpBlock(BlockPos pos, boolean strictDirection, boolean clientSwing, boolean rotate) {
        Direction direction = getInteractDirectionSlabBlock(pos, strictDirection, true);
        if (direction == null) {
            return false;
        } else {
            BlockPos neighbor = pos.offset(direction.getOpposite());
            return placeUpBlock(neighbor, direction, clientSwing, rotate);
        }
    }

    /**
     * 在指定位置向下放置方块（适用于台阶等方块）
     *
     * @param pos             要放置方块的位置
     * @param strictDirection 是否启用严格方向检查
     * @param clientSwing     是否在客户端显示挥手动画
     * @param rotate          是否自动旋转视角
     * @return 如果成功放置方块则返回 true，否则返回 false
     */
    public static boolean placeDownBlock(BlockPos pos, boolean strictDirection, boolean clientSwing, boolean rotate) {
        Direction direction = getInteractDirectionSlabBlock(pos, strictDirection, false);
        if (direction == null) {
            return false;
        } else if (!canSeeBlockFace(pos, direction)) {
            return false;
        } else {
            BlockPos neighbor = pos.offset(direction.getOpposite());
            return placeDownBlock(neighbor, direction, clientSwing, rotate);
        }
    }

    /**
     * 检查是否能看到方块的指定面（射线检测）
     *
     * @param pos  方块位置
     * @param side 要检查的方块面方向
     * @return 如果能看到指定面则返回 true，否则返回 false
     */
    public static boolean canSeeBlockFace(BlockPos pos, Direction side) {
        if (side == null) {
            return false;
        } else {
            Vec3d testVec = Vec3d.ofCenter(pos)
                .add(
                    side.getVector().getX() * 0.5,
                    side.getVector().getY() * 0.5,
                    side.getVector().getZ() * 0.5
                );
            HitResult result = mc
                .world
                .raycast(new RaycastContext(getEyesPos(), testVec,
                    RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player));
            return result == null || result.getType() == HitResult.Type.MISS;
        }
    }

    /**
     * 获取玩家眼部位置的坐标
     *
     * @return 玩家眼部位置的 Vec3d 坐标
     */
    public static Vec3d getEyesPos() {
        return mc.player.getEyePos();
    }

    /**
     * 按指定朝向放置方块
     *
     * @param pos             要放置方块的位置
     * @param strictDirection 是否启用严格方向检查
     * @param clientSwing     是否在客户端显示挥手动画
     * @param rotate          是否自动旋转视角
     * @param faceDirection   方块的朝向
     * @return 如果成功放置方块则返回 true，否则返回 false
     */
    public static boolean placeBlockByFaceDirection(BlockPos pos, boolean strictDirection, boolean clientSwing,
                                                    boolean rotate, Direction faceDirection) {
        Direction direction = getInteractDirection(pos, strictDirection);
        if (direction == null) {
            return false;
        }

        BlockPos neighbor = pos.offset(direction.getOpposite());
        return placeBlockByFaceDirection(pos, neighbor, direction, clientSwing, rotate, faceDirection);
    }

    /**
     * 在指定位置向上放置方块（适用于台阶等方块）
     *
     * @param pos             要放置方块的位置
     * @param strictDirection 是否启用严格方向检查
     * @param clientSwing     是否在客户端显示挥手动画
     * @param rotate          是否自动旋转视角
     * @return 如果成功放置方块则返回 true，否则返回 false
     */
    public static boolean placeUpBlockByFaceDirection(BlockPos pos, boolean strictDirection, boolean clientSwing, boolean rotate, Direction placementDirection) {
        Direction direction = getInteractDirectionSlabBlock(pos, strictDirection, true);
        if (direction == null) {
            return false;
        } else {
            BlockPos neighbor = pos.offset(direction.getOpposite());
            return placeUpBlockByFaceDirection(pos, neighbor, direction, clientSwing, rotate, placementDirection);
        }
    }

    /**
     * 按指定朝向放置方块（详细版本）
     *
     * @param initPos       初始位置
     * @param pos           目标位置
     * @param direction     放置方向
     * @param clientSwing   是否在客户端显示挥手动画
     * @param rotate        是否自动旋转视角
     * @param faceDirection 方块的朝向
     * @return 如果成功放置方块则返回 true，否则返回 false
     */
    public static boolean placeBlockByFaceDirection(
        BlockPos initPos, BlockPos pos, Direction direction, boolean clientSwing, boolean rotate, Direction faceDirection
    ) {
        Vec3d hitVec = Vec3d.ofCenter(pos).add(new Vec3d(direction.getUnitVector()).multiply(0.5));
        if (rotate) {
            Rotation rotation = new Rotation(hitVec).setPriority(10);
            RotationManager.getInstance().register(rotation);
        }

        Rotation rotation = new Rotation(hitVec).setPriority(10);
        rotation.setYaw(getDirectionYaw(faceDirection));

        // 根据 faceDirection 动态设置 pitch (俯仰角)
        float pitch;
        if (faceDirection == Direction.UP) {
            pitch = -90.0F; // 向上看 (抬头90度)
        } else if (faceDirection == Direction.DOWN) {
            pitch = 90.0F;  // 向下看 (低头90度)
        } else {
            pitch = 5.0F;   // 水平方向保持默认抬头5度
        }
        rotation.setPitch(pitch);

        boolean rot = RotationManager.getInstance().register(rotation);

        boolean placed = placeBlockImmediately(new BlockHitResult(hitVec, direction, pos, false), clientSwing);

        if (!rot) {
            return false;
        }
        return placed;
    }

    /**
     * 按指定朝向放置方块（详细版本）
     *
     * @param initPos       初始位置
     * @param pos           目标位置
     * @param direction     放置方向
     * @param clientSwing   是否在客户端显示挥手动画
     * @param rotate        是否自动旋转视角
     * @param faceDirection 方块的朝向
     * @return 如果成功放置方块则返回 true，否则返回 false
     */
    public static boolean placeUpBlockByFaceDirection(
        BlockPos initPos, BlockPos pos, Direction direction, boolean clientSwing, boolean rotate, Direction faceDirection
    ) {
        Vec3d hitVec = Vec3d.ofCenter(pos).add(new Vec3d(direction.getUnitVector()).multiply(0.5)).add(0.0, 0.3, 0.0);
        if (rotate) {
            Rotation rotation = new Rotation(hitVec).setPriority(10);
            RotationManager.getInstance().register(rotation);
            rotation.setYaw(getDirectionYaw(faceDirection));
            // 根据 faceDirection 动态设置 pitch (俯仰角)
            float pitch;
            if (faceDirection == Direction.UP) {
                pitch = -90.0F; // 向上看 (抬头90度)
            } else if (faceDirection == Direction.DOWN) {
                pitch = 90.0F;  // 向下看 (低头90度)
            } else {
                pitch = 5.0F;   // 水平方向保持默认抬头5度
            }
            rotation.setPitch(pitch);

            boolean rotated = RotationManager.getInstance().register(rotation);
            if (!rotated) {
                return false;
            }
        }

        boolean placed = placeBlockImmediately(new BlockHitResult(hitVec, direction, pos, false), clientSwing);
        RotationManager.getInstance().sync();
        return placed;
    }

    /**
     * 根据方向获取对应的偏航角度
     *
     * @param direction 方向
     * @return 对应的偏航角度（度）
     */
    public static float getDirectionYaw(Direction direction) {
        if (direction == null) {
            return 0.0F;
        } else {
            switch (direction) {
                case NORTH:
                    return 180.0F;
                case SOUTH:
                    return 0.0F;
                case WEST:
                    return 90.0F;
                case EAST:
                    return -90.0F;
                default:
                    return 0.0F;
            }
        }
    }

    /**
     * 在指定位置和方向放置方块
     *
     * @param pos         方块位置
     * @param direction   放置方向
     * @param clientSwing 是否在客户端显示挥手动画
     * @param rotate      是否自动旋转视角
     * @return 如果成功放置方块则返回 true，否则返回 false
     */
    public static boolean placeBlock(BlockPos pos, Direction direction, boolean clientSwing, boolean rotate) {

        Vec3d hitVec = Vec3d.ofCenter(pos).add(new Vec3d(direction.getUnitVector()).multiply(MikuMagic2.hit));
        if (rotate) {
            boolean rot = RotationManager.getInstance().register(new Rotation(hitVec).setPriority(10));
            if (!rot) {
                return false;
            }
        }

        boolean placed = placeBlockImmediately(new BlockHitResult(hitVec, direction, pos, false), clientSwing);
        RotationManager.getInstance().sync();
        return placed;
    }

    /**
     * 在指定位置向上放置方块（台阶等）
     *
     * @param pos         方块位置
     * @param direction   放置方向
     * @param clientSwing 是否在客户端显示挥手动画
     * @param rotate      是否自动旋转视角
     * @return 如果成功放置方块则返回 true，否则返回 false
     */
    public static boolean placeUpBlock(BlockPos pos, Direction direction, boolean clientSwing, boolean rotate) {
        Vec3d hitVec = Vec3d.ofCenter(pos).add(0.0, 0.3, 0.0);
        if (rotate) {
            boolean rot = RotationManager.getInstance().register(new Rotation(hitVec).setPriority(10));
            if (!rot) {
                return false;
            }
        }

        boolean placed = placeBlockImmediately(new BlockHitResult(hitVec, direction, pos, false), clientSwing);
        RotationManager.getInstance().sync();
        return placed;
    }

    /**
     * 在指定位置向下放置方块（台阶等）
     *
     * @param pos         方块位置
     * @param direction   放置方向
     * @param clientSwing 是否在客户端显示挥手动画
     * @param rotate      是否自动旋转视角
     * @return 如果成功放置方块则返回 true，否则返回 false
     */
    public static boolean placeDownBlock(BlockPos pos, Direction direction, boolean clientSwing, boolean rotate) {
        Vec3d hitVec = Vec3d.ofCenter(pos).add(0.0, -0.2, 0.0);
        if (rotate) {
            boolean rot = RotationManager.getInstance().register(new Rotation(hitVec).setPriority(10));
            if (!rot) {
                return false;
            }
        }

        boolean placed = placeBlockImmediately(new BlockHitResult(hitVec, direction, pos, false), clientSwing);
        RotationManager.getInstance().sync();
        return placed;
    }

    /**
     * 使用方块命中结果 立即放置方块，处理潜行和挥手逻辑
     *
     * @param result      方块命中结果
     * @param clientSwing 是否在客户端显示挥手动画
     * @return 如果成功放置方块则返回 true，否则返回 false
     */
    public static boolean placeBlockImmediately(BlockHitResult result, boolean clientSwing) {
        if (MikuMagic2.hit == 10) {
            return true;
        }
        BlockState state = mc.world.getBlockState(result.getBlockPos());
        boolean shouldSneak = (SNEAK_BLOCKS.contains(state.getBlock())
            || isSneakBlockClass(mc.world.getBlockState(result.getBlockPos()).getBlock()))
            && !mc.player.isSneaking();
        if (shouldSneak) {
            Via.sendPressShift();
        }

        ActionResult actionResult = placeBlockInternally(result);
        if (actionResult.isAccepted()) {
            if (clientSwing) {
                mc.player.swingHand(Hand.MAIN_HAND);
            } else {
                mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
            }
        }

        if (shouldSneak) {
            Via.sendReleaseShift();
        }

        return actionResult.isAccepted();
    }

    /**
     * 内部方块放置方法
     *
     * @param hitResult 方块命中结果
     * @return 交互结果
     */
    private static ActionResult placeBlockInternally(BlockHitResult hitResult) {
        return mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hitResult);
    }

    /**
     * 获取可以交互的方向
     *
     * @param blockPos        方块位置
     * @param strictDirection 是否启用严格方向检查
     * @return 可以交互的方向，如果没有则返回 null
     */
    public static Direction getInteractDirection(BlockPos blockPos, boolean strictDirection) {
        Set<Direction> ncpDirections = getPlaceDirectionsNCP(mc.player.getEyePos(), Vec3d.ofCenter(blockPos));
        Direction interactDirection = null;

        for (Direction direction : DIRECTIONS) {
            BlockState state = mc.world.getBlockState(blockPos.offset(direction));
            if (!state.isAir()
                && !(state.getBlock() instanceof FluidBlock)
                && (!strictDirection || ncpDirections.contains(direction.getOpposite()))) {
                interactDirection = direction;
                break;
            }
        }

        return interactDirection == null ? null : interactDirection.getOpposite();
    }

    /**
     * 获取指定交互的方向
     *
     * @param blockPos        方块位置
     * @param strictDirection 是否启用严格方向检查
     * @return 可以交互的方向，如果没有则返回 null
     */
    public static Direction getInteractDirectionOnly(BlockPos blockPos, boolean strictDirection, Direction only) {
        Set<Direction> ncpDirections = getPlaceDirectionsNCP(mc.player.getEyePos(), Vec3d.ofCenter(blockPos));
        Direction interactDirection = null;

        for (Direction direction : DIRECTIONS) {
            BlockState state = mc.world.getBlockState(blockPos.offset(direction));
            if (!state.isAir()
                && !(state.getBlock() instanceof FluidBlock)
                && (!strictDirection || ncpDirections.contains(direction.getOpposite()))) {
                if (direction == only) {
                    interactDirection = direction;
                    break;
                }
            }
        }

        return interactDirection == null ? null : interactDirection.getOpposite();
    }

    /**
     * 获取可以交互的方向
     *
     * @param blockPos        方块位置
     * @param strictDirection 是否启用严格方向检查
     * @return 可以交互的方向，如果没有则返回 null
     */
    public static List<Direction> getInteractDirections(BlockPos blockPos, boolean strictDirection) {
        Set<Direction> ncpDirections = getPlaceDirectionsNCP(mc.player.getEyePos(), Vec3d.ofCenter(blockPos));
        List<Direction> directions = new ArrayList<>();
        for (Direction direction : DIRECTIONS) {
            BlockState state = mc.world.getBlockState(blockPos.offset(direction));
            if (!state.isAir()
                && !(state.getBlock() instanceof FluidBlock)
                && (!strictDirection || ncpDirections.contains(direction.getOpposite()))) {
                directions.add(direction.getOpposite());
            }
        }

        return directions;
    }

    /**
     * 获取可以交互的方向（排除上下方向）
     *
     * @param blockPos        方块位置
     * @param strictDirection 是否启用严格方向检查
     * @return 可以交互的方向（不包括上下），如果没有则返回 null
     */
    public static Direction getInteractDirectionExitUpDown(BlockPos blockPos, boolean strictDirection) {
        Set<Direction> ncpDirections = getPlaceDirectionsNCP(mc.player.getEyePos(), Vec3d.ofCenter(blockPos));
        Direction interactDirection = null;

        for (Direction direction : DIRECTIONS) {
            BlockState state = mc.world.getBlockState(blockPos.offset(direction));
            if (!state.isAir()
                && state.getFluidState().isEmpty()
                && (!strictDirection || ncpDirections.contains(direction.getOpposite()))
                && direction != Direction.UP
                && direction != Direction.DOWN) {
                interactDirection = direction;
                break;
            }
        }

        return interactDirection == null ? null : interactDirection.getOpposite();
    }

    /**
     * 根据条件获取可以交互的方向
     *
     * @param blockPos        方块位置
     * @param strictDirection 是否启用严格方向检查
     * @param direction_      指定的方向条件
     * @return 满足条件的交互方向，如果没有则返回 null
     */
    public static Direction getInteractDirectionIf(BlockPos blockPos, boolean strictDirection, Direction direction_) {
        Set<Direction> ncpDirections = getPlaceDirectionsNCP(mc.player.getEyePos(), Vec3d.ofCenter(blockPos));
        Direction interactDirection = null;

        for (Direction direction : DIRECTIONS) {
            BlockState state = mc.world.getBlockState(blockPos.offset(direction));

            if ((!state.isAir()
                && state.getFluidState().isEmpty() || direction == direction_)
                && (!strictDirection || ncpDirections.contains(direction.getOpposite()))) {
                interactDirection = direction;
                break;
            }
        }

        return interactDirection == null ? null : interactDirection.getOpposite();
    }

    /**
     * 获取台阶方块的交互方向（仅水平方向）
     *
     * @param blockPos        方块位置
     * @param strictDirection 是否启用严格方向检查
     * @return 可以交互的水平方向，如果没有则返回 null
     */
    public static Direction getInteractDirectionSlabBlock(BlockPos blockPos, boolean strictDirection, boolean up) {
        Set<Direction> ncpDirections = getPlaceDirectionsNCP(mc.player.getEyePos(), Vec3d.ofCenter(blockPos));
        Direction interactDirection = null;


        // === 垂直支撑判断 ===
        if (up) {
            BlockState upState = mc.world.getBlockState(blockPos.up());
            if (!upState.isAir() && upState.getFluidState().isEmpty()
                && (!strictDirection || ncpDirections.contains(Direction.UP.getOpposite()))
            ) {

                return Direction.DOWN;
            }
        } else {
            BlockState downState = mc.world.getBlockState(blockPos.down());
            if (!downState.isAir() && downState.getFluidState().isEmpty()
                && (!strictDirection || ncpDirections.contains(Direction.DOWN.getOpposite()))
            ) {

                return Direction.UP;
            }
        }

        for (Direction direction : Direction.Type.HORIZONTAL) {
            if (direction != Direction.UP && direction != Direction.DOWN) {
                BlockState state = mc.world.getBlockState(blockPos.offset(direction));
                if (!state.isAir() && state.getFluidState().isEmpty()
                    && (!strictDirection || ncpDirections.contains(direction.getOpposite()))) {

                    if (state.getBlock() instanceof SlabBlock) {
                        SlabType slabType = state.get(Properties.SLAB_TYPE);
                        if (slabType == SlabType.DOUBLE) {
                            interactDirection = direction;
                            break;
                        } else if (slabType == SlabType.BOTTOM && !up) {
                            interactDirection = direction;
                            break;
                        } else if (slabType == SlabType.TOP && up) {
                            interactDirection = direction;
                            break;
                        }

                    } else {
                        interactDirection = direction;
                        break;
                    }
                }
            }
        }

        return interactDirection == null ? null : interactDirection.getOpposite();
    }

    /**
     * 获取 NCP（NoCheatPlus）兼容的放置方向集合
     *
     * @param eyePos   眼部位置
     * @param blockPos 方块位置
     * @return 可用的放置方向集合
     */
    public static Set<Direction> getPlaceDirectionsNCP(Vec3d eyePos, Vec3d blockPos) {
        return getPlaceDirectionsNCP(eyePos.x, eyePos.y, eyePos.z, blockPos.x, blockPos.y, blockPos.z);
    }

    /**
     * 根据坐标差计算 NCP 兼容的放置方向集合
     *
     * @param x  眼部 X 坐标
     * @param y  眼部 Y 坐标
     * @param z  眼部 Z 坐标
     * @param dx 目标 X 坐标
     * @param dy 目标 Y 坐标
     * @param dz 目标 Z 坐标
     * @return 可用的放置方向集合
     */
    public static Set<Direction> getPlaceDirectionsNCP(double x, double y, double z, double dx, double dy, double dz) {
        double xdiff = x - dx;
        double ydiff = y - dy;
        double zdiff = z - dz;
        Set<Direction> dirs = EnumSet.noneOf(Direction.class);
        if (ydiff > 0.5) {
            dirs.add(Direction.UP);
        } else if (ydiff < -0.5) {
            dirs.add(Direction.DOWN);
        } else {
            dirs.add(Direction.UP);
            dirs.add(Direction.DOWN);
        }

        if (xdiff > 0.5) {
            dirs.add(Direction.EAST);
        } else if (xdiff < -0.5) {
            dirs.add(Direction.WEST);
        } else {
            dirs.add(Direction.EAST);
            dirs.add(Direction.WEST);
        }

        if (zdiff > 0.5) {
            dirs.add(Direction.SOUTH);
        } else if (zdiff < -0.5) {
            dirs.add(Direction.NORTH);
        } else {
            dirs.add(Direction.SOUTH);
            dirs.add(Direction.NORTH);
        }

        return dirs;
    }


    /**
     * 目的是在指定方向点击一个方块，可选是否旋转视角，支持设置挥手方向。
     * pos	BlockPos	要点击的方块位置（block 坐标）
     * side	WalkDirection	点击方块的哪一侧（如 WalkDirection.UP）
     * rotate	boolean	是否旋转视角对准点击位置
     * hand	Hand	使用哪只手点击（MAIN_HAND 或 OFF_HAND）
     * swingSide	SwingSide	玩家动画挥手方向（仅客户端视觉）
     * <p>
     * BaritoneUtil.clickBlock(plantPos.get(i), WalkDirection.UP, true, Hand.MAIN_HAND, SwingSide.All);
     *
     * @param pos
     * @param side
     * @param rotate
     * @param hand
     * @param swingSide
     */
    public static void clickBlock(BlockPos pos, Direction side, boolean rotate, Hand hand, SwingSide swingSide) {
        Vec3d directionVec = new Vec3d(
            pos.getX()
                + 0.5
                + side.getVector().getX() * 0.5,
            pos.getY()
                + 0.5
                + side.getVector().getY() * 0.5,
            pos.getZ()
                + 0.5
                + side.getVector().getZ() * 0.5
        );
        swingHand(hand, swingSide);
        BlockHitResult result = new BlockHitResult(directionVec, side, pos, false);
        if (rotate) {
            boolean rot = RotationManager.getInstance().register(new Rotation(directionVec).setPriority(10));
            if (!rot) {
                return;
            }
        }

        BaseModule.sendSequencedPacket(id -> new PlayerInteractBlockC2SPacket(hand, result, id));
        RotationManager.getInstance().sync();
    }

    /**
     * 挥手动作
     *
     * @param hand 使用的手（主手或副手）
     * @param side 挥手方式（全部、仅客户端、仅服务器）
     */
    public static void swingHand(Hand hand, SwingSide side) {
        switch (side) {
            case All:
                mc.player.swingHand(hand);
                break;
            case Client:
                mc.player.swingHand(hand, false);
                break;
            case Server:
                mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(hand));
        }
    }

    /**
     * 检查指定位置是否与实体相交（排除末影水晶）
     *
     * @param pos 要检查的方块位置
     * @return 如果与实体相交则返回 true，否则返回 false
     */
    public static boolean isIntersectsEntity(BlockPos pos) {
        if (pos == null) {
            return true;
        } else {
            for (Entity entity : mc.world.getEntities()) {
                if (!(entity instanceof EndCrystalEntity)
                    && (
                    entity.getBoundingBox().intersects(new Box(pos)) && entity.isOnGround()
                        || entity instanceof ItemEntity && entity.getBoundingBox().intersects(new Box(pos.up()))
                )) {
                    return true;
                }
            }

            return false;
        }
    }

    /**
     * 检查指定位置是否与任何实体相交
     *
     * @param pos 要检查的方块位置
     * @return 如果与任何实体相交则返回 true，否则返回 false
     */
    public static boolean isIntersectsAnyEntity(BlockPos pos) {
        if (pos == null) {
            return true;
        } else {
            for (Entity entity : mc.world.getEntities()) {
                if (entity.getBoundingBox().intersects(new Box(pos))) {
                    return true;
                }
            }

            return false;
        }
    }

    public static Direction getPlaceDirection(BlockPos pos, boolean ignoreContainers) {
        if (pos == null) {
            return null;
        }
        Direction best = null;
        if (mc.world != null && mc.player != null) {

            double cDist = -1;
            for (Direction dir : DIRECTIONS) {

                // Doesn't place on top of max height
                if (pos.offset(dir).getY() >= 319) {
                    continue;
                }

                // Checks if block is an entity (chests, shulkers)
                if (ignoreContainers && mc.world.getBlockState(pos.offset(dir)).hasBlockEntity()) {
                    continue;
                }

                // Test if there is block in the side and if predicate is valid
                Block b = mc.world.getBlockState(pos.offset(dir)).getBlock();
                if (b instanceof AbstractFireBlock || b instanceof FluidBlock || b instanceof AirBlock) {
                    continue;
                }


                // Only accepts if closer than previous accepted direction
                double dist = PlayerUtils.distanceTo(pos.offset(dir));
                if (dist >= 0 && (cDist < 0 || dist < cDist)) {
                    best = dir;
                    cDist = dist;
                }
            }
        }
        return best;
    }

    public static Direction getPlaceOnDirection(BlockPos pos) {
        if (pos == null) {
            return null;
        }
        Direction best = null;
        if (mc.world != null && mc.player != null) {
            double cDist = -1;
            for (Direction dir : DIRECTIONS) {

                // Doesn't place on top of max height
                if (pos.offset(dir).getY() >= 319) {
                    continue;
                }

                // Test if there is block in the side and if predicate is valid
                Block b = mc.world.getBlockState(pos.offset(dir)).getBlock();
                if (!(b instanceof AbstractFireBlock || b instanceof FluidBlock || b instanceof AirBlock)) {
                    continue;
                }

                // Only accepts if closer than last accepted direction
                double dist = mc.player.getEyePos().distanceTo(Vec3d.ofCenter(pos.offset(dir)));
                if (dist >= 0 && (cDist < 0 || dist < cDist)) {
                    best = dir;
                    cDist = dist;
                }
            }
        }
        return best;
    }


    /**
     * 挥手方式枚举
     */
    public enum SwingSide {
        /**
         * 全部（客户端和服务器）
         */
        All,
        /**
         * 仅客户端
         */
        Client,
        /**
         * 仅服务器
         */
        Server,
        /**
         * 无挥手
         */
        None
    }

}
