/*
 * 本文件属于 meteor-miku 项目：https://github.com/mikumiku7/meteor-miku
 * meteor-miku 是 meteor-rejects 在 Minecraft 26.1 / Fabric 上的移植版本。
 *
 * Copyright (C) 2024-2026 XC_XinCheng
 *
 * SPDX-License-Identifier: GPL-3.0-only
 *
 * 本程序是自由软件：你可以依据 GNU 通用公共许可证（GNU GPL）第 3 版的条款
 * 重新发布和/或修改它。
 *
 * 本程序基于“有用”的期望分发，但不提供任何担保，甚至不提供适销性或特定
 * 用途适用性的默示担保。详见 GNU 通用公共许可证。
 *
 * 你应当已随本程序收到一份 GNU 通用公共许可证副本；如果没有，请见
 * <https://www.gnu.org/licenses/>。
 */
package com.github.mikumiku.addon.modules;

import com.github.mikumiku.addon.BaseModule;
import com.github.mikumiku.addon.util.MikuEntities;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.misc.AutoReconnect;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.entity.DamageUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.network.DisconnectionInfo;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Colors;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class AutoLog extends BaseModule {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgEntities = settings.createGroup("实体设置");
    private final SettingGroup sgLogging = settings.createGroup("日志设置");

    private final Setting<Integer> health = sgGeneral.add(new IntSetting.Builder()
        .name("生命值阈值")
        .description("当生命值低于或等于此值时自动断开连接。设置为0禁用此功能。")
        .defaultValue(6)
        .range(0, 19)
        .sliderMax(19)
        .build()
    );

    private final Setting<Boolean> smart = sgGeneral.add(new BoolSetting.Builder()
        .name("智能预测")
        .description("检测到即将受到足够伤害使生命值低于设定阈值时断开连接。")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> onlyTrusted = sgGeneral.add(new BoolSetting.Builder()
        .name("仅信任玩家")
        .description("当不在好友列表中的玩家出现在渲染距离内时断开连接。")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> instantDeath = sgGeneral.add(new BoolSetting.Builder()
        .name("防32K武器")
        .description("当附近玩家能够瞬间杀死你时断开连接。")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> smartToggle = sgGeneral.add(new BoolSetting.Builder()
        .name("智能切换")
        .description("低血量断线后禁用自动登出。治疗后会重新启用。")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> toggleOff = sgGeneral.add(new BoolSetting.Builder()
        .name("使用后关闭")
        .description("使用后禁用自动登出模块。")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> onlyWhenPlayersNearby = sgGeneral.add(new BoolSetting.Builder()
        .name("仅当有玩家时断开")
        .description("只有当附近30格内有非好友玩家时，其他断开连接功能才会生效。")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> totemCheck = sgGeneral.add(new BoolSetting.Builder()
        .name("图腾检查")
        .description("启用图腾数量检查，当图腾数量低于设定值时断开连接。")
        .defaultValue(false)
        .build()
    );

    private final Setting<Integer> totemCount = sgGeneral.add(new IntSetting.Builder()
        .name("最少图腾数量")
        .description("当图腾数量低于此值时断开连接。")
        .defaultValue(3)
        .range(0, 37)
        .sliderRange(0, 37)
        .visible(() -> totemCheck.get())
        .build()
    );

    // Entities

    // 26.2 移除了 EntityType.END_CRYSTAL 静态字段，默认值改为按注册名解析，避免运行时崩溃。
    private static EntityType<?>[] defaultMonitoredEntities() {
        EntityType<?> endCrystal = MikuEntities.endCrystal();
        return endCrystal == null ? new EntityType<?>[0] : new EntityType<?>[]{endCrystal};
    }

    private final Setting<Set<EntityType<?>>> entities = sgEntities.add(new EntityTypeListSetting.Builder()
        .name("监控实体")
        .description("当指定实体出现在指定范围内时断开连接。")
        .defaultValue(defaultMonitoredEntities())
        .build()
    );

    private final Setting<Boolean> useTotalCount = sgEntities.add(new BoolSetting.Builder()
        .name("使用总数计算")
        .description("在计算所有选定实体的总数或单独计算每种实体之间切换。")
        .defaultValue(true)
        .visible(() -> !entities.get().isEmpty())
        .build());

    private final Setting<Integer> combinedEntityThreshold = sgEntities.add(new IntSetting.Builder()
        .name("总数阈值")
        .description("触发断开连接前，附近选定实体的最小总数。")
        .defaultValue(10)
        .min(1)
        .sliderMax(32)
        .visible(() -> useTotalCount.get() && !entities.get().isEmpty())
        .build()
    );

    private final Setting<Integer> individualEntityThreshold = sgEntities.add(new IntSetting.Builder()
        .name("单个实体阈值")
        .description("触发断开连接前，单个实体类型附近的最小数量。")
        .defaultValue(2)
        .min(1)
        .sliderMax(16)
        .visible(() -> !useTotalCount.get() && !entities.get().isEmpty())
        .build()
    );

    private final Setting<Integer> range = sgEntities.add(new IntSetting.Builder()
        .name("检测范围")
        .description("实体距离你多近时触发断开连接。")
        .defaultValue(5)
        .min(1)
        .sliderMax(16)
        .visible(() -> !entities.get().isEmpty())
        .build()
    );

    // Logging settings

    private final Setting<Boolean> logDisconnectReason = sgLogging.add(new BoolSetting.Builder()
        .name("记录断开原因")
        .description("记录断开连接的详细原因")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> logNearbyPlayers = sgLogging.add(new BoolSetting.Builder()
        .name("记录视野内玩家")
        .description("断开连接时报告视野内的所有玩家")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> logCoordinates = sgLogging.add(new BoolSetting.Builder()
        .name("记录坐标")
        .description("断开连接时记录当前坐标")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> logToChat = sgLogging.add(new BoolSetting.Builder()
        .name("聊天显示日志")
        .description("是否在聊天中显示详细的断开连接信息")
        .defaultValue(true)
        .build()
    );

    //Declaring variables outside the loop for better efficiency
    private final Object2IntMap<EntityType<?>> entityCounts = new Object2IntOpenHashMap<>();

    public AutoLog() {
        super(BaseModule.CATEGORY_MIKU_COMBAT, "智能Log", "当满足特定条件时自动断开连接。log界面报告视野内玩家和log坐标");
    }

    /**
     * 检查附近30格内是否有非好友玩家
     */
    private boolean hasNonFriendPlayersNearby() {
        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player.getUuid() != mc.player.getUuid()) {
                if (PlayerUtils.isWithin(player, 30) && !Friends.get().isFriend(player)) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public void onActivate() {
        super.onActivate();

    }


    @EventHandler
    private void onTick(TickEvent.Post event) {
        float playerHealth = mc.player.getHealth();
        if (playerHealth <= 0) {
            this.toggle();
            return;
        }

        // 图腾数量检查
        if (totemCheck.get()) {
            int totems = mc.player.getInventory().count(Items.TOTEM_OF_UNDYING);
            if (totems <= totemCount.get()) {
                disconnect("图腾数量低于 " + totemCount.get() + " (当前: " + totems + ")。");
                if (toggleOff.get()) this.toggle();
                return;
            }
        }

        // 如果启用了"仅当有玩家时断开"，检查附近是否有非好友玩家
        if (onlyWhenPlayersNearby.get() && !hasNonFriendPlayersNearby()) {
            return; // 附近没有非好友玩家，跳过所有断开连接检查
        }

        if (playerHealth <= health.get()) {
            disconnect("生命值低于 " + health.get() + "。");
            if (smartToggle.get()) {
                if (isActive()) this.toggle();
                enableHealthListener();
            } else if (toggleOff.get()) this.toggle();
            return;
        }

        if (smart.get() && playerHealth + mc.player.getAbsorptionAmount() - PlayerUtils.possibleHealthReductions() < health.get()) {
            disconnect("生命值即将低于 " + health.get() + "。");
            if (toggleOff.get()) this.toggle();
            return;
        }

        if (!onlyTrusted.get() && !instantDeath.get() && entities.get().isEmpty())
            return; // only check all entities if needed

        for (Entity entity : mc.world.getEntities()) {
            if (entity instanceof PlayerEntity player && player.getUuid() != mc.player.getUuid()) {
                if (onlyTrusted.get() && player != mc.player && !Friends.get().isFriend(player)) {
                    disconnect(Text.literal("不受信任的玩家 '" + Formatting.RED + player.getName().getString() + Formatting.WHITE + "' 出现在渲染距离内。"));
                    if (toggleOff.get()) this.toggle();
                    return;
                }

                if (instantDeath.get() && PlayerUtils.isWithin(entity, 8) && DamageUtils.getAttackDamage(player, mc.player)
                    > playerHealth + mc.player.getAbsorptionAmount()) {
                    disconnect("检测到32K武器威胁。");
                    if (toggleOff.get()) this.toggle();
                    return;
                }
            }
        }

        // Entities detection Logic
        if (!entities.get().isEmpty()) {
            // Reset totalEntities count and clear the entityCounts map
            int totalEntities = 0;
            entityCounts.clear();

            // Iterate through all entities in the world and count the ones that match the selected types and are within range
            for (Entity entity : mc.world.getEntities()) {
                if (PlayerUtils.isWithin(entity, range.get()) && entities.get().contains(entity.getType())) {
                    totalEntities++;
                    if (!useTotalCount.get()) {
                        entityCounts.put(entity.getType(), entityCounts.getOrDefault(entity.getType(), 0) + 1);
                    }
                }
            }

            if (useTotalCount.get() && totalEntities >= combinedEntityThreshold.get()) {
                disconnect("范围内选定实体总数超过限制。");
                if (toggleOff.get()) this.toggle();
            } else if (!useTotalCount.get()) {
                // 检查每种实体类型的数量是否超过指定限制
                for (Object2IntMap.Entry<EntityType<?>> entry : entityCounts.object2IntEntrySet()) {
                    if (entry.getIntValue() >= individualEntityThreshold.get()) {
                        disconnect("范围内 " + entry.getKey().getName().getString() + " 数量超过限制。");
                        if (toggleOff.get()) this.toggle();
                        return;
                    }
                }
            }
        }
    }

    private void disconnect(String reason) {
        disconnect(Text.literal(reason));
    }

    private void disconnect(Text reason) {
        MutableText disconnectText = Text.literal("[自动登出] ");
        disconnectText.append(reason);

        // 生成详细的日志信息
        MutableText detailedLog = generateDetailedLog(reason);

        // 如果启用聊天显示日志
        if (logToChat.get()) {
            info("=== 自动登出详细信息 ===");
            info("断开原因: " + reason.getString());

            if (logCoordinates.get()) {
                BlockPos pos = mc.player.getBlockPos();
                info("坐标: X=" + pos.getX() + ", Y=" + pos.getY() + ", Z=" + pos.getZ());
            }

            if (totemCheck.get()) {
                int totems = mc.player.getInventory().count(Items.TOTEM_OF_UNDYING);
                info("图腾数量: " + totems);
            }

            if (logNearbyPlayers.get()) {
                List<String> nearbyPlayers = getNearbyPlayersInfo();
                if (!nearbyPlayers.isEmpty()) {
                    info("视野内玩家 (" + nearbyPlayers.size() + "):");
                    for (String playerInfo : nearbyPlayers) {
                        info("  " + playerInfo);
                    }
                } else {
                    info("视野内无其他玩家");
                }
            }
            info("========================");
        }

        // 将详细信息添加到断开连接消息中
        if (logDisconnectReason.get()) {
            disconnectText.append(Text.literal("\n\n=== 详细信息 ===").withColor(Colors.YELLOW));

            if (logCoordinates.get()) {
                BlockPos pos = mc.player.getBlockPos();
                disconnectText.append(Text.literal("\n坐标: " + pos.getX() + ", " + pos.getY() + ", " + pos.getZ()).withColor(Colors.WHITE));
            }

            if (totemCheck.get()) {
                int totems = mc.player.getInventory().count(Items.TOTEM_OF_UNDYING);
                disconnectText.append(Text.literal("\n图腾数量: " + totems).withColor(Colors.WHITE));
            }

            if (logNearbyPlayers.get()) {
                List<String> nearbyPlayers = getNearbyPlayersInfo();
                if (!nearbyPlayers.isEmpty()) {
                    disconnectText.append(Text.literal("\n视野内玩家 (" + nearbyPlayers.size() + "):").withColor(Colors.WHITE));
                    for (String playerInfo : nearbyPlayers) {
                        disconnectText.append(Text.literal("\n  " + playerInfo).withColor(Colors.GRAY));
                    }
                } else {
                    disconnectText.append(Text.literal("\n视野内无其他玩家").withColor(Colors.GRAY));
                }
            }
        }

        AutoReconnect autoReconnect = Modules.get().get(AutoReconnect.class);
        if (autoReconnect.isActive()) {
            disconnectText.append(Text.literal("\n\n信息 - 自动重连已禁用").withColor(Colors.GRAY));
            autoReconnect.toggle();
        }

        mc.disconnect(disconnectText);
    }

    /**
     * 获取视野内玩家信息
     */
    private List<String> getNearbyPlayersInfo() {
        List<String> playerInfoList = new ArrayList<>();

        if (mc.world == null || mc.player == null) return playerInfoList;

        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player.getUuid() != mc.player.getUuid()) {
                double distance = Math.sqrt(mc.player.squaredDistanceTo(player));
                String playerInfo = player.getName().getString() +
                    " (距离: " + String.format("%.1f", distance) + "格, " +
                    "生命值: " + String.format("%.1f", player.getHealth()) + "/" +
                    player.getMaxHealth() + ")";

                // 标记好友
                if (Friends.get().isFriend(player)) {
                    playerInfo += " [好友]";
                }

                playerInfoList.add(playerInfo);
            }
        }

        return playerInfoList;
    }

    /**
     * 生成详细的日志信息
     */
    private MutableText generateDetailedLog(Text reason) {
        MutableText log = Text.literal("自动登出日志:\n");
        log.append(reason);

        if (logCoordinates.get()) {
            BlockPos pos = mc.player.getBlockPos();
            log.append(Text.literal("\n坐标: " + pos.getX() + ", " + pos.getY() + ", " + pos.getZ()).withColor(Colors.WHITE));
        }

        if (totemCheck.get()) {
            int totems = mc.player.getInventory().count(Items.TOTEM_OF_UNDYING);
            log.append(Text.literal("\n图腾数量: " + totems).withColor(Colors.WHITE));
        }

        if (logNearbyPlayers.get()) {
            List<String> nearbyPlayers = getNearbyPlayersInfo();
            if (!nearbyPlayers.isEmpty()) {
                log.append(Text.literal("\n视野内玩家:").withColor(Colors.WHITE));
                for (String playerInfo : nearbyPlayers) {
                    log.append(Text.literal("\n  " + playerInfo).withColor(Colors.GRAY));
                }
            }
        }

        return log;
    }

    private class StaticListener {
        @EventHandler
        private void healthListener(TickEvent.Post event) {
            if (isActive()) disableHealthListener();

            else if (Utils.canUpdate()
                && !mc.player.isDead()
                && mc.player.getHealth() > health.get()) {
                info("玩家生命值高于最低值，重新启用模块。");
                toggle();
                disableHealthListener();
            }
        }
    }

    private final StaticListener staticListener = new StaticListener();

    private void enableHealthListener() {
        MeteorClient.EVENT_BUS.subscribe(staticListener);
    }

    private void disableHealthListener() {
        MeteorClient.EVENT_BUS.unsubscribe(staticListener);
    }
}
