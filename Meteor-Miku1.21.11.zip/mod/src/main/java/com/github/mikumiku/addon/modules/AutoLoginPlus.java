/*
 * 本文件属于 meteor-miku 项目：https://github.com/mikumiku7/meteor-miku
 * meteor-miku 是 meteor-rejects 在 Minecraft 26.1 / Fabric 上的移植版本。
 *
 * Copyright (C) 2024-2026 XC_XinCheng
 *
 * SPDX-License-Identifier: GPL-3.0-only
 *
 * 本程序是自由软件：你可以依据 GNU 通用公共许可证（GNU GPL）第 3 版的条款
 * 重新发布和/或修改它。
 *
 * 本程序基于“有用”的期望分发，但不提供任何担保，甚至不提供适销性或特定
 * 用途适用性的默示担保。详见 GNU 通用公共许可证。
 *
 * 你应当已随本程序收到一份 GNU 通用公共许可证副本；如果没有，请见
 * <https://www.gnu.org/licenses/>。
 */
package com.github.mikumiku.addon.modules;

import com.github.mikumiku.addon.BaseModule;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class AutoLoginPlus extends BaseModule {
    private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
    private final SettingGroup sgAccounts = this.settings.createGroup("账户管理");
    private final SettingGroup sgImportExport = this.settings.createGroup("导入导出");

    // 当前用户名显示（只读）
    private final Setting<String> currentUsername = this.sgGeneral
        .add(
            new StringSetting.Builder()
                .name("当前用户名")
                .description("显示当前MC客户端登录的用户名")
                .defaultValue("未检测到")
                .build()
        );

    // 账户列表设置
    private final Setting<List<String>> accountList = this.sgAccounts
        .add(
            new StringListSetting.Builder()
                .name("账户列表")
                .description("每行一个账户，格式: 用户名:密码")
                .defaultValue()
                .build()
        );

    // 导入输入框
    private final Setting<String> importInput = this.sgImportExport
        .add(
            new StringSetting.Builder()
                .name("导入账户")
                .description("粘贴账户列表，格式: 用户名:密码，每行一个")
                .defaultValue("")
                .build()
        );

    // 导出显示框
    private final Setting<String> exportOutput = this.sgImportExport
        .add(
            new StringSetting.Builder()
                .name("导出账户")
                .description("当前账户列表，格式: 用户名:密码，每行一个")
                .defaultValue("")
                .build()
        );

    // 导入按钮
    private final Setting<Boolean> importButton = this.sgImportExport
        .add(
            new BoolSetting.Builder()
                .name("执行导入")
                .description("点击导入上方输入框中的账户")
                .defaultValue(false)
                .visible(() -> false)
                .onChanged(this::onImportButtonClick)
                .build()
        );

    // 导出按钮
    private final Setting<Boolean> exportButton = this.sgImportExport
        .add(
            new BoolSetting.Builder()
                .name("执行导出")
                .description("点击将账户列表导出到上方输出框")
                .defaultValue(false)
                .visible(() -> false)
                .onChanged(this::onExportButtonClick)
                .build()
        );

    // 调试模式
    private final Setting<Boolean> debugMode = this.sgGeneral
        .add(
            new BoolSetting.Builder()
                .name("调试模式")
                .description("显示详细的调试信息")
                .defaultValue(false)
                .build()
        );

    // 存储解析后的账户信息
    private final Map<String, String> accounts = new HashMap<>();
    private String lastDetectedUsername = "";

    public AutoLoginPlus() {
        super(
            "自动登录Plus",
            "检测当前MC用户名并自动匹配对应密码登录服务器"
        );
    }

    @Override
    public void onActivate() {
        super.onActivate();
        updateCurrentUsername();
        parseAccountList();

        if (debugMode.get()) {
            info("自动登录模块已激活");
            info("当前用户名: " + getCurrentUsername());
            info("已配置账户数量: " + accounts.size());
        }
    }

    /**
     * 导入按钮点击回调
     */
    private void onImportButtonClick(Boolean value) {
        if (value) {
            performImport();
            importButton.set(false);
        }
    }

    /**
     * 导出按钮点击回调
     */
    private void onExportButtonClick(Boolean value) {
        if (value) {
            performExport();
            exportButton.set(false);
        }
    }

    /**
     * 执行导入操作
     */
    private void performImport() {
        String input = importInput.get();
        if (input == null || input.trim().isEmpty()) {
            warning("导入内容为空");
            return;
        }

        try {
            String[] lines = input.split("\n");
            int importedCount = 0;

            for (String line : lines) {
                String trimmed = line.trim();
                if (trimmed.isEmpty()) continue;

                String[] parts = trimmed.split(":");
                if (parts.length == 2) {
                    String username = parts[0].trim();
                    String password = parts[1].trim();
                    if (!username.isEmpty() && !password.isEmpty()) {
                        accounts.put(username, password);
                        importedCount++;
                    }
                }
            }

            // 同步到 accountList 设置
            syncAccountsToList();

            if (debugMode.get()) {
                info("成功导入 " + importedCount + " 个账户");
            }
        } catch (Exception e) {
            error("导入失败: " + e.getMessage());
        }
    }

    /**
     * 执行导出操作
     */
    private void performExport() {
        if (accounts.isEmpty()) {
            warning("账户列表为空，无法导出");
            return;
        }

        String exportText = accounts.entrySet().stream()
            .map(entry -> entry.getKey() + ":" + entry.getValue())
            .collect(Collectors.joining("\n"));

        exportOutput.set(exportText);

        if (debugMode.get()) {
            info("已导出 " + accounts.size() + " 个账户到输出框");
        }
    }

    /**
     * 同步内存中的账户到设置列表
     */
    private void syncAccountsToList() {
        List<String> list = accounts.entrySet().stream()
            .map(entry -> entry.getKey() + ":" + entry.getValue())
            .collect(Collectors.toList());
        accountList.set(list);
    }

    /**
     * 获取当前MC客户端的用户名
     */
    private String getCurrentUsername() {
        try {
            if (mc != null && mc.player != null) {
                return mc.player.getName().getString();
            }
        } catch (Exception e) {
            if (debugMode.get()) {
                error("获取用户名失败: " + e.getMessage());
            }
        }
        return "未知用户";
    }

    /**
     * 更新当前用户名显示
     */
    private void updateCurrentUsername() {
        String username = getCurrentUsername();
        if (!username.equals(lastDetectedUsername)) {
            lastDetectedUsername = username;
            currentUsername.set(username);
            // 注意：这里不能直接设置Setting的值，因为它是只读的
            // 我们只在调试信息中显示
            if (debugMode.get()) {
                info("检测到用户名: " + username);
            }
        }
    }

    /**
     * 解析账户列表
     */
    private void parseAccountList() {
        accounts.clear();
        List<String> accountEntries = accountList.get();

        if (accountEntries.isEmpty()) {
            if (debugMode.get()) {
                warning("账户列表为空");
            }
            return;
        }

        try {
            for (String entry : accountEntries) {
                String[] parts = entry.trim().split(":");
                if (parts.length == 2) {
                    String username = parts[0].trim();
                    String password = parts[1].trim();
                    if (!username.isEmpty() && !password.isEmpty()) {
                        accounts.put(username, password);
                        if (debugMode.get()) {
                            info("已添加账户: " + username);
                        }
                    }
                }
            }
        } catch (Exception e) {
            error("解析账户列表失败: " + e.getMessage());
        }
    }

    /**
     * 根据当前用户名获取对应密码
     */
    private String getPasswordForCurrentUser() {
        String currentUser = getCurrentUsername();
        return accounts.get(currentUser);
    }

    @EventHandler
    public void onPacketReceiver(PacketEvent.Receive event) {
        if (event.packet instanceof GameMessageS2CPacket packet
            && packet.content().getString().contains("/login")) {
            if (debugMode.get()) {
                info("检测到需要登录");
            }
            // 更新用户名和账户列表
            updateCurrentUsername();
            parseAccountList();

            String password = getPasswordForCurrentUser();
            String currentUser = getCurrentUsername();

            if (password != null && !password.isEmpty()) {
                if (mc.getNetworkHandler() != null) {
                    mc.getNetworkHandler().sendChatCommand("login " + password);
                    if (debugMode.get()) {
                        info("为用户 " + currentUser + " 自动登录");
                    }
                }
            } else {
                if (debugMode.get()) {
                    warning("未找到用户 " + currentUser + " 的密码配置");
                }
            }
        }
    }
}
