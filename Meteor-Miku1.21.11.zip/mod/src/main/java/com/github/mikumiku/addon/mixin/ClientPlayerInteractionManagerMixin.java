package com.github.mikumiku.addon.mixin;

import com.github.mikumiku.addon.mixinface.IClientPlayerInteractionManager;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import org.spongepowered.asm.mixin.Mixin;

/**
 * 1.21.11 的 ClientPlayerInteractionManager 原生就有 clickSlot，
 * 这里只把接口挂上去，不再需要 @Shadow 桥接。
 */
@Mixin(value = ClientPlayerInteractionManager.class, priority = 1002)
public abstract class ClientPlayerInteractionManagerMixin implements IClientPlayerInteractionManager {
}
