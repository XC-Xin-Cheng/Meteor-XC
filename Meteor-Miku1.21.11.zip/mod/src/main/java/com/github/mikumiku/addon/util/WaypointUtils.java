/*
 * 本文件属于 meteor-miku 项目：https://github.com/mikumiku7/meteor-miku
 * meteor-miku 是 meteor-rejects 在 Minecraft 26.1 / Fabric 上的移植版本。
 *
 * Copyright (C) 2024-2026 XC_XinCheng
 *
 * SPDX-License-Identifier: GPL-3.0-only
 *
 * 本程序是自由软件：你可以依据 GNU 通用公共许可证（GNU GPL）第 3 版的条款
 * 重新发布和/或修改它。
 *
 * 本程序基于“有用”的期望分发，但不提供任何担保，甚至不提供适销性或特定
 * 用途适用性的默示担保。详见 GNU 通用公共许可证。
 *
 * 你应当已随本程序收到一份 GNU 通用公共许可证副本；如果没有，请见
 * <https://www.gnu.org/licenses/>。
 */
package com.github.mikumiku.addon.util;

import xaero.common.minimap.waypoints.Waypoint;
import xaero.hud.minimap.BuiltInHudModules;
import xaero.hud.minimap.module.MinimapSession;
import xaero.hud.minimap.waypoint.WaypointColor;
import xaero.hud.minimap.waypoint.set.WaypointSet;
import xaero.hud.minimap.world.MinimapWorld;
import xaero.map.mods.SupportMods;

public class WaypointUtils {

    public static void addToWaypoints(int x, int y, int z, String name) {
        WaypointSet waypointSet = getWaypointSet();
        if (waypointSet == null) return;

        // dont add waypoint that already exists
        if (getWaypointByCoordinate(x, z) != null) return;

        String waypointName = "翅";

        // set color based on total storage blocks
        int color = 10; // green
        //13 紫色

        Waypoint waypoint = new Waypoint(
            x,
            y,
            z,
            name,
            waypointName,
            color,
            0,
            false);

        waypointSet.add(waypoint);

        SupportMods.xaeroMinimap.requestWaypointsRefresh();
    }

    public static void addToWaypoints(int x, int y, int z, String name, String shortName) {
        WaypointSet waypointSet = getWaypointSet();
        if (waypointSet == null) return;

        // dont add waypoint that already exists
        if (getWaypointByCoordinate(x, z) != null) return;

        // set color based on total storage blocks
        /**
         * @see WaypointColor
         */
        int color = 10; // green
        //13 紫色

        Waypoint waypoint = new Waypoint(
            x,
            y,
            z,
            name,
            shortName,
            color,
            0,
            false);

        waypointSet.add(waypoint);

        SupportMods.xaeroMinimap.requestWaypointsRefresh();
    }

    public static Waypoint getWaypointByCoordinate(int x, int z) {
        WaypointSet waypointSet = getWaypointSet();
        if (waypointSet == null) return null;
        for (Waypoint waypoint : waypointSet.getWaypoints()) {
            if (waypoint.getX() == x && waypoint.getZ() == z) {
                return waypoint;
            }
        }
        return null;
    }


    public static WaypointSet getWaypointSet() {
        MinimapSession minimapSession = BuiltInHudModules.MINIMAP.getCurrentSession();
        if (minimapSession == null) return null;
        MinimapWorld currentWorld = minimapSession.getWorldManager().getCurrentWorld();
        if (currentWorld == null) return null;
        return currentWorld.getCurrentWaypointSet();
    }


}
