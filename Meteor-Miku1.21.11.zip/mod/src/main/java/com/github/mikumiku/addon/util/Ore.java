/*
 * 本文件属于 meteor-miku 项目：https://github.com/mikumiku7/meteor-miku
 * meteor-miku 是 meteor-rejects 在 MinecraftClient 26.1 / Fabric 上的移植版本。
 *
 * Copyright (C) 2024-2026 XC_XinCheng
 *
 * SPDX-License-Identifier: GPL-3.0-only
 *
 * 本程序是自由软件：你可以依据 GNU 通用公共许可证（GNU GPL）第 3 版的条款
 * 重新发布和/或修改它。
 *
 * 本程序基于“有用”的期望分发，但不提供任何担保，甚至不提供适销性或特定
 * 用途适用性的默示担保。详见 GNU 通用公共许可证。
 *
 * 你应当已随本程序收到一份 GNU 通用公共许可证副本；如果没有，请见
 * <https://www.gnu.org/licenses/>。
 */
package com.github.mikumiku.addon.util;

import com.github.mikumiku.addon.mixin.CountPlacementModifierAccessor;
import com.github.mikumiku.addon.mixin.HeightRangePlacementModifierAccessor;
import com.github.mikumiku.addon.mixin.RarityFilterPlacementModifierAccessor;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.world.Dimension;
import net.minecraft.client.MinecraftClient;
import net.minecraft.registry.BuiltinRegistries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryEntryLookup;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.entry.RegistryEntryList;
import net.minecraft.util.math.intprovider.ConstantIntProvider;
import net.minecraft.util.math.intprovider.IntProvider;
import net.minecraft.world.HeightLimitView;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.dimension.DimensionOptions;
import net.minecraft.world.gen.HeightContext;
import net.minecraft.world.gen.WorldPresets;
import net.minecraft.world.gen.chunk.ChunkGenerator;
import net.minecraft.world.gen.feature.OrePlacedFeatures;
import net.minecraft.world.gen.feature.ScatteredOreFeature;
import net.minecraft.world.gen.feature.FeatureConfig;
import net.minecraft.world.gen.feature.OreFeatureConfig;
import net.minecraft.world.gen.feature.PlacedFeature;
import net.minecraft.world.gen.feature.util.PlacedFeatureIndexer;
import net.minecraft.world.gen.heightprovider.HeightProvider;
import net.minecraft.world.gen.placementmodifier.CountPlacementModifier;
import net.minecraft.world.gen.placementmodifier.HeightRangePlacementModifier;
import net.minecraft.world.gen.placementmodifier.PlacementModifier;
import net.minecraft.world.gen.placementmodifier.RarityFilterPlacementModifier;

import java.util.*;


public class Ore {

    /**
     * 矿石所在层。浅层 = 石头变种（Y≥0），深层 = 深板岩变种（Y<0），
     * 下界 = 下界岩变种（下界没有深板岩）。选择界面按它分段。
     */
    public enum OreLayer {
        SHALLOW("浅层矿石（Y≥0，石头）"),
        DEEP("深层矿石（Y<0，深板岩）"),
        NETHER("下界矿石");

        public final String displayName;

        OreLayer(String displayName) {
            this.displayName = displayName;
        }
    }

    /** 矿石种类。显示名、baritone 名称与颜色保持和旧版逐个开关完全一致。 */
    public enum OreType {
        COAL("煤炭", "coal_ore", new Color(47, 44, 54), OreLayer.SHALLOW, OreLayer.DEEP),
        IRON("铁", "iron_ore", new Color(236, 173, 119), OreLayer.SHALLOW, OreLayer.DEEP),
        COPPER("铜", "copper_ore", new Color(239, 151, 0), OreLayer.SHALLOW, OreLayer.DEEP),
        EMERALD("绿宝石", "emerald_ore", new Color(27, 209, 45), OreLayer.SHALLOW, OreLayer.DEEP),
        GOLD("金", "gold_ore", new Color(247, 229, 30), OreLayer.SHALLOW, OreLayer.DEEP, OreLayer.NETHER),
        REDSTONE("红石", "redstone_ore", new Color(245, 7, 23), OreLayer.SHALLOW, OreLayer.DEEP),
        LAPIS("青金石", "lapis_ore", new Color(8, 26, 189), OreLayer.SHALLOW, OreLayer.DEEP),
        DIAMOND("钻石", "diamond_ore", new Color(33, 244, 255), OreLayer.SHALLOW, OreLayer.DEEP),
        QUARTZ("石英", "nether_quartz_ore", new Color(205, 205, 205), OreLayer.NETHER),
        DEBRIS("远古残骸", "ancient_debris", new Color(209, 27, 245), OreLayer.NETHER);

        public final String displayName;
        /** Baritone 的 mineByName 名称。 */
        public final String mineName;
        public final Color color;

        private final EnumSet<OreLayer> layers;

        OreType(String displayName, String mineName, Color color, OreLayer... layers) {
            this.displayName = displayName;
            this.mineName = mineName;
            this.color = color;
            this.layers = EnumSet.noneOf(OreLayer.class);
            Collections.addAll(this.layers, layers);
        }

        public boolean hasLayer(OreLayer layer) {
            return layers.contains(layer);
        }

        public EnumSet<OreLayer> layers() {
            return layers;
        }

        /** 该层里可能出现的矿石种类。 */
        public static List<OreType> inLayer(OreLayer layer) {
            List<OreType> list = new ArrayList<>();
            for (OreType type : values()) {
                if (type.hasLayer(layer)) list.add(type);
            }
            return list;
        }

        /** 按 baritone 名称、中文名或枚举名查找（忽略大小写与首尾空格）。 */
        public static OreType byId(String id) {
            if (id == null) return null;
            String key = id.trim().toLowerCase(Locale.ROOT);
            if (key.isEmpty()) return null;
            for (OreType type : values()) {
                if (type.mineName.equals(key)
                    || type.displayName.equalsIgnoreCase(key)
                    || type.name().toLowerCase(Locale.ROOT).equals(key)) {
                    return type;
                }
            }
            return null;
        }
    }

    /**
     * 一个被勾选的“矿石 + 层”组合，例如深层钻石 = (DIAMOND, DEEP)。
     * 实例全部预先建好，渲染时 {@link #of(OreType, OreLayer)} 不产生新对象。
     */
    public static final class OreKey {
        /** “矿石 + 层”组合的总数，便于用数组按下标查表。 */
        public static final int COUNT = OreType.values().length * OreLayer.values().length;
        private static final OreKey[] CACHE = new OreKey[COUNT];

        static {
            for (OreType type : OreType.values()) {
                for (OreLayer layer : OreLayer.values()) {
                    CACHE[type.ordinal() * OreLayer.values().length + layer.ordinal()] = new OreKey(type, layer);
                }
            }
        }

        public final OreType type;
        public final OreLayer layer;

        private OreKey(OreType type, OreLayer layer) {
            this.type = type;
            this.layer = layer;
        }

        public static OreKey of(OreType type, OreLayer layer) {
            return CACHE[type.ordinal() * OreLayer.values().length + layer.ordinal()];
        }

        /** 在 {@link #CACHE} 里的下标，等价于 {@code type.ordinal() * 层数 + layer.ordinal()}。 */
        public int index() {
            return type.ordinal() * OreLayer.values().length + layer.ordinal();
        }

        /** 配置里保存的形式，例如 diamond_ore@deep。 */
        public String id() {
            return type.mineName + "@" + layer.name().toLowerCase(Locale.ROOT);
        }

        public static OreKey byId(String id) {
            if (id == null) return null;
            String key = id.trim().toLowerCase(Locale.ROOT);
            int at = key.indexOf('@');
            if (at < 0) return null;

            OreType type = OreType.byId(key.substring(0, at));
            if (type == null) return null;

            for (OreLayer layer : OreLayer.values()) {
                if (layer.name().toLowerCase(Locale.ROOT).equals(key.substring(at + 1))
                    && type.hasLayer(layer)) {
                    return of(type, layer);
                }
            }
            return null;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof OreKey other)) return false;
            return type == other.type && layer == other.layer;
        }

        @Override
        public int hashCode() {
            return type.ordinal() * 31 + layer.ordinal();
        }

        @Override
        public String toString() {
            return id();
        }
    }

    /**
     * 每个“矿石 + 层”的边框样式：是否让相邻同类矿石的边框连成一体，
     * 以及用哪个颜色画。默认不连接、颜色沿用该矿石的内置颜色。
     */
    public static final class OreStyle {
        public boolean connected;
        public final Color color;

        public OreStyle(Color defaultColor) {
            this.connected = false;
            this.color = new Color(defaultColor);
        }
    }

    public static Map<RegistryKey<Biome>, List<Ore>> getRegistry(Dimension dimension) {

        RegistryWrapper.WrapperLookup registry = BuiltinRegistries.createWrapperLookup();
        RegistryEntryLookup<PlacedFeature> features = registry.getOrThrow(RegistryKeys.PLACED_FEATURE);
        var reg = registry.getOrThrow(RegistryKeys.WORLD_PRESET).getOrThrow(WorldPresets.DEFAULT).value().createDimensionsRegistryHolder().dimensions();

        var dim = switch (dimension) {
            case Overworld -> reg.get(DimensionOptions.OVERWORLD);
            case Nether -> reg.get(DimensionOptions.NETHER);
            case End -> reg.get(DimensionOptions.END);
        };
        ChunkGenerator generator = dim.chunkGenerator();
        var biomes = generator.getBiomeSource().getBiomes();
        var biomes1 = biomes.stream().toList();

        List<PlacedFeatureIndexer.IndexedFeatures> indexer = PlacedFeatureIndexer.collectIndexedFeatures(
            biomes1, biomeEntry -> biomeEntry.value().getGenerationSettings().getFeatures(), true
        );


        Map<PlacedFeature, Ore> featureToOre = new HashMap<>();
        registerOre(featureToOre, indexer, features, OrePlacedFeatures.ORE_COAL_LOWER, 6, OreType.COAL, generator);
        registerOre(featureToOre, indexer, features, OrePlacedFeatures.ORE_COAL_UPPER, 6, OreType.COAL, generator);
        registerOre(featureToOre, indexer, features, OrePlacedFeatures.ORE_IRON_MIDDLE, 6, OreType.IRON, generator);
        registerOre(featureToOre, indexer, features, OrePlacedFeatures.ORE_IRON_SMALL, 6, OreType.IRON, generator);
        registerOre(featureToOre, indexer, features, OrePlacedFeatures.ORE_IRON_UPPER, 6, OreType.IRON, generator);
        registerOre(featureToOre, indexer, features, OrePlacedFeatures.ORE_GOLD, 6, OreType.GOLD, generator);
        registerOre(featureToOre, indexer, features, OrePlacedFeatures.ORE_GOLD_LOWER, 6, OreType.GOLD, generator);
        registerOre(featureToOre, indexer, features, OrePlacedFeatures.ORE_GOLD_EXTRA, 6, OreType.GOLD, generator);
        registerOre(featureToOre, indexer, features, OrePlacedFeatures.ORE_GOLD_NETHER, 7, OreType.GOLD, generator);
        registerOre(featureToOre, indexer, features, OrePlacedFeatures.ORE_GOLD_DELTAS, 7, OreType.GOLD, generator);
        registerOre(featureToOre, indexer, features, OrePlacedFeatures.ORE_REDSTONE, 6, OreType.REDSTONE, generator);
        registerOre(featureToOre, indexer, features, OrePlacedFeatures.ORE_REDSTONE_LOWER, 6, OreType.REDSTONE, generator);
        registerOre(featureToOre, indexer, features, OrePlacedFeatures.ORE_DIAMOND, 6, OreType.DIAMOND, generator);
        registerOre(featureToOre, indexer, features, OrePlacedFeatures.ORE_DIAMOND_BURIED, 6, OreType.DIAMOND, generator);
        registerOre(featureToOre, indexer, features, OrePlacedFeatures.ORE_DIAMOND_LARGE, 6, OreType.DIAMOND, generator);
        registerOre(featureToOre, indexer, features, OrePlacedFeatures.ORE_DIAMOND_MEDIUM, 6, OreType.DIAMOND, generator);
        registerOre(featureToOre, indexer, features, OrePlacedFeatures.ORE_LAPIS, 6, OreType.LAPIS, generator);
        registerOre(featureToOre, indexer, features, OrePlacedFeatures.ORE_LAPIS_BURIED, 6, OreType.LAPIS, generator);
        registerOre(featureToOre, indexer, features, OrePlacedFeatures.ORE_COPPER, 6, OreType.COPPER, generator);
        registerOre(featureToOre, indexer, features, OrePlacedFeatures.ORE_COPPER_LARGE, 6, OreType.COPPER, generator);
        registerOre(featureToOre, indexer, features, OrePlacedFeatures.ORE_EMERALD, 6, OreType.EMERALD, generator);
        registerOre(featureToOre, indexer, features, OrePlacedFeatures.ORE_QUARTZ_NETHER, 7, OreType.QUARTZ, generator);
        registerOre(featureToOre, indexer, features, OrePlacedFeatures.ORE_QUARTZ_DELTAS, 7, OreType.QUARTZ, generator);
        registerOre(featureToOre, indexer, features, OrePlacedFeatures.ORE_DEBRIS_SMALL, 7, OreType.DEBRIS, generator);
        registerOre(featureToOre, indexer, features, OrePlacedFeatures.ORE_ANCIENT_DEBRIS_LARGE, 7, OreType.DEBRIS, generator);


        Map<RegistryKey<Biome>, List<Ore>> biomeOreMap = new HashMap<>();

        biomes1.forEach(biome -> {
            biomeOreMap.put(biome.getKey().get(), new ArrayList<>());
            biome.value().getGenerationSettings().getFeatures().stream()
                .flatMap(RegistryEntryList::stream)
                .map(RegistryEntry::value)
                .filter(featureToOre::containsKey)
                .forEach(feature -> {
                    biomeOreMap.get(biome.getKey().get()).add(featureToOre.get(feature));
                });
        });
        return biomeOreMap;
    }

    private static void registerOre(
        Map<PlacedFeature, Ore> map,
        List<PlacedFeatureIndexer.IndexedFeatures> indexer,
        RegistryEntryLookup<PlacedFeature> oreRegistry,
        RegistryKey<PlacedFeature> oreKey,
        int genStep,
        OreType type,
        ChunkGenerator generator
    ) {
        var orePlacement = oreRegistry.getOrThrow(oreKey).value();

        int index = indexer.get(genStep).indexMapping().applyAsInt(orePlacement);

        Ore ore = new Ore(orePlacement, genStep, index, type, generator);

        map.put(orePlacement, ore);
    }

    public int step;
    public int index;
    public final OreType type;
    public IntProvider count = ConstantIntProvider.create(1);
    public HeightProvider heightProvider;
    public HeightContext heightContext;
    public float rarity = 1;
    public float discardOnAirChance;
    public int size;
    public Color color;
    public boolean scattered;

    private Ore(PlacedFeature feature, int step, int index, OreType type, ChunkGenerator generator) {
        this.step = step;
        this.index = index;
        this.type = type;
        this.color = type.color;
        int bottom = MinecraftClient.getInstance().world.getBottomY();
        int height = MinecraftClient.getInstance().world.getDimension().logicalHeight();
        this.heightContext = new HeightContext(generator, HeightLimitView.create(bottom, height));

        for (PlacementModifier modifier : feature.placementModifiers()) {
            if (modifier instanceof CountPlacementModifier) {
                this.count = ((CountPlacementModifierAccessor) modifier).getCount();

            } else if (modifier instanceof HeightRangePlacementModifier) {
                this.heightProvider = ((HeightRangePlacementModifierAccessor) modifier).getHeight();

            } else if (modifier instanceof RarityFilterPlacementModifier) {
                this.rarity = ((RarityFilterPlacementModifierAccessor) modifier).getChance();
            }
        }

        FeatureConfig featureConfig = feature.feature().value().config();

        if (featureConfig instanceof OreFeatureConfig oreFeatureConfig) {
            this.discardOnAirChance = oreFeatureConfig.discardOnAirChance;
            this.size = oreFeatureConfig.size;
        } else {
            throw new IllegalStateException("config for " + feature + "is not OreFeatureConfig.class");
        }

        if (feature.feature().value().feature() instanceof ScatteredOreFeature) {
            this.scattered = true;
        }
    }
}
