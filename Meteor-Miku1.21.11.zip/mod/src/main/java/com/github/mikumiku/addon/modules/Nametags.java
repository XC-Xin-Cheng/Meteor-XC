/*
 * 本文件属于 meteor-miku 项目：https://github.com/mikumiku7/meteor-miku
 * meteor-miku 是 meteor-rejects 在 Minecraft 26.1 / Fabric 上的移植版本。
 *
 * Copyright (C) 2024-2026 XC_XinCheng
 *
 * SPDX-License-Identifier: GPL-3.0-only
 *
 * 本程序是自由软件：你可以依据 GNU 通用公共许可证（GNU GPL）第 3 版的条款
 * 重新发布和/或修改它。
 *
 * 本程序基于“有用”的期望分发，但不提供任何担保，甚至不提供适销性或特定
 * 用途适用性的默示担保。详见 GNU 通用公共许可证。
 *
 * 你应当已随本程序收到一份 GNU 通用公共许可证副本；如果没有，请见
 * <https://www.gnu.org/licenses/>。
 */
//package com.github.mikumiku.addon.modules;
//
//import com.github.mikumiku.addon.BaseModule;
//import it.unimi.dsi.fastutil.objects.Object2IntMap;
//import it.unimi.dsi.fastutil.objects.Object2IntMaps;
//import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
//import meteordevelopment.meteorclient.events.render.Render2DEvent;
//import meteordevelopment.meteorclient.events.world.TickEvent;
//import meteordevelopment.meteorclient.renderer.Renderer2D;
//import meteordevelopment.meteorclient.renderer.text.TextRenderer;
//import meteordevelopment.meteorclient.settings.*;
//import meteordevelopment.meteorclient.systems.config.Config;
//import meteordevelopment.meteorclient.systems.friends.Friends;
//import meteordevelopment.meteorclient.systems.modules.Modules;
//import meteordevelopment.meteorclient.systems.modules.misc.NameProtect;
//import meteordevelopment.meteorclient.systems.modules.render.Freecam;
//import meteordevelopment.meteorclient.utils.Utils;
//import meteordevelopment.meteorclient.utils.entity.EntityUtils;
//import meteordevelopment.meteorclient.utils.misc.Names;
//import meteordevelopment.meteorclient.utils.player.PlayerUtils;
//import meteordevelopment.meteorclient.utils.render.NametagUtils;
//import meteordevelopment.meteorclient.utils.render.RenderUtils;
//import meteordevelopment.meteorclient.utils.render.color.Color;
//import meteordevelopment.meteorclient.utils.render.color.SettingColor;
//import meteordevelopment.orbit.EventHandler;
//import net.minecraft.component.type.ItemEnchantmentsComponent;
//import net.minecraft.enchantment.Enchantment;
//import net.minecraft.enchantment.EnchantmentHelper;
//import net.minecraft.enchantment.Enchantments;
//import net.minecraft.entity.*;
//import net.minecraft.entity.decoration.ItemFrameEntity;
//import net.minecraft.entity.player.PlayerEntity;
//import net.minecraft.entity.vehicle.TntMinecartEntity;
//import net.minecraft.item.ItemStack;
//import net.minecraft.registry.RegistryKey;
//import net.minecraft.registry.entry.RegistryEntry;
//import net.minecraft.registry.tag.EnchantmentTags;
//import net.minecraft.util.math.MathHelper;
//import net.minecraft.util.math.Vec3d;
//import net.minecraft.world.GameMode;
//import org.joml.Vector3d;
//
//import java.util.*;
//
//public class Nametags extends BaseModule {
//    private final SettingGroup sgGeneral = settings.getDefaultGroup();
//    private final SettingGroup sgPlayers = settings.createGroup("玩家");
//    private final SettingGroup sgItems = settings.createGroup("物品");
//    private final SettingGroup sgRender = settings.createGroup("渲染");
//
//    // 通用设置
//
//    private final Setting<Set<EntityType<?>>> entities = sgGeneral.add(new EntityTypeListSetting.Builder()
//        .name("目标实体")
//        .description("选择要显示名称标签的实体类型。")
//        .defaultValue(EntityType.PLAYER, EntityType.ITEM)
//        .build()
//    );
//
//    private final Setting<Double> scale = sgGeneral.add(new DoubleSetting.Builder()
//        .name("缩放比例")
//        .description("名称标签的整体缩放比例。")
//        .defaultValue(1.1)
//        .min(0.1)
//        .build()
//    );
//
//    private final Setting<Boolean> ignoreSelf = sgGeneral.add(new BoolSetting.Builder()
//        .name("忽略自己")
//        .description("在第三人称或自由视角时不显示自己的名称标签。")
//        .defaultValue(true)
//        .build()
//    );
//
//    private final Setting<Boolean> ignoreFriends = sgGeneral.add(new BoolSetting.Builder()
//        .name("忽略好友")
//        .description("不为好友渲染名称标签。")
//        .defaultValue(false)
//        .build()
//    );
//
//    private final Setting<Boolean> ignoreBots = sgGeneral.add(new BoolSetting.Builder()
//        .name("忽略机器人")
//        .description("仅渲染非机器人实体的名称标签。")
//        .defaultValue(true)
//        .build()
//    );
//
//    private final Setting<Boolean> culling = sgGeneral.add(new BoolSetting.Builder()
//        .name("渲染裁剪")
//        .description("仅在指定数量或距离范围内渲染名称标签。")
//        .defaultValue(false)
//        .build()
//    );
//
//    private final Setting<Double> maxCullRange = sgGeneral.add(new DoubleSetting.Builder()
//        .name("裁剪距离")
//        .description("仅渲染此距离范围内的名称标签。")
//        .defaultValue(20)
//        .min(0)
//        .sliderMax(200)
//        .visible(culling::get)
//        .build()
//    );
//
//    private final Setting<Integer> maxCullCount = sgGeneral.add(new IntSetting.Builder()
//        .name("裁剪数量")
//        .description("最多同时渲染的名称标签数量。")
//        .defaultValue(50)
//        .min(1)
//        .sliderRange(1, 100)
//        .visible(culling::get)
//        .build()
//    );
//
//    // 玩家设置
//
//    private final Setting<Boolean> displayHealth = sgPlayers.add(new BoolSetting.Builder()
//        .name("显示血量")
//        .description("在名称标签中显示玩家血量。")
//        .defaultValue(true)
//        .build()
//    );
//
//    private final Setting<Boolean> displayGameMode = sgPlayers.add(new BoolSetting.Builder()
//        .name("显示游戏模式")
//        .description("显示玩家当前的游戏模式。")
//        .defaultValue(false)
//        .build()
//    );
//
//    private final Setting<Boolean> displayDistance = sgPlayers.add(new BoolSetting.Builder()
//        .name("显示距离")
//        .description("显示你与该玩家之间的距离。")
//        .defaultValue(false)
//        .build()
//    );
//
//    private final Setting<Boolean> displayPing = sgPlayers.add(new BoolSetting.Builder()
//        .name("显示延迟")
//        .description("显示玩家的网络延迟（Ping）。")
//        .defaultValue(true)
//        .build()
//    );
//
//    private final Setting<Boolean> displayItems = sgPlayers.add(new BoolSetting.Builder()
//        .name("显示装备")
//        .description("在名称标签上方显示玩家的盔甲与手持物品。")
//        .defaultValue(true)
//        .build()
//    );
//
//    private final Setting<Double> itemSpacing = sgPlayers.add(new DoubleSetting.Builder()
//        .name("物品间距")
//        .description("装备图标之间的间距。")
//        .defaultValue(2)
//        .range(0, 10)
//        .visible(displayItems::get)
//        .build()
//    );
//
//    private final Setting<Boolean> ignoreEmpty = sgPlayers.add(new BoolSetting.Builder()
//        .name("忽略空槽位")
//        .description("在空物品栏处不保留间距。")
//        .defaultValue(true)
//        .visible(displayItems::get)
//        .build()
//    );
//
//    private final Setting<Durability> itemDurability = sgPlayers.add(new EnumSetting.Builder<Durability>()
//        .name("显示耐久")
//        .description("以总数、百分比或不显示的方式显示物品耐久。")
//        .defaultValue(Durability.None)
//        .visible(displayItems::get)
//        .build()
//    );
//
//    private final Setting<Boolean> displayEnchants = sgPlayers.add(new BoolSetting.Builder()
//        .name("显示附魔")
//        .description("在物品上显示附魔信息。")
//        .defaultValue(false)
//        .visible(displayItems::get)
//        .build()
//    );
//
//    private final Setting<Set<RegistryKey<Enchantment>>> shownEnchantments = sgPlayers.add(new EnchantmentListSetting.Builder()
//        .name("显示的附魔")
//        .description("名称标签上显示的附魔类型。")
//        .visible(() -> displayItems.get() && displayEnchants.get())
//        .defaultValue(
//            Enchantments.PROTECTION,
//            Enchantments.BLAST_PROTECTION,
//            Enchantments.FIRE_PROTECTION,
//            Enchantments.PROJECTILE_PROTECTION
//        )
//        .build()
//    );
//
//    private final Setting<Position> enchantPos = sgPlayers.add(new EnumSetting.Builder<Position>()
//        .name("附魔位置")
//        .description("附魔文字的显示位置。")
//        .defaultValue(Position.Above)
//        .visible(() -> displayItems.get() && displayEnchants.get())
//        .build()
//    );
//
//    private final Setting<Integer> enchantLength = sgPlayers.add(new IntSetting.Builder()
//        .name("附魔名称长度")
//        .description("附魔名称的最大显示长度。")
//        .defaultValue(3)
//        .range(1, 5)
//        .sliderRange(1, 5)
//        .visible(() -> displayItems.get() && displayEnchants.get())
//        .build()
//    );
//
//    private final Setting<Double> enchantTextScale = sgPlayers.add(new DoubleSetting.Builder()
//        .name("附魔文字缩放")
//        .description("附魔文字的显示大小比例。")
//        .defaultValue(1)
//        .range(0.1, 2)
//        .sliderRange(0.1, 2)
//        .visible(() -> displayItems.get() && displayEnchants.get())
//        .build()
//    );
//
//    // 物品设置
//
//    private final Setting<Boolean> itemCount = sgItems.add(new BoolSetting.Builder()
//        .name("显示数量")
//        .description("显示物品堆叠数量。")
//        .defaultValue(true)
//        .build()
//    );
//
//    // 渲染设置
//
//    private final Setting<SettingColor> background = sgRender.add(new ColorSetting.Builder()
//        .name("背景颜色")
//        .description("名称标签背景的颜色。")
//        .defaultValue(new SettingColor(0, 0, 0, 75))
//        .build()
//    );
//
//    private final Setting<SettingColor> nameColor = sgRender.add(new ColorSetting.Builder()
//        .name("名称颜色")
//        .description("名称标签中名字的颜色。")
//        .defaultValue(new SettingColor())
//        .build()
//    );
//
//    private final Setting<SettingColor> pingColor = sgRender.add(new ColorSetting.Builder()
//        .name("延迟颜色")
//        .description("名称标签中延迟值的颜色。")
//        .defaultValue(new SettingColor(20, 170, 170))
//        .visible(displayPing::get)
//        .build()
//    );
//
//    private final Setting<SettingColor> gamemodeColor = sgRender.add(new ColorSetting.Builder()
//        .name("模式颜色")
//        .description("名称标签中游戏模式文字的颜色。")
//        .defaultValue(new SettingColor(232, 185, 35))
//        .visible(displayGameMode::get)
//        .build()
//    );
//
//    private final Setting<DistanceColorMode> distanceColorMode = sgRender.add(new EnumSetting.Builder<DistanceColorMode>()
//        .name("距离颜色模式")
//        .description("名称标签中距离文字的上色方式。")
//        .defaultValue(DistanceColorMode.Gradient)
//        .visible(displayDistance::get)
//        .build()
//    );
//
//    private final Setting<SettingColor> distanceColor = sgRender.add(new ColorSetting.Builder()
//        .name("距离颜色")
//        .description("名称标签中距离文字的固定颜色。")
//        .defaultValue(new SettingColor(150, 150, 150))
//        .visible(() -> displayDistance.get() && distanceColorMode.get() == DistanceColorMode.Flat)
//        .build()
//    );
//
//    private final Color WHITE = new Color(255, 255, 255);
//    private final Color RED = new Color(255, 25, 25);
//    private final Color AMBER = new Color(255, 105, 25);
//    private final Color GREEN = new Color(25, 252, 25);
//    private final Color GOLD = new Color(232, 185, 35);
//
//    private final Vector3d pos = new Vector3d();
//    private final double[] itemWidths = new double[6];
//
//    private final List<Entity> entityList = new ArrayList<>();
//
//    public Nametags() {
//        super(BaseModule.CATEGORY_MIKU_PRO, "名称标签+", "在玩家、物品及其他实体上方显示可自定义的名称标签。");
//    }
//
//
//    private static String ticksToTime(int ticks) {
//        if (ticks > 20 * 3600) {
//            int h = ticks / 20 / 3600;
//            return h + " h";
//        } else if (ticks > 20 * 60) {
//            int m = ticks / 20 / 60;
//            return m + " m";
//        } else {
//            int s = ticks / 20;
//            int ms = (ticks % 20) / 2;
//            return s + "." + ms + " s";
//        }
//    }
//
//    @EventHandler
//    private void onTick(TickEvent.Post event) {
//        entityList.clear();
//        boolean freecamNotActive = true;
//        try {
//            freecamNotActive = !Modules.get().isActive(Freecam.class);
//        } catch (Exception e) {
//        }
//
//
//        boolean notThirdPerson = mc.options.getPerspective().isFirstPerson();
//        Vec3d cameraPos = mc.gameRenderer.getCamera().getPos();
//
//        for (Entity entity : mc.world.getEntities()) {
//            EntityType<?> type = entity.getType();
//            if (!entities.get().contains(type)) continue;
//
//            if (type == EntityType.PLAYER) {
//                if ((ignoreSelf.get() || (freecamNotActive && notThirdPerson)) && entity == mc.player) continue;
//                if (EntityUtils.getGameMode((PlayerEntity) entity) == null && ignoreBots.get()) continue;
//                if (Friends.get().isFriend((PlayerEntity) entity) && ignoreFriends.get()) continue;
//            }
//
//            if (!culling.get() || PlayerUtils.isWithinCamera(entity, maxCullRange.get())) {
//                entityList.add(entity);
//            }
//        }
//
//        entityList.sort(Comparator.comparing(e -> e.distanceToSqr(cameraPos)));
//    }
//
//    @EventHandler
//    private void onRender2D(Render2DEvent event) {
//        int count = getRenderCount();
//        boolean shadow = Config.get().customFont.get();
//
//        for (int i = count - 1; i > -1; i--) {
//            Entity entity = entityList.get(i);
//
//            Utils.set(pos, entity, event.tickDelta);
//            pos.add(0, getHeight(entity), 0);
//
//            EntityType<?> type = entity.getType();
//
//            if (NametagUtils.to2D(pos, scale.get())) {
//                if (type == EntityType.PLAYER) renderNametagPlayer(event, (PlayerEntity) entity, shadow);
//                else if (type == EntityType.ITEM) renderNametagItem(((ItemEntity) entity).getStack(), shadow);
//                else if (type == EntityType.ITEM_FRAME || type == EntityType.GLOW_ITEM_FRAME)
//                    renderNametagItem(((ItemFrameEntity) entity).getHeldItemStack(), shadow);
//                else if (type == EntityType.TNT) renderTntNametag(ticksToTime(((TntEntity) entity).getFuse()), shadow);
//                else if (type == EntityType.TNT_MINECART && ((TntMinecartEntity) entity).isPrimed())
//                    renderTntNametag(ticksToTime(((TntMinecartEntity) entity).getFuseTicks()), shadow);
//                else if (entity instanceof LivingEntity) renderGenericLivingNametag((LivingEntity) entity, shadow);
//                else renderGenericNametag(entity, shadow);
//            }
//        }
//    }
//
//    private int getRenderCount() {
//        int count = culling.get() ? maxCullCount.get() : entityList.size();
//        count = MathHelper.clamp(count, 0, entityList.size());
//
//        return count;
//    }
//
//    @Override
//    public String getInfoString() {
//        return Integer.toString(getRenderCount());
//    }
//
//    private double getHeight(Entity entity) {
//        double height = entity.getEyeHeight(entity.getPose());
//
//        if (entity.getType() == EntityType.ITEM || entity.getType() == EntityType.ITEM_FRAME || entity.getType() == EntityType.GLOW_ITEM_FRAME)
//            height += 0.2;
//        else height += 0.5;
//
//        return height;
//    }
//
//    private void renderNametagPlayer(Render2DEvent event, PlayerEntity player, boolean shadow) {
//        TextRenderer text = TextRenderer.get();
//        NametagUtils.begin(pos, event.drawContext);
//
//        // Gamemode
//        GameMode gm = EntityUtils.getGameMode(player);
//        String gmText = "BOT";
//        if (gm != null) {
//            gmText = switch (gm) {
//                case SPECTATOR -> "Sp";
//                case SURVIVAL -> "S";
//                case CREATIVE -> "C";
//                case ADVENTURE -> "A";
//            };
//        }
//
//        gmText = "[" + gmText + "] ";
//
//        // Name
//        String name;
//        Color nameColor = PlayerUtils.getPlayerColor(player, this.nameColor.get());
//
//        if (player == mc.player) name = Modules.get().get(NameProtect.class).getName(player.getName().getString());
//        else name = player.getName().getString();
//
//        // Health
//        float absorption = player.getAbsorptionAmount();
//        int health = Math.round(player.getHealth() + absorption);
//        double healthPercentage = health / (player.getMaxHealth() + absorption);
//
//        String healthText = " " + health;
//        Color healthColor;
//
//        if (healthPercentage <= 0.333) healthColor = RED;
//        else if (healthPercentage <= 0.666) healthColor = AMBER;
//        else healthColor = GREEN;
//
//        // Ping
//        int ping = EntityUtils.getPing(player);
//        String pingText = " [" + ping + "ms]";
//
//        // Distance
//        double dist = Math.round(PlayerUtils.distanceToCamera(player) * 10.0) / 10.0;
//        String distText = " " + dist + "m";
//
//        // Calc widths
//        double gmWidth = text.getWidth(gmText, shadow);
//        double nameWidth = text.getWidth(name, shadow);
//        double healthWidth = text.getWidth(healthText, shadow);
//        double pingWidth = text.getWidth(pingText, shadow);
//        double distWidth = text.getWidth(distText, shadow);
//
//        double width = nameWidth;
//
//        boolean renderPlayerDistance = player != mc.cameraEntity || Modules.get().isActive(Freecam.class);
//
//        if (displayHealth.get()) width += healthWidth;
//        if (displayGameMode.get()) width += gmWidth;
//        if (displayPing.get()) width += pingWidth;
//        if (displayDistance.get() && renderPlayerDistance) width += distWidth;
//
//        double widthHalf = width / 2;
//        double heightDown = text.getHeight(shadow);
//
//        drawBg(-widthHalf, -heightDown, width, heightDown);
//
//        // Render texts
//        text.beginBig();
//        double hX = -widthHalf;
//        double hY = -heightDown;
//
//        if (displayGameMode.get()) hX = text.render(gmText, hX, hY, gamemodeColor.get(), shadow);
//        hX = text.render(name, hX, hY, nameColor, shadow);
//
//        if (displayHealth.get()) hX = text.render(healthText, hX, hY, healthColor, shadow);
//        if (displayPing.get()) hX = text.render(pingText, hX, hY, pingColor.get(), shadow);
//        if (displayDistance.get() && renderPlayerDistance) {
//            switch (distanceColorMode.get()) {
//                case Flat -> text.render(distText, hX, hY, distanceColor.get(), shadow);
//                case Gradient -> text.render(distText, hX, hY, EntityUtils.getColorFromDistance(player), shadow);
//            }
//        }
//
//        text.end();
//
//        if (displayItems.get()) {
//            // Item calc
//            Arrays.fill(itemWidths, 0);
//            boolean hasItems = false;
//            int maxEnchantCount = 0;
//
//            for (int i = 0; i < 6; i++) {
//                ItemStack itemStack = getItem(player, i);
//
//                // Setting up widths
//                if (itemWidths[i] == 0 && (!ignoreEmpty.get() || !itemStack.isEmpty()))
//                    itemWidths[i] = 32 + itemSpacing.get();
//
//                if (!itemStack.isEmpty()) hasItems = true;
//
//                if (displayEnchants.get()) {
//                    ItemEnchantmentsComponent enchantments = EnchantmentHelper.getEnchantments(itemStack);
//
//                    int size = 0;
//                    for (RegistryEntry<Enchantment> enchantment : enchantments.getEnchantments()) {
//                        if (enchantment.getKey().isPresent() && !shownEnchantments.get().contains(enchantment.getKey().get()))
//                            continue;
//                        String enchantName = Utils.getEnchantSimpleName(enchantment, enchantLength.get()) + " " + enchantments.getLevel(enchantment);
//                        itemWidths[i] = Math.max(itemWidths[i], (text.getWidth(enchantName, shadow) / 2));
//                        size++;
//                    }
//
//                    maxEnchantCount = Math.max(maxEnchantCount, size);
//                }
//            }
//
//            double itemsHeight = (hasItems ? 32 : 0);
//            double itemWidthTotal = 0;
//            for (double w : itemWidths) itemWidthTotal += w;
//            double itemWidthHalf = itemWidthTotal / 2;
//
//            double y = -heightDown - 7 - itemsHeight;
//            double x = -itemWidthHalf;
//
//            // Rendering items and enchants
//            for (int i = 0; i < 6; i++) {
//                ItemStack stack = getItem(player, i);
//                RenderUtils.drawItem(event.drawContext, stack, (int) x, (int) y, 2, true);
//
//                if (stack.isDamageable() && itemDurability.get() != Durability.None) {
//                    text.begin(0.75, false, true);
//
//                    String damageText = switch (itemDurability.get()) {
//                        case Percentage ->
//                            String.format("%.0f%%", ((stack.getMaxDamage() - stack.getDamage()) * 100f) / (float) stack.getMaxDamage());
//                        case Total -> Integer.toString(stack.getMaxDamage() - stack.getDamage());
//                        default -> "err";
//                    };
//                    Color damageColor = new Color(stack.getItemBarColor());
//
//                    text.render(damageText, (int) x, (int) y, damageColor.a(255), true);
//                    text.end();
//                }
//
//                if (maxEnchantCount > 0 && displayEnchants.get()) {
//                    text.begin(0.5 * enchantTextScale.get(), false, true);
//
//                    ItemEnchantmentsComponent enchantments = EnchantmentHelper.getEnchantments(stack);
//                    Object2IntMap<RegistryEntry<Enchantment>> enchantmentsToShow = new Object2IntOpenHashMap<>();
//
//                    for (RegistryEntry<Enchantment> enchantment : enchantments.getEnchantments()) {
//                        if (enchantment.matches(shownEnchantments.get()::contains)) {
//                            enchantmentsToShow.put(enchantment, enchantments.getLevel(enchantment));
//                        }
//                    }
//
//                    double aW = itemWidths[i];
//                    double enchantY = 0;
//
//                    double addY = switch (enchantPos.get()) {
//                        case Above -> -((enchantmentsToShow.size() + 1) * text.getHeight(shadow));
//                        case OnTop -> (itemsHeight - enchantmentsToShow.size() * text.getHeight(shadow)) / 2;
//                    };
//
//                    double enchantX;
//
//                    for (Object2IntMap.Entry<RegistryEntry<Enchantment>> entry : Object2IntMaps.fastIterable(enchantmentsToShow)) {
//                        String enchantName = Utils.getEnchantSimpleName(entry.getKey(), enchantLength.get()) + " " + entry.getIntValue();
//
//                        Color enchantColor = WHITE;
//                        if (entry.getKey().isIn(EnchantmentTags.CURSE)) enchantColor = RED;
//
//                        enchantX = switch (enchantPos.get()) {
//                            case Above -> x + (aW / 2) - (text.getWidth(enchantName, shadow) / 2);
//                            case OnTop -> x + (aW - text.getWidth(enchantName, shadow)) / 2;
//                        };
//
//                        text.render(enchantName, enchantX, y + addY + enchantY, enchantColor, shadow);
//
//                        enchantY += text.getHeight(shadow);
//                    }
//
//                    text.end();
//                }
//
//                x += itemWidths[i];
//            }
//        } else if (displayEnchants.get()) displayEnchants.set(false);
//
//        NametagUtils.end(event.drawContext);
//    }
//
//    private void renderNametagItem(ItemStack stack, boolean shadow) {
//        if (stack.isEmpty()) return;
//
//        TextRenderer text = TextRenderer.get();
//        NametagUtils.begin(pos);
//
//        String name = Names.get(stack);
//        String count = " x" + stack.getCount();
//
//        double nameWidth = text.getWidth(name, shadow);
//        double countWidth = text.getWidth(count, shadow);
//        double heightDown = text.getHeight(shadow);
//
//        double width = nameWidth;
//        if (itemCount.get()) width += countWidth;
//        double widthHalf = width / 2;
//
//        drawBg(-widthHalf, -heightDown, width, heightDown);
//
//        text.beginBig();
//        double hX = -widthHalf;
//        double hY = -heightDown;
//
//        hX = text.render(name, hX, hY, nameColor.get(), shadow);
//        if (itemCount.get()) text.render(count, hX, hY, GOLD, shadow);
//        text.end();
//
//        NametagUtils.end();
//    }
//
//    private void renderGenericLivingNametag(LivingEntity entity, boolean shadow) {
//        TextRenderer text = TextRenderer.get();
//        NametagUtils.begin(pos);
//
//        //Name
//        String nameText = entity.getType().getName().getString();
//        nameText += " ";
//
//        //Health
//        float absorption = entity.getAbsorptionAmount();
//        int health = Math.round(entity.getHealth() + absorption);
//        double healthPercentage = health / (entity.getMaxHealth() + absorption);
//
//        String healthText = String.valueOf(health);
//        Color healthColor;
//
//        if (healthPercentage <= 0.333) healthColor = RED;
//        else if (healthPercentage <= 0.666) healthColor = AMBER;
//        else healthColor = GREEN;
//
//        double nameWidth = text.getWidth(nameText, shadow);
//        double healthWidth = text.getWidth(healthText, shadow);
//        double heightDown = text.getHeight(shadow);
//
//        double width = nameWidth + healthWidth;
//        double widthHalf = width / 2;
//
//        drawBg(-widthHalf, -heightDown, width, heightDown);
//
//        text.beginBig();
//        double hX = -widthHalf;
//        double hY = -heightDown;
//
//        hX = text.render(nameText, hX, hY, nameColor.get(), shadow);
//        text.render(healthText, hX, hY, healthColor, shadow);
//        text.end();
//
//        NametagUtils.end();
//    }
//
//    private void renderGenericNametag(Entity entity, boolean shadow) {
//        TextRenderer text = TextRenderer.get();
//        NametagUtils.begin(pos);
//
//        //Name
//        String nameText = entity.getType().getName().getString();
//
//        double nameWidth = text.getWidth(nameText, shadow);
//        double heightDown = text.getHeight(shadow);
//        double widthHalf = nameWidth / 2;
//
//        drawBg(-widthHalf, -heightDown, nameWidth, heightDown);
//
//        text.beginBig();
//        double hX = -widthHalf;
//        double hY = -heightDown;
//
//        text.render(nameText, hX, hY, nameColor.get(), shadow);
//        text.end();
//
//        NametagUtils.end();
//    }
//
//    private void renderTntNametag(String fuseText, boolean shadow) {
//        TextRenderer text = TextRenderer.get();
//        NametagUtils.begin(pos);
//
//        double width = text.getWidth(fuseText, shadow);
//        double heightDown = text.getHeight(shadow);
//
//        double widthHalf = width / 2;
//
//        drawBg(-widthHalf, -heightDown, width, heightDown);
//
//        text.beginBig();
//        double hX = -widthHalf;
//        double hY = -heightDown;
//
//        text.render(fuseText, hX, hY, nameColor.get(), shadow);
//        text.end();
//
//        NametagUtils.end();
//    }
//
//    private ItemStack getItem(PlayerEntity entity, int index) {
//        return switch (index) {
//            case 0 -> entity.getMainHandStack();
//            case 1 -> entity.getInventory().armor.get(3);
//            case 2 -> entity.getInventory().armor.get(2);
//            case 3 -> entity.getInventory().armor.get(1);
//            case 4 -> entity.getInventory().armor.get(0);
//            case 5 -> entity.getOffHandStack();
//            default -> ItemStack.EMPTY;
//        };
//    }
//
//    private void drawBg(double x, double y, double width, double height) {
//        Renderer2D.COLOR.begin();
//        Renderer2D.COLOR.quad(x - 1, y - 1, width + 2, height + 2, background.get());
//        Renderer2D.COLOR.render(null);
//    }
//
//    public enum Position {
//        Above,
//        OnTop
//    }
//
//    public enum Durability {
//        None,
//        Total,
//        Percentage
//    }
//
//    public enum DistanceColorMode {
//        Gradient,
//        Flat
//    }
//
//    public boolean excludeBots() {
//        return ignoreBots.get();
//    }
//
//    public boolean playerNametags() {
//        return isActive() && entities.get().contains(EntityType.PLAYER);
//    }
//}
