/*
 * 本文件属于 meteor-miku 项目：https://github.com/mikumiku7/meteor-miku
 * meteor-miku 是 meteor-rejects 在 Minecraft 26.1 / Fabric 上的移植版本。
 *
 * Copyright (C) 2024-2026 XC_XinCheng
 *
 * SPDX-License-Identifier: GPL-3.0-only
 *
 * 本程序是自由软件：你可以依据 GNU 通用公共许可证（GNU GPL）第 3 版的条款
 * 重新发布和/或修改它。
 *
 * 本程序基于“有用”的期望分发，但不提供任何担保，甚至不提供适销性或特定
 * 用途适用性的默示担保。详见 GNU 通用公共许可证。
 *
 * 你应当已随本程序收到一份 GNU 通用公共许可证副本；如果没有，请见
 * <https://www.gnu.org/licenses/>。
 */
package com.github.mikumiku.addon.modules;

import com.github.mikumiku.addon.BaseModule;
import com.github.mikumiku.addon.util.BagUtil;
import com.github.mikumiku.addon.util.BaritoneUtil;
import com.github.mikumiku.addon.util.MikuDamageUtils;
import com.github.mikumiku.addon.util.Via;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import meteordevelopment.orbit.EventPriority;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.InteractionHand;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.AABB;
import net.minecraft.core.Direction;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author OLEPOSSU
 */

public class AnchorAuraPlus extends BaseModule {
    public AnchorAuraPlus() {
        super(BaseModule.CATEGORY_MIKU_COMBAT, "锚爆光环+", "使用重生锚自动消灭敌人。");
    }

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgDamage = settings.createGroup("伤害");
    private final SettingGroup sgRender = settings.createGroup("渲染");

    //--------------------General--------------------//
    private final Setting<Boolean> pauseEat = sgGeneral.add(new BoolSetting.Builder()
        .name("进食暂停")
        .description("进食时暂停功能。")
        .defaultValue(true)
        .build()
    );
    private final Setting<SwitchMode> switchMode = sgGeneral.add(new EnumSetting.Builder<SwitchMode>()
        .name("切换模式")
        .description("切换物品的方法。静默模式最可靠，但并非在所有地方都有效。")
        .defaultValue(SwitchMode.Silent)
        .build()
    );
    private final Setting<LogicMode> logicMode = sgGeneral.add(new EnumSetting.Builder<LogicMode>()
        .name("逻辑模式")
        .description("欺负小朋友的逻辑。")
        .defaultValue(LogicMode.BreakPlace)
        .build()
    );
    private final Setting<Double> speed = sgGeneral.add(new DoubleSetting.Builder()
        .name("速度")
        .description("每秒应该引爆多少个重生锚。")
        .defaultValue(2)
        .min(0)
        .sliderRange(0, 20)
        .build()
    );

    private final Setting<Double> range = sgGeneral.add(
        new DoubleSetting.Builder()
            .name("范围")
            .description("自动建造的最大范围")
            .defaultValue(4)
            .range(0, 6)
            .build()
    );

    //--------------------Damage--------------------//
    private final Setting<Double> minDmg = sgDamage.add(new DoubleSetting.Builder()
        .name("最小伤害")
        .description("放置所需的最低伤害。")
        .defaultValue(8)
        .min(0)
        .sliderRange(0, 20)
        .build()
    );
    private final Setting<Double> maxDmg = sgDamage.add(new DoubleSetting.Builder()
        .name("最大自伤")
        .description("对自身的最大伤害。")
        .defaultValue(6)
        .min(0)
        .sliderRange(0, 20)
        .build()
    );
    private final Setting<Double> minRatio = sgDamage.add(new DoubleSetting.Builder()
        .name("最小伤害比例")
        .description("敌我伤害比例（敌人伤害 / 自身伤害）。")
        .defaultValue(2)
        .min(0)
        .sliderRange(0, 10)
        .build()
    );

    //--------------------Render--------------------//
    private final Setting<Boolean> placeSwing = sgRender.add(new BoolSetting.Builder()
        .name("放置摆动")
        .description("放置方块时渲染摆动动画。")
        .defaultValue(true)
        .build()
    );
    //    private final Setting<SwingHand> placeHand = sgRender.add(new EnumSetting.Builder<SwingHand>()
//        .name("放置手")
//        .description("应该摆动哪只手。")
//        .defaultValue(SwingHand.RealHand)
//        .visible(placeSwing::get)
//        .build()
//    );
    private final Setting<Boolean> interactSwing = sgRender.add(new BoolSetting.Builder()
        .name("交互摆动")
        .description("与方块交互时渲染摆动动画。")
        .defaultValue(true)
        .build()
    );
    //    private final Setting<SwingHand> interactHand = sgRender.add(new EnumSetting.Builder<SwingHand>()
//        .name("交互手")
//        .description("应该摆动哪只手。")
//        .defaultValue(SwingHand.RealHand)
//        .visible(interactSwing::get)
//        .build()
//    );
    public final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
        .name("形状模式")
        .description("应该渲染哪些部分。")
        .defaultValue(ShapeMode.Both)
        .build()
    );
    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder()
        .name("线条颜色")
        .description("渲染内容的线条颜色")
        .defaultValue(new SettingColor(255, 0, 0, 255))
        .build()
    );
    public final Setting<SettingColor> color = sgRender.add(new ColorSetting.Builder()
        .name("侧面颜色")
        .description("渲染内容的侧面颜色")
        .defaultValue(new SettingColor(255, 0, 0, 50))
        .build()
    );

    private BlockPos[] blocks = new BlockPos[]{};
    private int lastIndex = 0;
    private int length = 0;
    private long tickTime = -1;
    private double bestDmg = -1;
    private long lastTime = 0;

    private BlockPos placePos = null;
    private BlockPos posPlace = null;
    private BlockPos calcPos = null;
    private BlockPos renderPos = null;
    private List<Player> targets = new ArrayList<>();
    private final Map<BlockPos, Anchor> anchors = new HashMap<>();

    double timer = 0;

    @EventHandler(priority = EventPriority.HIGHEST)
    private void onTick(TickEvent.Post event) {
        calculate(length - 1);
        renderPos = calcPos;
        placePos = calcPos;

        blocks = getBlocks(mc.player.getEyePosition(), range.get());

        // Reset stuff
        tickTime = System.currentTimeMillis();
        length = blocks.length;
        lastIndex = 0;
        bestDmg = -1;
        calcPos = null;

        updateTargets();
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    private void onRender(Render3DEvent event) {
        double delta = (System.currentTimeMillis() - lastTime) / 1000f;
        timer += delta;
        lastTime = System.currentTimeMillis();
        if (tickTime < 0 || mc.player == null || mc.level == null) {
            return;
        }

        if (pauseCheck()) {
            update();
        }

        List<BlockPos> toRemove = new ArrayList<>();
        anchors.forEach((pos, anchor) -> {
            if (System.currentTimeMillis() - anchor.time > 500) {
                toRemove.add(pos);
            }
        });
        toRemove.forEach(anchors::remove);

        int index = Math.min((int) Math.ceil((System.currentTimeMillis() - tickTime) / 50f * length), length - 1);
        calculate(index);

        if (renderPos != null && pauseCheck()) {
            event.renderer.box(renderPos, color.get(), lineColor.get(), shapeMode.get(), 0);
        }

    }

    private boolean pauseCheck() {
        return !pauseEat.get() || !mc.player.isUsingItem();
    }

    private void calculate(int index) {
        BlockPos pos;

        double dmg;
        double self;
        for (int i = lastIndex; i < index; i++) {
            pos = blocks[i];

            dmg = getDmg(pos);
            self = MikuDamageUtils.anchorDamage(mc.player, mc.player.getBoundingBox(), Vec3.atCenterOf(pos), pos, false);

            if (!dmgCheck(dmg, self)) {
                continue;
            }

            Direction direction = BaritoneUtil.getPlaceDirection(pos, true);
            if (direction == null) {
                continue;
            }
            posPlace = pos.relative(direction);

            if (EntityUtils.intersectsWithEntity(new AABB(pos), entity -> !(entity instanceof ItemEntity))) {
                continue;
            }

//            calcData = data;
            calcPos = pos;
            bestDmg = dmg;
        }
        lastIndex = index;
    }

    private void updateTargets() {
        List<Player> players = new ArrayList<>();
        double closestDist = 1000;
        Player closest;
        double dist;
        for (int i = 3; i > 0; i--) {

            closest = null;
            for (Player player : mc.level.players()) {
                if (players.contains(player) || Friends.get().isFriend(player) || player == mc.player) {
                    continue;
                }

                dist = player.distanceTo(mc.player);

                if (dist > 15) {
                    continue;
                }

                if (closest == null || dist < closestDist) {
                    closestDist = dist;
                    closest = player;
                }
            }
            if (closest != null) {
                players.add(closest);
            }
        }
        targets = players;
    }

    private BlockPos[] getBlocks(Vec3 middle, double radius) {
        ArrayList<BlockPos> result = new ArrayList<>();
        int i = (int) Math.ceil(radius);
        BlockPos pos;

        for (int x = -i; x <= i; x++) {
            for (int y = -i; y <= i; y++) {
                for (int z = -i; z <= i; z++) {
                    pos = new BlockPos((int) (Math.floor(middle.x) + x), (int) (Math.floor(middle.y) + y), (int) (Math.floor(middle.z) + z));

                    if (!BaritoneUtil.canPlace(pos) && !(mc.level.getBlockState(pos).getBlock() == Blocks.RESPAWN_ANCHOR)) {
                        continue;
                    }

                    if (!inRangeToTargets(pos)) {
                        continue;
                    }

                    if (!inPlaceRange(pos)) {
                        continue;
                    }

                    result.add(pos);
                }
            }
        }
        return result.toArray(new BlockPos[0]);
    }

    private boolean inPlaceRange(BlockPos pos) {
        double distance = PlayerUtils.distanceTo(pos);
        return distance <= range.get();
    }

    private boolean inRangeToTargets(BlockPos pos) {
        for (Player target : targets) {
            if (Via.getEntityPos(target).add(0, 1, 0).distanceTo(Vec3.upFromBottomCenterOf(pos, 0)) < 3.5) return true;
        }
        return false;
    }

    private void update() {
        if (placePos == null || posPlace == null) return;

        Anchor anchor = getAnchor(placePos);

        if (logicMode.get() == LogicMode.PlaceBreak) {
            switch (anchor.state) {
                case Anchor -> {
                    if (chargeUpdate(placePos)) {
                        Anchor a = new Anchor(AnchorState.Loaded, anchor.charges + 1, System.currentTimeMillis());

                        anchors.remove(placePos);
                        anchors.put(placePos, a);
                    }
                }
                case Loaded -> {
                    if (explodeUpdate(placePos)) {
                        anchors.remove(placePos);
                        anchors.put(placePos, new Anchor(AnchorState.Air, 0, System.currentTimeMillis()));
                    }
                }
                case Air -> {
                    if (timer <= 1 / speed.get()) {
                        return;
                    }

                    if (placeUpdate()) {
                        anchors.remove(placePos);
                        anchors.put(placePos, new Anchor(AnchorState.Anchor, 0, System.currentTimeMillis()));
                        timer = 0;
                    }
                }
            }
        } else {
            switch (anchor.state) {
                case Air -> {
                    if (placeUpdate()) {
                        anchors.remove(placePos);
                        anchors.put(placePos, new Anchor(AnchorState.Anchor, 0, System.currentTimeMillis()));
                    }
                }
                case Anchor -> {
                    if (chargeUpdate(placePos)) {
                        Anchor a = new Anchor(AnchorState.Loaded, anchor.charges + 1, System.currentTimeMillis());

                        anchors.remove(placePos);
                        anchors.put(placePos, a);
                    }
                }
                case Loaded -> {
                    if (timer <= 1 / speed.get()) {
                        return;
                    }

                    if (explodeUpdate(placePos)) {
                        anchors.remove(placePos);
                        anchors.put(placePos, new Anchor(AnchorState.Air, 0, System.currentTimeMillis()));
                        timer = 0;
                    }
                }
            }
        }
    }

    private void place(InteractionHand hand) {
        BaritoneUtil.placeBlock(posPlace);

        if (placeSwing.get()) {
            BaritoneUtil.swingHand(hand, BaritoneUtil.SwingSide.Client);
        }
    }

    private Anchor getAnchor(BlockPos pos) {
        if (anchors.containsKey(pos)) {
            return anchors.get(pos);
        }
        BlockState state = mc.level.getBlockState(pos);
        return new Anchor(state.getBlock() == Blocks.RESPAWN_ANCHOR ? state.getValue(BlockStateProperties.RESPAWN_ANCHOR_CHARGES) < 1 ? AnchorState.Anchor : AnchorState.Loaded : AnchorState.Air, state.getBlock() == Blocks.RESPAWN_ANCHOR ? state.getValue(BlockStateProperties.RESPAWN_ANCHOR_CHARGES) : 0, System.currentTimeMillis());
    }

    private boolean placeUpdate() {
        InteractionHand hand = InteractionHand.MAIN_HAND;

        boolean switched = hand != null;

        if (!switched) {
            switch (switchMode.get()) {
                case Silent, Normal -> {
                    FindItemResult result = InvUtils.findInHotbar(Items.RESPAWN_ANCHOR);
                    switched = result.found();
                }
                case PickSilent, InvSwitch -> {
                    FindItemResult result = InvUtils.find(Items.RESPAWN_ANCHOR);
                    switched = result.found();
                }
            }
        }

        if (!switched) {
            return false;
        }


        if (hand == null) {
            switch (switchMode.get()) {
                case Silent, Normal -> {
                    FindItemResult result = InvUtils.findInHotbar(Items.RESPAWN_ANCHOR);
                    InvUtils.swap(result.slot(), true);
                }
                case PickSilent -> {
                    FindItemResult result = InvUtils.find(Items.RESPAWN_ANCHOR);
                    BagUtil.doSwap(result.slot());
                    switched = true;
                }
                case InvSwitch -> {
                    FindItemResult result = InvUtils.find(Items.RESPAWN_ANCHOR);
                    switched = true;
                    BagUtil.doSwap(result.slot());

                }
            }
        }

        if (!switched) {
            return false;
        }

        place(hand == null ? InteractionHand.MAIN_HAND : hand);


        if (hand == null) {
            switch (switchMode.get()) {
                case Silent -> BagUtil.swapBack();
                case PickSilent -> BagUtil.swapBack();
                case InvSwitch -> BagUtil.swapBack();
            }
        }
        return true;
    }

    private boolean chargeUpdate(BlockPos pos) {


        boolean switched = false;

        if (!switched) {
            switch (switchMode.get()) {
                case Silent, Normal -> {
                    FindItemResult result = InvUtils.findInHotbar(Items.GLOWSTONE);
                    switched = result.found();
                }
                case PickSilent, InvSwitch -> {
                    FindItemResult result = InvUtils.find(Items.GLOWSTONE);
                    switched = result.found();
                }
            }
        }

        if (!switched) {
            return false;
        }

        FindItemResult result = InvUtils.findInHotbar(Items.GLOWSTONE);
        BagUtil.doSwap(result.slot());

        if (!switched) {
            return false;
        }

        BaritoneUtil.clickBlock(pos, Direction.UP, true, InteractionHand.MAIN_HAND, BaritoneUtil.SwingSide.Client);


        BagUtil.swapBack();

        return true;
    }

    private boolean explodeUpdate(BlockPos pos) {
        InteractionHand hand = null;
        Direction dir = BaritoneUtil.getPlaceOnDirection(pos);

        if (dir == null) {
            return false;
        }

        boolean switched = false;

        if (!switched) {
            switch (switchMode.get()) {
                case Silent, Normal -> {
                    FindItemResult result = InvUtils.findInHotbar(stack -> stack.getItem() != Items.GLOWSTONE);
                    switched = result.found();
                }
                case PickSilent, InvSwitch -> {
                    FindItemResult result = InvUtils.find(stack -> stack.getItem() != Items.GLOWSTONE);
                    switched = result.found();
                }
            }
        }

        if (!switched) {
            return false;
        }
        FindItemResult result = InvUtils.findInHotbar(item -> item.getItem() != Items.GLOWSTONE);
        BagUtil.doSwap(result.slot());


        if (!switched) {
            return false;
        }

        interact(pos, dir, hand == null ? InteractionHand.MAIN_HAND : hand);
        BagUtil.doSwap(result.slot());


        return true;
    }

    private void interact(BlockPos pos, Direction dir, InteractionHand hand) {
//        interactBlock(hand, pos.toCenterPos(), dir, pos);
        BaritoneUtil.clickBlock(pos, dir, true, hand, BaritoneUtil.SwingSide.All);

    }

    private boolean dmgCheck(double dmg, double self) {
        if (dmg < bestDmg) return false;
        if (dmg < minDmg.get()) return false;
        if (self > maxDmg.get()) return false;
        return dmg / self >= minRatio.get();
    }

    private double getDmg(BlockPos pos) {
        double highest = -1;
        for (Player target : targets) {
            highest = Math.max(highest, MikuDamageUtils.anchorDamage(target, target.getBoundingBox(), Vec3.atCenterOf(pos), pos, true));
        }
        return highest;
    }

    public enum LogicMode {
        PlaceBreak,
        BreakPlace
    }

    public enum SwitchMode {
        Silent,
        Normal,
        PickSilent,
        InvSwitch,
        Disabled
    }

    public enum AnchorState {
        Air,
        Anchor,
        Loaded
    }

    private record Anchor(AnchorState state, int charges, long time) {
    }
}
