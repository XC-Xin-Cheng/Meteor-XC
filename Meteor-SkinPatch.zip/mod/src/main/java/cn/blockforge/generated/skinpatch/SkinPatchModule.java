package cn.blockforge.generated.skinpatch;

import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.modules.Module;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * 皮肤补丁模块：整个补丁的开关和设置都在这里。
 *
 * <p>开关就是模块本身（ClickGUI 里灰色条目，左键点击切换），皮肤站、MC版本、手臂模型、
 * 披风/鞘翅这些都在右键打开的设置面板里改，改完立刻清缓存重新取皮。</p>
 */
public class SkinPatchModule extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgSource = settings.createGroup("皮肤站");
    private final SettingGroup sgMulti = settings.createGroup("多站同时生效");
    private final SettingGroup sgLook = settings.createGroup("外观");

    /**
     * 「额外同时生效」的预设皮肤站开关。
     *
     * <p>键是站点，值是它在设置面板里的勾选框；解析时按 {@link SkinSites#MULTI_PRESETS}
     * 的固定顺序依次尝试，避免选项顺序随玩家勾选先后变化。</p>
     */
    private final Map<SkinSite, Setting<Boolean>> extraSites = new EnumMap<>(SkinSite.class);

    /** 取皮肤的目标客户端版本，顺序参照 Meteor 的下拉列表：新的在前。 */
    public final Setting<McVersion> mcVersion = sgGeneral.add(new EnumSetting.Builder<McVersion>()
            .name("MC版本")
            .description("按你实际游玩的版本取皮肤。1.19.4 以前的版本没有独立鞘翅贴图，只会套用披风图案。")
            .defaultValue(McVersion.V26_1_2)
            .onChanged(version -> SkinPatch.invalidateCaches())
            .build());

    /** 单次 HTTP 请求的超时时间。 */
    public final Setting<Integer> timeoutMillis = sgGeneral.add(new IntSetting.Builder()
            .name("请求超时")
            .description("向皮肤站请求数据的最长等待时间（毫秒）。")
            .defaultValue(5000)
            .min(500)
            .max(30000)
            .sliderRange(500, 15000)
            .build());

    /** 要不要在后台提前把在线玩家的皮肤取好。 */
    public final Setting<Boolean> prefetchSkins = sgGeneral.add(new BoolSetting.Builder()
            .name("后台预取皮肤")
            .description("玩家出现在列表里就先用后台线程把皮肤取好，渲染时直接命中缓存；关掉后改为要用时再取。")
            .defaultValue(true)
            .build());

    /** 主皮肤来源。 */
    public final Setting<SkinSite> skinSite = sgSource.add(new EnumSetting.Builder<SkinSite>()
            .name("主皮肤站")
            .description("优先从哪里取皮肤。内置 LittleSkin、Ely.by、Celestia、MUA、VlssuSkin、红石；选 Mojang 官方就等于只开开关不换皮肤。想让多家同时生效，去下面的「多站同时生效」勾选。")
            .defaultValue(SkinSite.LITTLESKIN)
            .onChanged(site -> SkinPatch.invalidateCaches())
            .build());

    /**
     * 官方 UUID 在第三方皮肤站里查不到（站内编号和 Mojang 的 UUID 不是一回事），
     * 打开这一项后会先用游戏名在站内反查出站内 UUID，再拿它取皮肤。
     */
    public final Setting<Boolean> lookupByName = sgSource.add(new BoolSetting.Builder()
            .name("站内名字反查")
            .description("皮肤站按自己的账号编号，官方 UUID 在站里查不到。开启后先用玩家名字查出站内 UUID 再取皮肤，对当前生效的所有来源都适用，多数玩家都靠这一项才能取到。")
            .defaultValue(true)
            .visible(() -> SkinSites.anySupportsNameLookup(this))
            .onChanged(value -> SkinPatch.invalidateCaches())
            .build());

    /** 自建 Blessing Skin 等皮肤站的 Yggdrasil profile 接口。 */
    public final Setting<String> profileUrl = sgSource.add(new StringSetting.Builder()
            .name("Yggdrasil 接口")
            .description("profile 接口地址，支持 {uuid}（无连字符）、{uuid_dash}（带连字符）、{name} 占位符。填标准 profile 地址时会自动用上名字反查。")
            .defaultValue(SkinSites.LITTLESKIN_URL)
            .visible(() -> skinSite.get() == SkinSite.YGGDRASIL)
            .onChanged(url -> SkinPatch.invalidateCaches())
            .build());

    /** CustomSkinLoader 风格接口。 */
    public final Setting<String> customApiUrl = sgSource.add(new StringSetting.Builder()
            .name("CustomSkinLoader 接口")
            .description("返回 {\"skin\":\"...\",\"cape\":\"...\",\"elytra\":\"...\",\"model\":\"slim\"} 的接口地址。")
            .defaultValue("")
            .visible(() -> skinSite.get() == SkinSite.CUSTOM)
            .onChanged(url -> SkinPatch.invalidateCaches())
            .build());

    /** 直链模式：皮肤。 */
    public final Setting<String> directSkin = sgSource.add(new StringSetting.Builder()
            .name("皮肤直链")
            .description("皮肤图片直链，支持占位符。")
            .defaultValue("")
            .visible(() -> skinSite.get() == SkinSite.DIRECT)
            .onChanged(url -> SkinPatch.invalidateCaches())
            .build());

    /** 直链模式：披风。 */
    public final Setting<String> directCape = sgSource.add(new StringSetting.Builder()
            .name("披风直链")
            .description("披风图片直链，留空表示不加载披风。")
            .defaultValue("")
            .visible(() -> skinSite.get() == SkinSite.DIRECT)
            .onChanged(url -> SkinPatch.invalidateCaches())
            .build());

    /** 直链模式：鞘翅。 */
    public final Setting<String> directElytra = sgSource.add(new StringSetting.Builder()
            .name("鞘翅直链")
            .description("鞘翅图片直链，留空表示不加载鞘翅。")
            .defaultValue("")
            .visible(() -> skinSite.get() == SkinSite.DIRECT)
            .onChanged(url -> SkinPatch.invalidateCaches())
            .build());

    /** 手臂模型。 */
    public final Setting<SkinModel> model = sgLook.add(new EnumSetting.Builder<SkinModel>()
            .name("手臂模型")
            .description("粗手臂还是细手臂。自动表示跟随皮肤站返回的数据。")
            .defaultValue(SkinModel.AUTO)
            .onChanged(value -> SkinPatch.invalidateCaches())
            .build());

    /** 要不要加载披风。 */
    public final Setting<Boolean> loadCape = sgLook.add(new BoolSetting.Builder()
            .name("加载披风")
            .description("关闭后只换皮肤，不换披风。")
            .defaultValue(true)
            .onChanged(value -> SkinPatch.invalidateCaches())
            .build());

    /** 要不要加载鞘翅。 */
    public final Setting<Boolean> loadElytra = sgLook.add(new BoolSetting.Builder()
            .name("加载鞘翅")
            .description("关闭后鞘翅继续用披风图案。")
            .defaultValue(true)
            .visible(() -> mcVersion.get().elytraTextureSupported())
            .onChanged(value -> SkinPatch.invalidateCaches())
            .build());

    public SkinPatchModule() {
        // ClickGUI 里灰色条目显示的是 Module.title，而 title 是构造器里用
        // Utils.nameToTitle(name) 从 name 现算出来的（title 是 final，构造完就改不了）：
        // name "skin-patch" 会被拆成 "Skin Patch" 两个单词。要让它显示成中文，
        // 只能把 name 本身写成中文——"皮肤补丁" 不含连字符，nameToTitle 原样返回。
        // 同时挂上英文别名，ClickGUI 搜索框里打 skin / patch 仍然能搜到（搜索会比对 aliases）。
        super(SkinPatchAddon.CATEGORY, "皮肤补丁",
                "万用皮肤补丁：开关即模块开关，从自定义皮肤站给所有人换皮肤。",
                "skin-patch", "skinpatch");
        // 主菜单里也要能开关，否则单人/多人选择界面看不到效果
        runInMainMenu = true;
        // 「多站同时生效」的勾选框按 SkinSites.MULTI_PRESETS 的顺序生成，
        // 这样面板里的排布固定，解析时也按同一顺序依次尝试。
        // 设置是在构造器里加的（早于 Modules.get().add 和面板构建），Meteor 能正常存档与显示。
        for (SkinSite site : SkinSites.MULTI_PRESETS) {
            Setting<Boolean> setting = sgMulti.add(new BoolSetting.Builder()
                    .name(site.toString())
                    .description("与主皮肤站同时生效：排在前面的来源查不到这个玩家时，再依次用勾选的站去取。")
                    .defaultValue(false)
                    .onChanged(value -> SkinPatch.invalidateCaches())
                    .build());
            extraSites.put(site, setting);
        }
    }

    @Override
    public void onActivate() {
        SkinPatch.invalidateCaches();
        // 中途开模块时，已有玩家不会再触发查询，这里主动预取一遍，省掉渲染线程上的网络等待。
        SkinPatch.prefetchOnlineSkins();
        if (SkinPatch.hasChatHeadsCompat()) {
            info("检测到 Chat Heads：聊天栏头像会跟着补丁一起换皮肤。");
        }
        if (mc.player != null) {
            info("皮肤补丁已开启，来源：%s", SkinSites.describeSource(this));
        }
    }

    @Override
    public void onDeactivate() {
        SkinPatch.invalidateCaches();
        if (mc.player != null) {
            info("皮肤补丁已关闭，改回原版皮肤。");
        }
    }

    @Override
    public String getInfoString() {
        List<SkinSite> sites = SkinSites.activeSites(this);
        if (sites.isEmpty()) {
            return "Mojang 官方";
        }
        if (sites.size() == 1) {
            return sites.get(0).toString();
        }
        return sites.get(0) + " 等 " + sites.size() + " 站";
    }

    /** 这一家预设皮肤站是否被勾选为「额外同时生效」。 */
    public boolean isExtraSiteEnabled(SkinSite site) {
        Setting<Boolean> setting = extraSites.get(site);
        return setting != null && setting.get();
    }

    /** 当前是否要加载鞘翅贴图：开关开着，且目标版本认识这个贴图类型。 */
    public boolean supportsElytra() {
        return loadElytra.get() && mcVersion.get().elytraTextureSupported();
    }
}
