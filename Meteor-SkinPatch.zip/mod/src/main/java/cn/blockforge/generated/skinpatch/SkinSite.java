package cn.blockforge.generated.skinpatch;

/**
 * 皮肤来源。对应模块设置里的「皮肤站」下拉。
 *
 * <p>国内皮肤站和 Ely.by 大多实现了 Yggdrasil 的 profile 接口，返回的 JSON 里带一个
 * base64 的 {@code textures} 属性，格式与 Mojang 官方一致，所以共用同一段解析逻辑。</p>
 *
 * <p>内置的几家预设皮肤站只是把各自固定的接口地址登记在 {@link SkinSites} 里，
 * 方便直接选；想接自建皮肤站仍然走 {@link #YGGDRASIL} 自己填地址。</p>
 */
public enum SkinSite {
    /** 原版：不替换，直接用 Mojang 的皮肤。 */
    MOJANG("Mojang 官方"),
    /** LittleSkin，自带 Yggdrasil 接口。 */
    LITTLESKIN("LittleSkin"),
    /** Ely.by，按昵称查询的材质接口。 */
    ELYBY("Ely.by"),
    /** Celestia Skin（MCS 星盟），Blessing Skin 系。 */
    CELESTIA("Celestia Skin"),
    /** MUA 用户中心（Minecraft 高校联盟），Blessing Skin 系。 */
    MUA("MUA 用户中心"),
    /** VlssuSkin，Blessing Skin 系。 */
    VLSSU("VlssuSkin"),
    /** 红石皮肤站，Blessing Skin 系。 */
    REDSTONE("红石皮肤站"),
    /** 自建 Blessing Skin 等：自己填 Yggdrasil profile 接口。 */
    YGGDRASIL("自定义 Yggdrasil"),
    /** CustomSkinLoader 风格接口：一次返回 skin / cape / elytra / model。 */
    CUSTOM("CustomSkinLoader 接口"),
    /** 直链：皮肤、披风、鞘翅各填一个 URL 模板。 */
    DIRECT("直链");

    private final String label;

    SkinSite(String label) {
        this.label = label;
    }

    @Override
    public String toString() {
        return label;
    }
}
