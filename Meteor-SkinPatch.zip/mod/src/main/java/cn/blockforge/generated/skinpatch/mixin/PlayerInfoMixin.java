package cn.blockforge.generated.skinpatch.mixin;

import cn.blockforge.generated.skinpatch.ChatHeadsCompat;
import com.mojang.authlib.GameProfile;
import net.minecraft.client.multiplayer.PlayerInfo;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 玩家列表里一出现新玩家，就先把皮肤丢给后台线程取好。
 *
 * <p>原版 {@code PlayerInfo.getSkin()} 会同步要一次 textures 属性，第一次碰到某个玩家时
 * 直接卡在网络上。这里在档案建立（收到玩家列表包）的那一刻就启动预取，等真正渲染到这个
 * 玩家时缓存多半已经好了，{@code SkinResolver#resolve} 只做一次 Map 查询。</p>
 *
 * <p>预取走 {@link ChatHeadsCompat#prefetch}：装了 Chat Heads 时聊天栏头像也用同一份
 * {@code PlayerInfo}，这样就一起预取到了，聊天里第一次出现某个玩家时头像也已经是自定义皮肤。</p>
 *
 * <p>预取不阻塞、拿不到就跳过，模块没开时也不做任何事，所以不会影响原有行为。</p>
 */
@Mixin(PlayerInfo.class)
public abstract class PlayerInfoMixin {

    @Inject(method = "<init>", at = @At("RETURN"), require = 0)
    private void skinpatch$prefetchSkin(GameProfile profile, boolean showHat, CallbackInfo info) {
        ChatHeadsCompat.prefetch(profile);
    }
}
