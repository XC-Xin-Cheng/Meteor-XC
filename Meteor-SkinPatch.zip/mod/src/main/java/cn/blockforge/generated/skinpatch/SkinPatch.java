package cn.blockforge.generated.skinpatch;

import com.google.common.cache.LoadingCache;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.resources.SkinManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.util.Map;

/**
 * 皮肤补丁的公共状态：日志、开关查询与贴图缓存清理。
 *
 * <p>开关就是 Meteor 里的 {@code 皮肤补丁} 模块本身，这里只负责查询和转发；
 * 真正的皮肤替换发生在 {@link SkinResolver}，由 SkinManager 的 Mixin 调用。</p>
 */
public final class SkinPatch {
    public static final String MOD_ID = "skinpatch";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    /** {@code PlayerInfo.skinLookup}：惰性字段，置空可让 getSkin() 重新查一次皮肤。 */
    private static boolean skinLookupReflectionTried;
    private static Field skinLookupField;

    private SkinPatch() {
    }

    /** 取模块实例；Meteor 还没初始化完成时返回 null。 */
    public static SkinPatchModule module() {
        return SkinPatchAddon.module();
    }

    /** 模块开着才算开启补丁。 */
    public static boolean isEnabled() {
        SkinPatchModule module = module();
        return module != null && module.isActive();
    }

    /**
     * 关掉补丁或换了皮肤站之后，原版已经下载并缓存的皮肤不会自动失效。
     * 这里把皮肤管理器和玩家皮肤渲染缓存清干净，让下一次查询重新走补丁逻辑。
     */
    public static void invalidateCaches() {
        // 连带清掉结果缓存和「游戏名 → 站内 UUID」的查询缓存，否则换了皮肤站还在用上一家的数据。
        SkinResolver.clearCaches();
        Minecraft client = Minecraft.getInstance();
        if (client == null) {
            return;
        }
        try {
            SkinManager skinManager = client.getSkinManager();
            if (skinManager != null) {
                invalidate(skinManager, "skinCache");
                clearTextureCache(skinManager, "skinTextures");
                clearTextureCache(skinManager, "capeTextures");
                clearTextureCache(skinManager, "elytraTextures");
            }
        } catch (Throwable throwable) {
            LOGGER.warn("[SkinPatch] 清理 SkinManager 缓存失败：{}", throwable.toString());
        }
        try {
            Object renderCache = client.playerSkinRenderCache();
            if (renderCache != null) {
                invalidate(renderCache, "renderInfoCache");
                invalidate(renderCache, "defaultSkinCache");
            }
        } catch (Throwable throwable) {
            LOGGER.warn("[SkinPatch] 清理 PlayerSkinRenderCache 缓存失败：{}", throwable.toString());
        }
        // Chat Heads 另存了一份「头部 + 帽子层」的合成头像贴图，换皮肤后不清就会一直显示旧头像。
        ChatHeadsCompat.invalidateBlendedHeads();
        // 原版给每个玩家只建一次皮肤查询闭包（PlayerInfo.getSkin 首次调用时生成），清掉
        // SkinManager 的缓存并不会作废它；不一起重置的话，已经在场上的玩家和聊天栏头像
        // 会一直停在旧皮肤，只有重进服务器才变。重置后再预取一遍，下一次渲染直接命中新数据。
        resetOnlinePlayerSkins();
        prefetchOnlineSkins();
    }

    /**
     * 把在线玩家已生成的皮肤查询作废，逼下一次 {@code getSkin()} 重新走补丁逻辑。
     *
     * <p>{@code PlayerInfo.skinLookup} 是私有的惰性字段：为空时 {@code getSkin()} 会重新
     * 构建，所以置空即可。拿不到这个字段（版本差异）就安静跳过，绝不影响正常渲染。</p>
     */
    private static void resetOnlinePlayerSkins() {
        Minecraft client = Minecraft.getInstance();
        if (client == null) {
            return;
        }
        // PlayerInfo 的字段不是线程安全的，只在客户端主线程上改；别的线程进来时跳过，
        // 等下一次在主线程刷新缓存时再重置（预取仍会照常发起）。
        if (!client.isSameThread()) {
            return;
        }
        ClientPacketListener connection = client.getConnection();
        if (connection == null || !resolveSkinLookupField()) {
            return;
        }
        try {
            for (Object entry : connection.getOnlinePlayers()) {
                if (entry instanceof PlayerInfo info) {
                    skinLookupField.set(info, null);
                }
            }
        } catch (Throwable throwable) {
            LOGGER.warn("[SkinPatch] 重置玩家皮肤查询失败：{}", throwable.toString());
        }
    }

    /** 惰性查找并缓存 {@code PlayerInfo.skinLookup} 字段；找不到就一直走「不重置」分支。 */
    private static boolean resolveSkinLookupField() {
        if (skinLookupReflectionTried) {
            return skinLookupField != null;
        }
        skinLookupReflectionTried = true;
        try {
            Field field = PlayerInfo.class.getDeclaredField("skinLookup");
            field.setAccessible(true);
            skinLookupField = field;
        } catch (Throwable throwable) {
            LOGGER.debug("[SkinPatch] 无法重置 PlayerInfo 皮肤查询（结构不匹配）：{}", throwable.toString());
        }
        return skinLookupField != null;
    }

    /** 装没装 Chat Heads；模块开启时用它提示一次联动是否生效。 */
    public static boolean hasChatHeadsCompat() {
        return ChatHeadsCompat.isLoaded();
    }

    /**
     * 把当前在线玩家的皮肤丢到后台先取好。
     *
     * <p>模块是中途开启的时候，原来的玩家档案早就建好了，不会重新触发一次查询；
     * 这里主动预取一遍，渲染线程下一次要用皮肤时就能直接命中缓存，不再现场等网络。</p>
     */
    public static void prefetchOnlineSkins() {
        Minecraft client = Minecraft.getInstance();
        if (client == null) {
            return;
        }
        ClientPacketListener connection = client.getConnection();
        if (connection == null) {
            return;
        }
        try {
            for (Object entry : connection.getOnlinePlayers()) {
                if (entry instanceof PlayerInfo info) {
                    // 走和「玩家档案刚建立」时同一个入口：聊天栏头像和玩家模型共用这一份结果
                    ChatHeadsCompat.prefetch(info.getProfile());
                }
            }
        } catch (Throwable throwable) {
            LOGGER.warn("[SkinPatch] 预取在线玩家皮肤失败：{}", throwable.toString());
        }
    }

    private static void invalidate(Object target, String fieldName) {
        if (target == null) {
            return;
        }
        try {
            Field field = target.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            Object value = field.get(target);
            if (value instanceof LoadingCache) {
                ((LoadingCache<?, ?>) value).invalidateAll();
            }
        } catch (Throwable throwable) {
            LOGGER.warn("[SkinPatch] 字段 {} 清理失败：{}", fieldName, throwable.toString());
        }
    }

    /** {@code SkinManager.TextureCache} 内部存的是 Map，直接整个清空。 */
    private static void clearTextureCache(Object skinManager, String fieldName) {
        try {
            Field field = skinManager.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            Object textureCache = field.get(skinManager);
            if (textureCache == null) {
                return;
            }
            Field textures = textureCache.getClass().getDeclaredField("textures");
            textures.setAccessible(true);
            Object value = textures.get(textureCache);
            if (value instanceof Map) {
                ((Map<?, ?>) value).clear();
            }
        } catch (Throwable throwable) {
            LOGGER.warn("[SkinPatch] 字段 {} 清理失败：{}", fieldName, throwable.toString());
        }
    }
}
