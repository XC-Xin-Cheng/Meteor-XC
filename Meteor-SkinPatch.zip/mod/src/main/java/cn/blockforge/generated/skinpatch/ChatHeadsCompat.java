package cn.blockforge.generated.skinpatch;

import com.mojang.authlib.GameProfile;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.AbstractTexture;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.resources.Identifier;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * 与 Chat Heads 模组的联动。
 *
 * <p>Chat Heads 会在聊天栏每条消息旁边画一个玩家头像：它同样通过
 * {@code PlayerInfo.getSkin()} 取皮肤，所以补丁换过的皮肤会自动出现在聊天头像上，
 * 不需要为了它单独改皮肤来源。这里补的是另一个坑——<b>它自己那份头像贴图的缓存</b>。</p>
 *
 * <p>Chat Heads 为了把头部和帽子层合成一张图（避免半透明帽子叠画两次），会把
 * 下载好的皮肤贴图剪出 8×8 的头部、注册成自己的动态贴图，并用一个
 * {@code Set<Identifier>} 记住「哪个皮肤贴图已经合成过」。这张合成图一旦生成就不会
 * 再变：玩家换皮肤、我们换皮肤站或开关模块之后，原版贴图已经换成新的，聊天头像却
 * 还是旧的那张，直到重启客户端。</p>
 *
 * <p>所以补丁每次刷新皮肤缓存时，顺手把 Chat Heads 的合成头像也丢掉：注销它注册的
 * 动态贴图并清空那个 Set，下一次它重新下载皮肤时会按新贴图重新合成一张。找不到
 * Chat Heads 就什么都不做。</p>
 *
 * <p><b>不新增依赖：</b>全篇用反射访问 Chat Heads 的类，模组不在就直接跳过，
 * 它换版本改了内部字段也只是「联动失效」，绝不会让本模组报错或影响原版渲染。</p>
 */
public final class ChatHeadsCompat {
    /** Chat Heads 的 mod id，用来判断模组装没装。 */
    private static final String CHAT_HEADS_MOD_ID = "chat_heads";
    /** Chat Heads 的主类，合成头像的字段和方法都挂在这里。 */
    private static final String CHAT_HEADS_CLASS = "dzwdz.chat_heads.ChatHeads";
    /** 记录「哪些皮肤贴图已经合成过头像」的 Set&lt;Identifier&gt;。 */
    private static final String BLENDED_HEADS_FIELD = "blendedHeadTextures";

    /** mod 装没装；null 表示还没查过。 */
    private static Boolean loaded;
    /** 只查一次反射结果：拿不到字段就永远走「没有联动」的轻量分支。 */
    private static boolean reflectionTried;
    private static Field blendedHeadsField;

    private ChatHeadsCompat() {
    }

    /** Chat Heads 装了没有；结果只查一次。 */
    static boolean isLoaded() {
        Boolean cached = loaded;
        if (cached == null) {
            cached = detect();
            loaded = cached;
        }
        return cached;
    }

    private static boolean detect() {
        try {
            return FabricLoader.getInstance().isModLoaded(CHAT_HEADS_MOD_ID);
        } catch (Throwable throwable) {
            // 加载器还没起来：当成没装，后面还会再问
            return false;
        }
    }

    /**
     * 玩家的档案刚建立时调一次：让补丁先把皮肤取到缓存里。
     *
     * <p>Chat Heads 画头像用的是同一份 {@code PlayerInfo}，补丁在它渲染之前就把皮肤
     * 准备好，聊天里第一次出现这个玩家时头像就是自定义皮肤，而不是官方默认头像
     * （按 UUID 拼出来的那张）。</p>
     */
    public static void prefetch(GameProfile profile) {
        SkinResolver.prefetch(profile);
    }

    /**
     * 补丁换了皮肤来源：把 Chat Heads 已经合成的旧头像丢掉，让它按新贴图重做。
     *
     * <p>会在客户端主线程上调用（按钮、开关），这里再确认一次；万一从别的线程进来就
     * 不碰 OpenGL 资源，等下一次在主线程刷新时再清。</p>
     */
    static void invalidateBlendedHeads() {
        if (!isLoaded()) {
            return;
        }
        if (!Minecraft.getInstance().isSameThread()) {
            return;
        }
        try {
            if (!resolveReflection()) {
                return;
            }
            Object raw = blendedHeadsField.get(null);
            if (!(raw instanceof Collection<?> heads)) {
                return;
            }
            // 先复制一份：下面要把注销掉的位置从集合里删掉
            List<Identifier> registered = new ArrayList<>(heads.size());
            for (Object head : heads) {
                if (head instanceof Identifier location) {
                    registered.add(location);
                }
            }
            if (registered.isEmpty()) {
                return;
            }
            TextureManager textureManager = Minecraft.getInstance().getTextureManager();
            for (Identifier location : registered) {
                try {
                    release(textureManager, location);
                } catch (Throwable throwable) {
                    SkinPatch.LOGGER.debug("[SkinPatch] 注销 Chat Heads 头像贴图 {} 失败：{}",
                            location, throwable.toString());
                }
            }
            heads.clear();
            SkinPatch.LOGGER.info("[SkinPatch] 已清掉 Chat Heads 的 {} 张合成头像，等待按新皮肤重新合成。",
                    registered.size());
        } catch (Throwable throwable) {
            SkinPatch.LOGGER.warn("[SkinPatch] 清理 Chat Heads 头像缓存失败：{}", throwable.toString());
        }
    }

    /** 注销单个动态贴图；没注册过（或已经被清掉）就当成已经干净。 */
    private static void release(TextureManager textureManager, Identifier location) {
        AbstractTexture texture = textureManager.getTexture(location);
        if (texture == null) {
            return;
        }
        // release 会把它从贴图管理器里摘掉并归还显存
        textureManager.release(location);
    }

    /**
     * 第一次真正要用时再查反射：mod 没装、或 Chat Heads 改了内部结构，
     * 都在这里安静地降级成「没有联动」。
     */
    private static boolean resolveReflection() {
        if (reflectionTried) {
            return blendedHeadsField != null;
        }
        reflectionTried = true;
        try {
            Class<?> chatHeads = Class.forName(CHAT_HEADS_CLASS);
            Field field = chatHeads.getField(BLENDED_HEADS_FIELD);
            field.setAccessible(true);
            blendedHeadsField = field;
            SkinPatch.LOGGER.info("[SkinPatch] 检测到 Chat Heads，聊天头像会跟随补丁换皮肤。");
            return true;
        } catch (Throwable throwable) {
            // 版本差异导致字段换了名字之类：只是联动不生效，绝不影响皮肤补丁本身
            SkinPatch.LOGGER.debug("[SkinPatch] Chat Heads 联动不可用（已安装但结构不匹配）：{}",
                    throwable.toString());
            return false;
        }
    }
}
