package cn.blockforge.generated.skinpatch;

/**
 * 手臂模型。只在直链模式和 CustomSkinLoader 接口模式下需要手动指定，
 * 走 Yggdrasil 时皮肤站返回的数据里已经带了这个信息。
 */
public enum SkinModel {
    /** 不干预，跟随皮肤站返回的数据。 */
    AUTO("自动"),
    /** 经典：粗手臂。 */
    CLASSIC("经典（粗手臂）"),
    /** 纤细：slim 细手臂。 */
    SLIM("纤细（细手臂）");

    private final String label;

    SkinModel(String label) {
        this.label = label;
    }

    /** 写进 textures 属性的 metadata.model 值；自动时返回 null 表示不写。 */
    public String metadata() {
        if (this == SLIM) {
            return "slim";
        }
        if (this == CLASSIC) {
            return "classic";
        }
        return null;
    }

    @Override
    public String toString() {
        return label;
    }
}
