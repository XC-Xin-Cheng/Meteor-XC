package cn.blockforge.generated.skinpatch.mixin;

import cn.blockforge.generated.skinpatch.SkinResolver;
import com.mojang.authlib.minecraft.MinecraftProfileTextures;
import com.mojang.authlib.properties.Property;
import com.mojang.authlib.yggdrasil.YggdrasilMinecraftSessionService;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 域名白名单绕过的兜底注入点。
 *
 * <p>{@link SkinManagerCacheLoaderMixin} 直接改 {@code SkinManager} 内部那次解包调用，
 * 与用哪种会话服务实现无关，是首选路径；这里再在标准实现
 * {@link YggdrasilMinecraftSessionService} 的入口上补一道，万一原版内部结构改名导致
 * 首选注入没生效，皮肤仍然能正常显示。</p>
 *
 * <p>只拦截补丁自己产出的属性（名字固定为 {@code skinpatch:textures}），其他属性原样
 * 走原版逻辑，所以不会放宽原版对服务器伪造皮肤地址的防护。两道注入即使同时生效也不冲突：
 * 首选路径先返回，轮到这里时属性已经不是补丁的了。</p>
 */
@Mixin(YggdrasilMinecraftSessionService.class)
public abstract class YggdrasilSessionServiceMixin {

    @Inject(method = "unpackTextures", at = @At("HEAD"), cancellable = true)
    private void skinpatch$unpackCustomTextures(Property property, CallbackInfoReturnable<MinecraftProfileTextures> info) {
        MinecraftProfileTextures custom = SkinResolver.unpackCustom(property);
        if (custom != null) {
            info.setReturnValue(custom);
        }
    }
}
