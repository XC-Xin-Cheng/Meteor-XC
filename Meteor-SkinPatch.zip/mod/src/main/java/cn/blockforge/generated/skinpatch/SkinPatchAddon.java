package cn.blockforge.generated.skinpatch;

import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;

/**
 * Meteor Client 插件入口。
 *
 * <p>注册一个名为 {@code Meteor皮肤补丁} 的分类（就是 ClickGUI 顶上那块紫色标题），
 * 里面放一个名为 {@code 皮肤补丁} 的模块（灰色条目）。模块的开关本身就是补丁的开关：
 * 左键点一下开、再点一下关，右键展开设置，所以既不需要聊天指令，也不需要额外的快捷键。</p>
 */
public class SkinPatchAddon extends MeteorAddon {
    /**
     * ClickGUI 里的分类名，显示在紫色标题栏上。
     *
     * <p>窗口标题取的是 {@code Category.name} 原文（ModulesScreen 里
     * {@code theme.window(category.name)}），Meteor 不会做任何本地化或大小写转换，
     * 所以这里直接写中文即可。</p>
     */
    public static final Category CATEGORY = new Category("Meteor皮肤补丁");

    /**
     * 主菜单贡献者名单里作者名的写法：灰色（{@code §7}）+ 斜体（{@code §o}），
     * 与名单里其它插件的作者名观感保持一致。
     *
     * <p>这里只能写字面格式码，原因在 {@link #onInitialize()} 的注释里。</p>
     */
    private static final String CREDIT_AUTHOR = "\u00A77\u00A7oXC_Xin_Cheng";

    private static SkinPatchModule module;

    @Override
    public void onInitialize() {
        // Meteor 的 TitleScreenCredits 生成名单时，会把作者名强制套上 ChatFormatting.WHITE：
        // 无论 fabric.mod.json 里怎么写，纯文本都会渲染成白色正体。唯一能盖过它的，是字符串
        // 自带的传统格式码 —— 客户端渲染文本时由 StringDecomposer 解析 § 并 applyLegacyFormat，
        // 优先级高于 Meteor 设的白色样式。所以这里覆盖 authors 字段，让名单里显示灰色斜体。
        //
        // 只改这个运行时字段，不动 fabric.mod.json：Fabric 的模组列表、Mod Menu、日志里
        // 仍然是干净的 "XC_Xin_Cheng"，不会把格式码当正文露出来。
        // AddonManager 先填好 authors 再调 onInitialize，此处覆盖不会被回滚。
        authors = new String[]{CREDIT_AUTHOR};

        module = new SkinPatchModule();
        Modules.get().add(module);
        SkinPatch.LOGGER.info("[Meteor-SkinPatch] 已作为 Meteor 插件加载，分类 {}，当前状态：{}",
                CATEGORY.name, module.isActive() ? "开启" : "关闭");
    }

    @Override
    public void onRegisterCategories() {
        Modules.registerCategory(CATEGORY);
    }

    @Override
    public String getPackage() {
        return "cn.blockforge.generated.skinpatch";
    }

    /** 取模块实例；Meteor 系统还没初始化完成时返回 null。 */
    public static SkinPatchModule module() {
        if (module != null) {
            return module;
        }
        try {
            module = Modules.get().get(SkinPatchModule.class);
        } catch (Throwable ignored) {
            // 系统还没就绪，等下一次查询
        }
        return module;
    }
}
