package cn.blockforge.generated.skinpatch;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.SignatureState;
import com.mojang.authlib.minecraft.MinecraftProfileTexture;
import com.mojang.authlib.minecraft.MinecraftProfileTextures;
import com.mojang.authlib.properties.Property;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 把玩家档案换成自定义皮肤站的数据。
 *
 * <p>返回的是原版皮肤系统使用的 {@code textures} 属性（base64 的 JSON），
 * 下游的下载、缓存、模型识别全部交给原版处理，所以只要数据格式对，
 * 皮肤站用哪家都能通用。</p>
 *
 * <p>所有参数都来自 {@link SkinPatchModule} 的设置面板，模块没开就原样返回 null，
 * 由 Mixin 回退到原版逻辑。</p>
 *
 * <p>Blessing Skin 系皮肤站（LittleSkin、Celestia、MUA、VlssuSkin、红石）按站内账号编号，
 * 玩家的官方 UUID 在站里查不到，所以要先拿游戏名换出站内 UUID 再取皮肤。</p>
 *
 * <p><b>性能：</b>原版 {@code SkinManager.get} 每次都会先同步要一次 textures 属性，
 * 再拿它当原版缓存的键，所以这里必须尽快返回。为此做了三层处理：</p>
 * <ul>
 *   <li>最终结果缓存：同一个玩家解析一次后直接返回，不再发请求；查无此人也做短时否定缓存，
 *       避免对着一个不在站的玩家反复超时。</li>
 *   <li>并发去重：同一个玩家同时被多处请求时只发一轮 HTTP，其余等结果。</li>
 *   <li>后台预取：玩家出现在列表里就先在工作线程把皮肤取好，渲染线程第一次用到时直接命中缓存。</li>
 * </ul>
 */
public final class SkinResolver {
    private static final String USER_AGENT = "Meteor-SkinPatch/1.0 (Minecraft Fabric)";

    /**
     * 补丁自己产出的 textures 属性用的名字。
     *
     * <p>原版 {@code SkinManager.get} 会把 {@code sessionService.getPackedTextures(profile)}
     * 的返回值（名字固定为 {@code textures}）塞进缓存键并交给
     * {@code MinecraftSessionService.unpackTextures} 解包，而解包时会用
     * {@code TextureUrlChecker.isAllowedTextureDomain} 卡域名——只放行
     * {@code textures.minecraft.net}，第三方皮肤站的图片地址一律被丢掉。</p>
     *
     * <p>为了把「补丁自己给的属性」和「服务器发来的属性」区分开，补丁改用这个名字。
     * 原版读服务器档案时只会取名为 {@code textures} 的那条，所以服务器不可能伪造出
     * 我们这个名字的属性；{@link #unpackCustom} 只认这个名字，绕过域名检查的范围
     * 就严格限制在补丁自己解析出的数据上，不会削弱原版对服务器伪造皮肤地址的防护。</p>
     */
    public static final String CUSTOM_PROPERTY_NAME = "skinpatch:textures";

    /** 站内 UUID 查询结果的缓存时长：查到留 30 分钟，没查到只留 2 分钟。 */
    private static final long HIT_TTL_MILLIS = 30L * 60L * 1000L;
    private static final long MISS_TTL_MILLIS = 2L * 60L * 1000L;
    /** 各种缓存条目的上限，超过就直接清空，避免长时间挂机越攒越多。 */
    private static final int CACHE_LIMIT = 1024;
    private static final int LOOKUP_CACHE_LIMIT = 512;
    /** 后台预取的并发上限：待解析的玩家太多时就不再排队，避免把皮肤站请求打爆。 */
    private static final int PREFETCH_LIMIT = 256;
    /** 后台预取线程数；只做网络等待，给几条就够。 */
    private static final int WORKER_COUNT = 3;
    /** 一次解析依次尝试多家来源时的总时限 = 单次请求超时 × 这个倍数。 */
    private static final int TOTAL_TIMEOUT_FACTOR = 4;

    /** 「API 根地址 + 游戏名」→ 站内 UUID 的小缓存，避免重复名字反查。 */
    private static final Map<String, CachedId> LOOKUP_CACHE = new ConcurrentHashMap<>();

    /** 玩家 UUID → 最终解析结果（含「查无此人」）。 */
    private static final Map<UUID, CachedSkin> SKIN_CACHE = new ConcurrentHashMap<>();

    /** 正在解析中的玩家，用于并发去重。 */
    private static final Map<UUID, CompletableFuture<Property>> INFLIGHT = new ConcurrentHashMap<>();

    /** 设置一变就加一，旧的结果一律作废，避免异步回来的旧数据盖掉新设置。 */
    private static final AtomicLong GENERATION = new AtomicLong();

    private static final AtomicInteger THREAD_IDS = new AtomicInteger();
    private static final ExecutorService WORKERS = Executors.newFixedThreadPool(WORKER_COUNT, runnable -> {
        Thread thread = new Thread(runnable, "skinpatch-prefetch-" + THREAD_IDS.incrementAndGet());
        thread.setDaemon(true);
        return thread;
    });

    private SkinResolver() {
    }

    private record CachedId(String id, long expiresAt) {
    }

    /** 一次解析的最终结果；{@code property} 为 null 表示「查无此人」，同样缓存一小段时间。 */
    private record CachedSkin(Property property, long expiresAt, long generation) {
    }

    /** 解析一次所需的全部设置，在调用线程上一次性读好，工作线程不再碰 Meteor 的设置对象。 */
    private record ResolveConfig(List<SkinSite> sites, String profileUrl, String customApiUrl,
                                 String directSkin, String directCape, String directElytra,
                                 SkinModel model, boolean loadCape, boolean supportsElytra,
                                 boolean lookupByName, int timeoutMillis) {
    }

    /** 换皮肤站、改设置或关开关时把结果缓存和站内 UUID 缓存一起清掉。 */
    public static void clearCaches() {
        GENERATION.incrementAndGet();
        SKIN_CACHE.clear();
        LOOKUP_CACHE.clear();
    }

    /**
     * 解析出替换用的 textures 属性；返回 null 表示保持原版。
     *
     * <p>命中缓存时几乎是纯 Map 查询；没命中则现场解析一次（和别人正在预取的同一玩家会直接等结果）。</p>
     */
    public static Property resolve(GameProfile profile) {
        if (profile == null || profile.id() == null) {
            return null;
        }
        SkinPatchModule module = activeModule();
        if (module == null) {
            return null;
        }
        UUID id = profile.id();
        CachedSkin hit = fresh(id);
        if (hit != null) {
            return hit.property();
        }
        return resolveInline(profile, configOf(module));
    }

    /**
     * 后台预取：玩家出现在列表里时调用，先把皮肤取到缓存里，渲染线程随后就能直接命中。
     *
     * <p>不阻塞调用线程；模块没开、来源是官方、已经有缓存或在解析中都会直接跳过。</p>
     */
    public static void prefetch(GameProfile profile) {
        if (profile == null || profile.id() == null) {
            return;
        }
        SkinPatchModule module = activeModule();
        if (module == null || !module.prefetchSkins.get()) {
            return;
        }
        UUID id = profile.id();
        if (fresh(id) != null || INFLIGHT.size() >= PREFETCH_LIMIT) {
            return;
        }
        resolveAsync(profile, configOf(module));
    }

    /** 模块开着且确实配置了自定义来源时返回模块，否则返回 null。 */
    private static SkinPatchModule activeModule() {
        SkinPatchModule module = SkinPatch.module();
        if (module == null || !module.isActive()) {
            return null;
        }
        if (SkinSites.activeSites(module).isEmpty()) {
            return null;
        }
        return module;
    }

    private static ResolveConfig configOf(SkinPatchModule module) {
        return new ResolveConfig(
                SkinSites.activeSites(module),
                module.profileUrl.get(),
                module.customApiUrl.get(),
                module.directSkin.get(),
                module.directCape.get(),
                module.directElytra.get(),
                module.model.get(),
                module.loadCape.get(),
                module.supportsElytra(),
                module.lookupByName.get(),
                module.timeoutMillis.get());
    }

    /** 读取仍然有效的缓存条目；过期或换代就顺手丢弃。 */
    private static CachedSkin fresh(UUID id) {
        CachedSkin entry = SKIN_CACHE.get(id);
        if (entry == null) {
            return null;
        }
        if (entry.generation() != GENERATION.get() || entry.expiresAt() <= System.currentTimeMillis()) {
            SKIN_CACHE.remove(id, entry);
            return null;
        }
        return entry;
    }

    /** 在当前线程解析并返回；如果同一个玩家已经有人在解析，就等那一份结果。 */
    private static Property resolveInline(GameProfile profile, ResolveConfig config) {
        UUID id = profile.id();
        CompletableFuture<Property> running = INFLIGHT.get(id);
        if (running != null) {
            return await(running, config);
        }
        CompletableFuture<Property> created = new CompletableFuture<>();
        CompletableFuture<Property> existing = INFLIGHT.putIfAbsent(id, created);
        if (existing != null) {
            return await(existing, config);
        }
        long generation = GENERATION.get();
        Property property = run(profile, config);
        if (generation == GENERATION.get()) {
            store(id, property, generation);
        }
        INFLIGHT.remove(id, created);
        created.complete(property);
        return property;
    }

    /** 在工作线程解析，调用方立即返回，结果进缓存供后续命中。 */
    private static void resolveAsync(GameProfile profile, ResolveConfig config) {
        UUID id = profile.id();
        CompletableFuture<Property> created = new CompletableFuture<>();
        if (INFLIGHT.putIfAbsent(id, created) != null) {
            return;
        }
        long generation = GENERATION.get();
        WORKERS.execute(() -> {
            Property property = run(profile, config);
            if (generation == GENERATION.get()) {
                store(id, property, generation);
            }
            INFLIGHT.remove(id, created);
            created.complete(property);
        });
    }

    /** 等待正在进行的解析；超时就放弃本次，改走原版。 */
    private static Property await(CompletableFuture<Property> future, ResolveConfig config) {
        try {
            return future.get(config.timeoutMillis() * 4L + 1000L, TimeUnit.MILLISECONDS);
        } catch (TimeoutException exception) {
            SkinPatch.LOGGER.warn("[SkinPatch] 等待皮肤站响应超时，本次改走原版。");
            return null;
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            return null;
        } catch (Exception exception) {
            return null;
        }
    }

    private static Property run(GameProfile profile, ResolveConfig config) {
        try {
            return resolveNow(profile, config);
        } catch (Throwable throwable) {
            SkinPatch.LOGGER.warn("[SkinPatch] 为 {} 获取自定义皮肤失败，本次改走原版：{}",
                    profile.name(), throwable.toString());
            return null;
        }
    }

    private static void store(UUID id, Property property, long generation) {
        if (SKIN_CACHE.size() >= CACHE_LIMIT) {
            SKIN_CACHE.clear();
        }
        long ttl = property == null ? MISS_TTL_MILLIS : HIT_TTL_MILLIS;
        SKIN_CACHE.put(id, new CachedSkin(property, System.currentTimeMillis() + ttl, generation));
    }

    /**
     * 把补丁自己产出的 textures 属性解包成原版的 {@link MinecraftProfileTextures}。
     *
     * <p>只认 {@link #CUSTOM_PROPERTY_NAME}：不是补丁给的属性就返回 null，调用方继续走
     * 原版 {@code unpackTextures}。原版解包会用 {@code TextureUrlChecker} 卡域名
     * （只放行 {@code textures.minecraft.net}），第三方皮肤站的图片地址过不去，
     * 所以补丁自己解包、自己构造，跳过这一步。</p>
     *
     * <p>签名状态直接给 {@link SignatureState#SIGNED}：原版 {@code SkinManager} 用它决定
     * {@code PlayerSkin.secure()}，而 {@code PlayerInfo} 对<b>其他玩家</b>查询皮肤时传的是
     * {@code requireSecure = true}（本机玩家才 false）。如果留成 UNSIGNED，自定义皮肤会在
     * 这一步被过滤掉、退回默认皮肤——也就是「自己看得见、别人看不见」。补丁换皮本来就是
     * 玩家主动选择的可信来源，这里按可信处理。</p>
     */
    public static MinecraftProfileTextures unpackCustom(Property property) {
        if (property == null || !CUSTOM_PROPERTY_NAME.equals(property.name())) {
            return null;
        }
        try {
            byte[] decoded = Base64.getDecoder().decode(property.value());
            JsonObject root = JsonParser.parseString(new String(decoded, StandardCharsets.UTF_8)).getAsJsonObject();
            JsonObject textures = root.getAsJsonObject("textures");
            if (textures == null) {
                return null;
            }
            MinecraftProfileTexture skin = textureOf(textures.getAsJsonObject("SKIN"));
            MinecraftProfileTexture cape = textureOf(textures.getAsJsonObject("CAPE"));
            MinecraftProfileTexture elytra = textureOf(textures.getAsJsonObject("ELYTRA"));
            if (skin == null && cape == null && elytra == null) {
                return null;
            }
            return new MinecraftProfileTextures(skin, cape, elytra, SignatureState.SIGNED);
        } catch (Exception exception) {
            SkinPatch.LOGGER.warn("[SkinPatch] 解包自定义 textures 属性失败，本次改走原版：{}",
                    exception.toString());
            return null;
        }
    }

    /** 把 payload 里的一段纹理条目转成原版对象；没有 url 就当没有这张贴图。 */
    private static MinecraftProfileTexture textureOf(JsonObject entry) {
        if (entry == null) {
            return null;
        }
        String url = optString(entry, "url");
        if (url.isEmpty()) {
            return null;
        }
        JsonObject meta = entry.getAsJsonObject("metadata");
        Map<String, String> metadata = null;
        if (meta != null && !meta.isEmpty()) {
            metadata = new HashMap<>();
            for (Map.Entry<String, JsonElement> field : meta.entrySet()) {
                JsonElement value = field.getValue();
                if (value != null && !value.isJsonNull()) {
                    metadata.put(field.getKey(), value.getAsString());
                }
            }
        }
        return new MinecraftProfileTexture(url, metadata);
    }

    /**
     * 按来源列表依次尝试：前面的取到皮肤就停下，全部落空才回退原版。
     *
     * <p>勾选了多家皮肤站后，如果前几家都不可达，逐个超时会拖很久。这里给整轮尝试一个
     * 总时限，到点就不再试后面的站，宁可这次回退原版，也不把渲染 / 预取线程长时间占住。</p>
     */
    private static Property resolveNow(GameProfile profile, ResolveConfig config) throws Exception {
        long deadline = System.currentTimeMillis() + config.timeoutMillis() * (long) TOTAL_TIMEOUT_FACTOR;
        for (SkinSite site : config.sites()) {
            if (System.currentTimeMillis() >= deadline) {
                SkinPatch.LOGGER.warn("[SkinPatch] 为 {} 依次尝试多家皮肤站已超出总时限，本次改走原版。",
                        profile.name());
                break;
            }
            Property property = resolveFrom(profile, site, config);
            if (property != null) {
                return property;
            }
        }
        return null;
    }

    /** 按单个来源解析；这一家没有数据返回 null，由调用方决定是否试下一家。 */
    private static Property resolveFrom(GameProfile profile, SkinSite site, ResolveConfig config) throws Exception {
        // 内置皮肤站（LittleSkin / Ely.by / Celestia / MUA / VlssuSkin / 红石）共用一套解析。
        String preset = SkinSites.presetUrl(site);
        if (preset != null) {
            return resolveYggdrasil(profile, preset, config);
        }
        if (site == SkinSite.YGGDRASIL) {
            return resolveYggdrasil(profile, config.profileUrl(), config);
        }
        if (site == SkinSite.CUSTOM) {
            return resolveCustomSkinLoader(profile, config);
        }
        if (site == SkinSite.DIRECT) {
            return resolveDirect(profile, config);
        }
        return null;
    }

    /**
     * Yggdrasil / Blessing Skin 系皮肤站。
     *
     * <p>这些站按自己的账号体系编号，玩家的官方 UUID 在站里查不到；能对上号的只有
     * 游戏名。所以先 POST 游戏名换出站内 UUID，再请求 profile 拿 textures；
     * 站内没这个号（或名字反查被关掉）时，再拿官方 UUID 直接试一次。</p>
     */
    private static Property resolveYggdrasil(GameProfile profile, String template, ResolveConfig config)
            throws Exception {
        String name = profile.name() == null ? "" : profile.name();
        String root = SkinSites.blessingSkinRoot(template);
        if (root != null && config.lookupByName() && !name.isEmpty()) {
            String siteId = lookupSiteId(root, name, config.timeoutMillis());
            if (siteId != null) {
                Property property = texturesOf(httpGet(root + SkinSites.PROFILE_PATH.replace("{uuid}", siteId),
                        config.timeoutMillis()), config);
                if (property != null) {
                    return property;
                }
            }
        }
        String url = fill(template, profile);
        if (url.isEmpty()) {
            return null;
        }
        return texturesOf(httpGet(url, config.timeoutMillis()), config);
    }

    /**
     * 用游戏名在 Blessing Skin 站内查出该玩家的站内 UUID。
     *
     * <p>走的是 {@code POST /api/profiles/minecraft}，请求体是名字数组，
     * 返回 {@code [{"id":"...","name":"..."}]}；查不到就是空数组，返回 null。</p>
     */
    private static String lookupSiteId(String root, String name, int timeoutMillis) {
        String key = root + "|" + name.toLowerCase(Locale.ROOT);
        long now = System.currentTimeMillis();
        CachedId cached = LOOKUP_CACHE.get(key);
        if (cached != null && cached.expiresAt() > now) {
            return cached.id();
        }
        String id = null;
        try {
            String body = httpPostJson(root + SkinSites.NAME_LOOKUP_PATH,
                    "[\"" + escapeJson(name) + "\"]", timeoutMillis);
            id = firstProfileId(body);
        } catch (Exception exception) {
            SkinPatch.LOGGER.warn("[SkinPatch] 站内名字反查失败，改用官方 UUID：{}", exception.toString());
        }
        if (LOOKUP_CACHE.size() >= LOOKUP_CACHE_LIMIT) {
            LOOKUP_CACHE.clear();
        }
        LOOKUP_CACHE.put(key, new CachedId(id, now + (id == null ? MISS_TTL_MILLIS : HIT_TTL_MILLIS)));
        return id;
    }

    /** 从 {@code [{"id":"...","name":"..."}]} 里取第一个玩家的站内 UUID。 */
    private static String firstProfileId(String body) {
        if (body == null || body.isEmpty()) {
            return null;
        }
        JsonElement parsed = JsonParser.parseString(body);
        if (!parsed.isJsonArray()) {
            return null;
        }
        JsonArray array = parsed.getAsJsonArray();
        if (array.isEmpty()) {
            return null;
        }
        JsonElement first = array.get(0);
        if (!first.isJsonObject()) {
            return null;
        }
        String id = optString(first.getAsJsonObject(), "id");
        return id.isEmpty() ? null : id.replace("-", "");
    }

    /** 把 profile 接口返回的 JSON 转成 textures 属性；没有可用数据返回 null。 */
    private static Property texturesOf(String body, ResolveConfig config) {
        if (body == null || body.isEmpty()) {
            return null;
        }
        try {
            JsonObject root = JsonParser.parseString(body).getAsJsonObject();
            JsonArray properties = root.getAsJsonArray("properties");
            if (properties == null) {
                return null;
            }
            for (JsonElement element : properties) {
                if (!element.isJsonObject()) {
                    continue;
                }
                JsonObject property = element.getAsJsonObject();
                if ("textures".equals(optString(property, "name"))) {
                    String value = optString(property, "value");
                    if (!value.isEmpty()) {
                        return new Property(CUSTOM_PROPERTY_NAME, filterByVersion(value, config));
                    }
                }
            }
        } catch (Exception exception) {
            SkinPatch.LOGGER.warn("[SkinPatch] 解析皮肤站返回的 profile 失败：{}", exception.toString());
        }
        return null;
    }

    /** CustomSkinLoader 风格接口：{"skin": "...", "cape": "...", "model": "slim"}。 */
    private static Property resolveCustomSkinLoader(GameProfile profile, ResolveConfig config) throws Exception {
        String url = fill(config.customApiUrl(), profile);
        if (url.isEmpty()) {
            return null;
        }
        String body = httpGet(url, config.timeoutMillis());
        if (body == null || body.isEmpty()) {
            return null;
        }
        JsonObject root = JsonParser.parseString(body).getAsJsonObject();
        String skin = optString(root, "skin");
        if (skin.isEmpty()) {
            return null;
        }
        String cape = config.loadCape() ? optString(root, "cape") : "";
        String elytra = config.supportsElytra() ? optString(root, "elytra") : "";
        String model = optString(root, "model");
        if (model.isEmpty()) {
            String metadata = config.model().metadata();
            model = metadata == null ? "" : metadata;
        }
        return buildPacked(profile, skin, cape, elytra, model);
    }

    /** 直链模式：皮肤/披风/鞘翅各自一个 URL 模板，不解析皮肤站返回的 JSON。 */
    private static Property resolveDirect(GameProfile profile, ResolveConfig config) {
        String skin = fill(config.directSkin(), profile);
        if (skin.isEmpty()) {
            return null;
        }
        String cape = config.loadCape() ? fill(config.directCape(), profile) : "";
        String elytra = config.supportsElytra() ? fill(config.directElytra(), profile) : "";
        String metadata = config.model().metadata();
        return buildPacked(profile, skin, cape, elytra, metadata == null ? "" : metadata);
    }

    /**
     * 皮肤站返回的 textures 里可能带鞘翅贴图，而较旧的客户端不认识这个类型。
     * 目标版本不支持时，把它从 base64 数据里摘掉，其余部分原样保留。
     */
    private static String filterByVersion(String value, ResolveConfig config) {
        if (config.supportsElytra()) {
            return value;
        }
        try {
            byte[] decoded = Base64.getDecoder().decode(value);
            JsonObject root = JsonParser.parseString(new String(decoded, StandardCharsets.UTF_8)).getAsJsonObject();
            JsonObject textures = root.getAsJsonObject("textures");
            if (textures == null || !textures.has("ELYTRA")) {
                return value;
            }
            textures.remove("ELYTRA");
            return Base64.getEncoder().encodeToString(root.toString().getBytes(StandardCharsets.UTF_8));
        } catch (Exception exception) {
            SkinPatch.LOGGER.warn("[SkinPatch] 处理 textures 属性失败，改用原始数据：{}", exception.toString());
            return value;
        }
    }

    private static Property buildPacked(GameProfile profile, String skin, String cape, String elytra, String model) {
        JsonObject textures = new JsonObject();
        textures.add("SKIN", textureEntry(skin, model));
        if (cape != null && !cape.isEmpty()) {
            textures.add("CAPE", textureEntry(cape, null));
        }
        if (elytra != null && !elytra.isEmpty()) {
            textures.add("ELYTRA", textureEntry(elytra, null));
        }
        JsonObject root = new JsonObject();
        root.addProperty("timestamp", System.currentTimeMillis());
        root.addProperty("profileId", profile.id().toString().replace("-", ""));
        root.addProperty("profileName", profile.name() == null ? "" : profile.name());
        root.add("textures", textures);
        String value = Base64.getEncoder().encodeToString(root.toString().getBytes(StandardCharsets.UTF_8));
        return new Property(CUSTOM_PROPERTY_NAME, value);
    }

    private static JsonObject textureEntry(String url, String model) {
        JsonObject entry = new JsonObject();
        entry.addProperty("url", url);
        if (model != null && !model.isEmpty() && !"auto".equalsIgnoreCase(model)) {
            JsonObject metadata = new JsonObject();
            metadata.addProperty("model", model.toLowerCase(Locale.ROOT));
            entry.add("metadata", metadata);
        }
        return entry;
    }

    /**
     * 把模板里的占位符换成真实玩家信息。
     *
     * <p>{@code {uuid}} 按 Yggdrasil 规范填<b>无连字符</b>的 UUID（带横线的地址皮肤站会直接 404），
     * 需要连字符时用 {@code {uuid_dash}}。</p>
     */
    private static String fill(String template, GameProfile profile) {
        if (template == null || template.isEmpty()) {
            return "";
        }
        String uuid = profile.id().toString();
        String name = profile.name() == null ? "" : profile.name();
        return template
                .replace("{uuid_dash}", uuid)
                .replace("{uuid_nodash}", uuid.replace("-", ""))
                .replace("{uuid}", uuid.replace("-", ""))
                .replace("{name}", name);
    }

    /** 转义 JSON 字符串里的引号和反斜杠；Minecraft 名字本来就很干净，这里只做兜底。 */
    private static String escapeJson(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private static String optString(JsonObject object, String key) {
        if (object == null || !object.has(key)) {
            return "";
        }
        JsonElement element = object.get(key);
        if (element == null || element.isJsonNull()) {
            return "";
        }
        return element.getAsString();
    }

    private static String httpGet(String url, int timeoutMillis) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URI(url).toURL().openConnection();
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(timeoutMillis);
        connection.setReadTimeout(timeoutMillis);
        connection.setInstanceFollowRedirects(true);
        connection.setRequestProperty("User-Agent", USER_AGENT);
        connection.setRequestProperty("Accept", "application/json,text/plain,*/*");
        int code = connection.getResponseCode();
        // 204 是 Yggdrasil 约定的「查无此人」，不是错误，直接当没有数据。
        if (code == HttpURLConnection.HTTP_NO_CONTENT) {
            return null;
        }
        if (code < 200 || code >= 300) {
            SkinPatch.LOGGER.warn("[SkinPatch] 皮肤站返回 HTTP {}：{}", code, url);
            return null;
        }
        // 读完就关流让连接回到 keep-alive 池；不要 disconnect，否则每次都要重做 TCP/TLS 握手。
        try (InputStream input = connection.getInputStream()) {
            return readAll(input);
        }
    }

    /** 发一个 JSON 数组的 POST 请求（Blessing Skin 的名字反查接口就是这么用的）。 */
    private static String httpPostJson(String url, String json, int timeoutMillis) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URI(url).toURL().openConnection();
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(timeoutMillis);
        connection.setReadTimeout(timeoutMillis);
        connection.setDoOutput(true);
        connection.setRequestProperty("User-Agent", USER_AGENT);
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        connection.setRequestProperty("Accept", "application/json");
        try (OutputStream output = connection.getOutputStream()) {
            output.write(json.getBytes(StandardCharsets.UTF_8));
        }
        int code = connection.getResponseCode();
        if (code < 200 || code >= 300) {
            SkinPatch.LOGGER.warn("[SkinPatch] 皮肤站名字接口返回 HTTP {}：{}", code, url);
            return null;
        }
        try (InputStream input = connection.getInputStream()) {
            return readAll(input);
        }
    }

    private static String readAll(InputStream input) throws Exception {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] buffer = new byte[4096];
        int read;
        while ((read = input.read(buffer)) != -1) {
            output.write(buffer, 0, read);
        }
        return output.toString(StandardCharsets.UTF_8);
    }
}
