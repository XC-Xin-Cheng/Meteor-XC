package cn.blockforge.generated.skinpatch.mixin;

import cn.blockforge.generated.skinpatch.SkinResolver;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.minecraft.MinecraftSessionService;
import com.mojang.authlib.properties.Property;
import net.minecraft.client.resources.SkinManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * 皮肤补丁的第一道注入点。
 *
 * <p>原版 {@code SkinManager.get(GameProfile)} 会先向会话服务器要一份打包好的
 * textures 属性，然后交给缓存和下载器处理。这里把这一步换成自定义皮肤站的数据：
 * 拿得到就用我们的，拿不到就原样调用原版逻辑。</p>
 *
 * <p>只替换“数据来源”，下载、缓存、模型识别仍然走原版，兼容性最好。</p>
 *
 * <p>换皮肤其实要过原版三道闸门，这里是第一道；补丁给的属性随后会被
 * {@link SkinManagerCacheLoaderMixin} 接管解包、绕开纹理域名白名单，并带上可信标记，
 * 否则第三方皮肤站的图片地址会被原版丢掉、其他玩家也看不到。</p>
 */
@Mixin(SkinManager.class)
public abstract class SkinManagerMixin {

    @Redirect(
            method = "get(Lcom/mojang/authlib/GameProfile;)Ljava/util/concurrent/CompletableFuture;",
            at = @At(
                    value = "INVOKE",
                    target = "Lcom/mojang/authlib/minecraft/MinecraftSessionService;getPackedTextures(Lcom/mojang/authlib/GameProfile;)Lcom/mojang/authlib/properties/Property;"
            )
    )
    private Property skinpatch$useCustomSkinSource(MinecraftSessionService sessionService, GameProfile profile) {
        Property patched = SkinResolver.resolve(profile);
        if (patched != null) {
            return patched;
        }
        return sessionService.getPackedTextures(profile);
    }
}
