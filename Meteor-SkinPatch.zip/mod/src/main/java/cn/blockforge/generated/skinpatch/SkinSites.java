package cn.blockforge.generated.skinpatch;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * 皮肤站预设地址与来源描述。
 *
 * <p>绝大多数国内皮肤站（LittleSkin、Blessing Skin 自建站）和 Ely.by 都实现了
 * Yggdrasil 的 profile 接口，返回的 JSON 里带一个 base64 的 {@code textures}
 * 属性，格式与 Mojang 官方完全一致，所以可以用同一段逻辑处理。</p>
 *
 * <p><b>为什么要按名字反查：</b>第三方皮肤站按自己的账号体系给玩家编号，
 * 你在站内的 UUID 和 Mojang 官方 UUID 是两回事（官方 UUID 拿到站里查一直是「查无此人」）。
 * 所以 Blessing Skin 系站点要先拿游戏名 POST 到 {@code /api/profiles/minecraft}
 * 换出站内 UUID，再用它去请求 profile 接口。这里登记的是各站的 API 根地址，
 * 两个接口都由根地址拼出来。</p>
 */
public final class SkinSites {
    /** Yggdrasil profile 接口的固定后缀；{uuid} 会被替换成无连字符的 UUID。 */
    public static final String PROFILE_PATH = "/sessionserver/session/minecraft/profile/{uuid}";

    /** Blessing Skin 系的「游戏名 → 站内 UUID」接口，需要 POST 一个名字数组。 */
    public static final String NAME_LOOKUP_PATH = "/api/profiles/minecraft";

    /** LittleSkin 的 Yggdrasil API 根地址。 */
    public static final String LITTLESKIN_ROOT = "https://littleskin.cn/api/yggdrasil";
    /** Ely.by 的材质接口：按昵称查询，返回结构与 Mojang 的 profile 接口一致。 */
    public static final String ELYBY_URL = "https://skinsystem.ely.by/profile/{name}?unsigned=false";
    /** Celestia Skin（MCS 星盟）的 Yggdrasil API 根地址。 */
    public static final String CELESTIA_ROOT = "https://skin.mcstaralliance.com/api/yggdrasil";
    /** MUA 用户中心（Minecraft 高校联盟）的 Yggdrasil API 根地址。 */
    public static final String MUA_ROOT = "https://skin.mualliance.ltd/api/yggdrasil";
    /** VlssuSkin 的 Yggdrasil API 根地址。 */
    public static final String VLSSU_ROOT = "https://skin.vlssu.com/api/yggdrasil";
    /** 红石皮肤站的 Yggdrasil API 根地址。 */
    public static final String REDSTONE_ROOT = "https://mcskin.cn/api/yggdrasil";

    /** LittleSkin 的 profile 接口完整地址。 */
    public static final String LITTLESKIN_URL = LITTLESKIN_ROOT + PROFILE_PATH;
    /** Celestia 的 profile 接口完整地址。 */
    public static final String CELESTIA_URL = CELESTIA_ROOT + PROFILE_PATH;
    /** MUA 的 profile 接口完整地址。 */
    public static final String MUA_URL = MUA_ROOT + PROFILE_PATH;
    /** VlssuSkin 的 profile 接口完整地址。 */
    public static final String VLSSU_URL = VLSSU_ROOT + PROFILE_PATH;
    /** 红石皮肤站的 profile 接口完整地址。 */
    public static final String REDSTONE_URL = REDSTONE_ROOT + PROFILE_PATH;

    /**
     * 可以「同时生效」的预设皮肤站，按推荐的尝试顺序排列。
     *
     * <p>玩家可能只在其中一家有号，所以模块允许一次勾选多家：主站取不到时依次往后试，
     * 谁先返回皮肤就用谁的，全都取不到才回退原版。</p>
     */
    public static final List<SkinSite> MULTI_PRESETS = List.of(
            SkinSite.LITTLESKIN,
            SkinSite.ELYBY,
            SkinSite.CELESTIA,
            SkinSite.MUA,
            SkinSite.VLSSU,
            SkinSite.REDSTONE);

    /** 预设皮肤站到「API 根地址」的映射；Blessing Skin 系站点才有根地址。 */
    private static final Map<SkinSite, String> PRESET_ROOTS = new EnumMap<>(SkinSite.class);

    static {
        PRESET_ROOTS.put(SkinSite.LITTLESKIN, LITTLESKIN_ROOT);
        PRESET_ROOTS.put(SkinSite.CELESTIA, CELESTIA_ROOT);
        PRESET_ROOTS.put(SkinSite.MUA, MUA_ROOT);
        PRESET_ROOTS.put(SkinSite.VLSSU, VLSSU_ROOT);
        PRESET_ROOTS.put(SkinSite.REDSTONE, REDSTONE_ROOT);
    }

    private SkinSites() {
    }

    /** 预设皮肤站的 Blessing Skin API 根地址；Ely.by、自定义、直链等返回 null。 */
    public static String presetRoot(SkinSite site) {
        return site == null ? null : PRESET_ROOTS.get(site);
    }

    /** 预设皮肤站的 profile 接口模板；自定义、直链等模式返回 null。 */
    public static String presetUrl(SkinSite site) {
        String root = presetRoot(site);
        if (root != null) {
            return root + PROFILE_PATH;
        }
        return site == SkinSite.ELYBY ? ELYBY_URL : null;
    }

    /**
     * 从 profile 接口模板反推 Blessing Skin 的 API 根地址。
     *
     * <p>只有模板里出现标准的 {@code /sessionserver/session/minecraft/profile/}
     * 路径才认得出来；填的是别的接口（比如 Ely.by 那种按名字查询的地址）就返回 null，
     * 调用方会退化成「填占位符直接请求」。自定义 Yggdrasil 也能靠这个用上名字反查。</p>
     */
    public static String blessingSkinRoot(String template) {
        if (template == null || template.isEmpty()) {
            return null;
        }
        int index = template.indexOf("/sessionserver/session/minecraft/profile/");
        if (index <= 0) {
            return null;
        }
        return template.substring(0, index);
    }

    /** 当前皮肤来源能不能用「游戏名 → 站内 UUID」反查。 */
    public static boolean supportsNameLookup(SkinSite site) {
        if (site == SkinSite.YGGDRASIL) {
            return true;
        }
        return presetRoot(site) != null;
    }

    /** 当前生效的来源里，任意一家支持名字反查就返回 true（用于设置项的显隐）。 */
    public static boolean anySupportsNameLookup(SkinPatchModule module) {
        for (SkinSite site : activeSites(module)) {
            if (supportsNameLookup(site)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 本次实际生效的来源，按尝试顺序排列：主皮肤站在最前，额外勾选的预设站依次跟在后面。
     *
     * <p>主站选「Mojang 官方」时它不进列表——官方数据是最后的兜底，只有自定义来源全部落空
     * 才会走它。列表为空表示当前没有任何自定义来源，解析层直接跳过。</p>
     */
    public static List<SkinSite> activeSites(SkinPatchModule module) {
        if (module == null) {
            return List.of();
        }
        List<SkinSite> sites = new ArrayList<>();
        SkinSite primary = module.skinSite.get();
        if (primary != null && primary != SkinSite.MOJANG) {
            sites.add(primary);
        }
        for (SkinSite site : MULTI_PRESETS) {
            if (site != primary && module.isExtraSiteEnabled(site)) {
                sites.add(site);
            }
        }
        return sites;
    }

    /** 给玩家看的一句话描述：当前到底从哪儿取皮肤。 */
    public static String describeSource(SkinPatchModule module) {
        if (module == null) {
            return "Mojang 官方";
        }
        List<SkinSite> sites = activeSites(module);
        if (sites.isEmpty()) {
            return "Mojang 官方";
        }
        String primary = describeOne(module, sites.get(0));
        if (sites.size() == 1) {
            return primary;
        }
        return primary + "，另加 " + (sites.size() - 1) + " 家备用";
    }

    /** 单个来源的一句话描述。 */
    private static String describeOne(SkinPatchModule module, SkinSite site) {
        if (presetUrl(site) != null) {
            return site.toString();
        }
        if (site == SkinSite.YGGDRASIL) {
            return orDefault(module.profileUrl.get(), "未填写接口地址");
        }
        if (site == SkinSite.CUSTOM) {
            return orDefault(module.customApiUrl.get(), "未填写接口地址");
        }
        if (site == SkinSite.DIRECT) {
            return orDefault(module.directSkin.get(), "未填写皮肤直链");
        }
        return "Mojang 官方";
    }

    private static String orDefault(String value, String fallback) {
        return value == null || value.isEmpty() ? fallback : value;
    }
}
