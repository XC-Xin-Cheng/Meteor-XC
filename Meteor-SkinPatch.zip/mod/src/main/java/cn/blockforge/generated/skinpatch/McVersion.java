package cn.blockforge.generated.skinpatch;

/**
 * 模块设置里的「MC版本」下拉，顺序按新版本在前排列。
 *
 * <p>这个值是取皮肤的兼容目标：1.19.4 以后客户端才有独立的鞘翅贴图（textures 里的
 * {@code ELYTRA}），更早的版本鞘翅只会套用披风图案。选了旧版本，补丁就不会往数据里塞
 * 鞘翅贴图，避免旧客户端拿到它不认识的贴图类型。</p>
 */
public enum McVersion {
    V26_1_2("26.1.2", true),
    V26_1_1("26.1.1", true),
    V26_1("26.1", true),
    V1_21_1("1.21.1", true),
    V1_21("1.21", true),
    V1_20_6("1.20.6", true),
    V1_20_5("1.20.5", true),
    V1_20_4("1.20.4", true),
    V1_20_3("1.20.3", true),
    V1_20_2("1.20.2", true),
    V1_20_1("1.20.1", true),
    V1_20("1.20", true),
    V1_19_4("1.19.4", true),
    V1_19_3("1.19.3", false),
    V1_19_2("1.19.2", false),
    V1_19_1("1.19.1", false),
    V1_19("1.19", false),
    V1_18_2("1.18.2", false),
    V1_18_1("1.18.1", false),
    V1_18("1.18", false),
    V1_17_1("1.17.1", false),
    V1_16_5("1.16.5", false);

    private final String label;
    private final boolean elytraTexture;

    McVersion(String label, boolean elytraTexture) {
        this.label = label;
        this.elytraTexture = elytraTexture;
    }

    /** 这个版本能不能用独立的鞘翅贴图。 */
    public boolean elytraTextureSupported() {
        return elytraTexture;
    }

    @Override
    public String toString() {
        return label;
    }
}
