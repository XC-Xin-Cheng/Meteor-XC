package cn.blockforge.generated.skinpatch.mixin;

import cn.blockforge.generated.skinpatch.SkinResolver;
import com.mojang.authlib.minecraft.MinecraftProfileTextures;
import com.mojang.authlib.minecraft.MinecraftSessionService;
import com.mojang.authlib.properties.Property;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * 皮肤补丁的第二道注入点：绕过原版的纹理域名白名单。
 *
 * <p>{@code SkinManager.get} 把补丁给的 textures 属性当作缓存键后，会由内部的
 * {@code SkinManager$1} 这个 CacheLoader 解包：先调
 * {@code MinecraftSessionService.unpackTextures(property)}，再交给
 * {@code registerTextures} 下载、注册。问题出在解包那一步——authlib 会用
 * {@code TextureUrlChecker.isAllowedTextureDomain} 检查每条纹理地址，只放行
 * {@code textures.minecraft.net}；第三方皮肤站（LittleSkin、Ely.by 等）的图片域名
 * 一律判为非法，直接返回 {@code MinecraftProfileTextures.EMPTY}，皮肤就变回默认。</p>
 *
 * <p>这里把这次调用换成：先问 {@link SkinResolver#unpackCustom}——只对补丁自己产出的属性
 * 返回自建的解包结果（域名检查一并跳过），其余属性原样交回原版
 * {@code unpackTextures}。所以原版对「服务器伪造皮肤地址」的防护还在，
 * 被放宽的只有玩家主动配置的那些来源。</p>
 *
 * <p>注入点是 {@code SkinManager$1.lambda$load$0}（lambda 内联后的静态合成方法），
 * 这里用字节码里的固定名字定位；版本锁定在 26.1.2，名字不会变。合成方法万一在别的
 * 环境里对不上也不致命（{@code require = 0}），此时由
 * {@link YggdrasilSessionServiceMixin} 在会话服务入口兜底。</p>
 */
@Mixin(targets = "net.minecraft.client.resources.SkinManager$1")
public abstract class SkinManagerCacheLoaderMixin {

    @Redirect(
            method = "lambda$load$0",
            require = 0,
            at = @At(
                    value = "INVOKE",
                    target = "Lcom/mojang/authlib/minecraft/MinecraftSessionService;unpackTextures(Lcom/mojang/authlib/properties/Property;)Lcom/mojang/authlib/minecraft/MinecraftProfileTextures;"
            )
    )
    private static MinecraftProfileTextures skinpatch$unpackCustomTextures(MinecraftSessionService sessionService,
                                                                           Property property) {
        MinecraftProfileTextures custom = SkinResolver.unpackCustom(property);
        if (custom != null) {
            return custom;
        }
        return sessionService.unpackTextures(property);
    }
}
