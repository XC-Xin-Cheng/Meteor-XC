package cn.blockforge.meteorzhcn.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;

/**
 * 打开一个界面。
 *
 * <p>1.21.11 里界面状态仍直接挂在 {@code MinecraftClient} 上，{@code setScreen(Screen)}
 * 就是本版本的正式接口，直接调用即可。不要再用按字符串查方法的反射：本版本的字节码在
 * 构建时会被重映射成 intermediary 名，反射里的字符串不会一起改，运行期会找不到方法。</p>
 */
public final class ClientScreens {
    private ClientScreens() {
    }

    public static void open(Screen screen) {
        MinecraftClient.getInstance().setScreen(screen);
    }
}
