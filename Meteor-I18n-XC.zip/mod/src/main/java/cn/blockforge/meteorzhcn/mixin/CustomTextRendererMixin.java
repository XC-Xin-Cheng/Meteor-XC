package cn.blockforge.meteorzhcn.mixin;

import java.io.IOException;
import java.nio.ByteBuffer;

import cn.blockforge.meteorzhcn.font_fix.FontFix;
import meteordevelopment.meteorclient.renderer.MeshBuilder;
import meteordevelopment.meteorclient.renderer.MeshRenderer;
import meteordevelopment.meteorclient.renderer.MeteorRenderPipelines;
import meteordevelopment.meteorclient.renderer.text.CustomTextRenderer;
import meteordevelopment.meteorclient.renderer.text.Font;
import meteordevelopment.meteorclient.renderer.text.FontFace;
import meteordevelopment.meteorclient.renderer.text.TextRenderer;
import meteordevelopment.meteorclient.utils.render.color.Color;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 把 Meteor 的字体渲染器换成支持按需补字形的实现，其余调用点完全不变。
 * 每个字号档位保留一份 {@link FontFix}，与原先的 5 档字体一一对应。
 */
@Mixin(value = CustomTextRenderer.class, remap = false)
public abstract class CustomTextRendererMixin implements TextRenderer {
    @Shadow
    @Final
    private MeshBuilder mesh;
    @Shadow
    @Final
    private Font[] fonts;
    @Shadow
    private boolean building;
    @Shadow
    private boolean scaleOnly;
    @Shadow
    private double fontScale;
    @Shadow
    private double scale;

    @Unique
    private FontFix[] fontsFix;
    @Unique
    private FontFix fontFix;
    /** 是否已经释放过纹理。Fonts.load 在新建渲染器失败时会回退重试，destroy 可能被调用两次。 */
    @Unique
    private boolean fontsFixReleased;

    @Inject(method = "<init>", at = @At("RETURN"))
    private void onInit(FontFace fontFace, CallbackInfo ci) throws IOException {
        ByteBuffer buffer = fontFace.readToDirectByteBuffer();
        FontFix[] fonts = new FontFix[5];

        try {
            for (int i = 0; i < fonts.length; i++) {
                fonts[i] = new FontFix(buffer, (int) Math.round(27.0 * ((double) i * 0.5 + 1.0)));
            }
        } catch (RuntimeException | Error e) {
            // 中途失败时把已经建好的图集先关掉，不然 Fonts.load 回退到默认字体时就漏了这几张显存纹理。
            for (FontFix font : fonts) {
                if (font != null) {
                    font.close();
                }
            }

            // 这个实例最终不会被赋值给 Fonts.RENDERER，Meteor 构造函数里建好的原版字体纹理同样要收掉。
            if (this.fonts != null) {
                for (Font font : this.fonts) {
                    if (font != null && font.texture != null) {
                        font.texture.close();
                    }
                }
            }

            throw e;
        }

        this.fontsFix = fonts;
    }

    @Overwrite
    public void begin(double scale, boolean scaleOnly, boolean big) {
        if (this.building) {
            throw new RuntimeException("CustomTextRenderer.begin() called twice");
        }

        if (!scaleOnly) {
            this.mesh.begin();
        }

        if (big) {
            this.fontFix = this.fontsFix[this.fontsFix.length - 1];
        } else {
            double scaleA = Math.floor(scale * 10.0) / 10.0;
            int scaleI;
            if (scaleA >= 3.0) {
                scaleI = 5;
            } else if (scaleA >= 2.5) {
                scaleI = 4;
            } else if (scaleA >= 2.0) {
                scaleI = 3;
            } else if (scaleA >= 1.5) {
                scaleI = 2;
            } else {
                scaleI = 1;
            }

            this.fontFix = this.fontsFix[scaleI - 1];
        }

        this.building = true;
        this.scaleOnly = scaleOnly;
        this.fontScale = (double) this.fontFix.getHeight() / 27.0;
        this.scale = 1.0 + (scale - this.fontScale) / this.fontScale;
    }

    @Overwrite
    public double getWidth(String text, int length, boolean shadow) {
        if (text.isEmpty()) {
            return 0.0;
        }

        FontFix font = this.building ? this.fontFix : this.fontsFix[0];
        return (font.getWidth(text, length) + (double) (shadow ? 1 : 0)) * this.scale / 1.5;
    }

    @Overwrite
    public double getHeight(boolean shadow) {
        FontFix font = this.building ? this.fontFix : this.fontsFix[0];
        return (double) (font.getHeight() + 1 + (shadow ? 1 : 0)) * this.scale / 1.5;
    }

    @Overwrite
    public double render(String text, double x, double y, Color color, boolean shadow) {
        boolean wasBuilding = this.building;
        if (!wasBuilding) {
            this.begin();
        }

        double width;
        if (shadow) {
            int preShadowA = CustomTextRenderer.SHADOW_COLOR.a;
            CustomTextRenderer.SHADOW_COLOR.a = (int) ((double) color.a / 255.0 * (double) preShadowA);
            width = this.fontFix.render(
                    this.mesh, text, x + this.fontScale * this.scale / 1.5, y + this.fontScale * this.scale / 1.5, CustomTextRenderer.SHADOW_COLOR, this.scale / 1.5
            );
            this.fontFix.render(this.mesh, text, x, y, color, this.scale / 1.5);
            CustomTextRenderer.SHADOW_COLOR.a = preShadowA;
        } else {
            width = this.fontFix.render(this.mesh, text, x, y, color, this.scale / 1.5);
        }

        if (!wasBuilding) {
            this.end();
        }

        return width;
    }

    @Overwrite
    public void end() {
        if (!this.building) {
            throw new RuntimeException("CustomTextRenderer.end() called without calling begin()");
        }

        if (!this.scaleOnly) {
            this.mesh.end();
            MeshRenderer.begin()
                    .attachments(Minecraft.getInstance().getMainRenderTarget())
                    .pipeline(MeteorRenderPipelines.UI_TEXT)
                    .mesh(this.mesh)
                    .sampler("u_Texture", this.fontFix.texture.getTextureView(), this.fontFix.texture.getSampler())
                    .end();
        }

        this.building = false;
        this.scale = 1.0;
    }

    @Overwrite
    public void destroy() {
        if (this.fontsFixReleased) {
            return;
        }

        this.fontsFixReleased = true;

        if (this.fontsFix != null) {
            for (FontFix font : this.fontsFix) {
                if (font != null) {
                    font.close();
                }
            }
        }

        if (this.fonts != null) {
            for (Font font : this.fonts) {
                font.texture.close();
            }
        }
    }
}
